if(!window.cp)window.cp = function(str){return document.getElementById(str)};cp.CPProjInit = function(){if(cp && cp.model && cp.model.data) return; cp.model = {}; cp.poolResources = {}; cp.D = cp.model.data = {
pref:{
acc:1,
rkt:1,
hsr:0,
atp:false
},
si5490:{
name:'Image_10',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si5490c',
tag:'container-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":520,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIXED_HEIGHT","padding":{"top":35,"bottom":35,"right":0,"left":0},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":1.18}',
retainState:false,
immo:false,
apsn:'Slide5512',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si5484',
t:1268
}
]
,
containerType:'image',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":520,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIXED_HEIGHT","padding":{"top":35,"bottom":35,"right":0,"left":0},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":1.18}',
option:'SINGLE_IMAGE_OPTION_ROW_C1',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si5490c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:5490,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5490',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--widget-container--fillcolor)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si5484:{
name:'Image_Group_10',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si5484c',
tag:'container-image-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-buttons":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":30,"bottom":30,"left":30,"right":30},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-buttons":"RIGHT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":3},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridTemplateRows":"minmax(10px,auto)","gridGap":"0 10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"3 / 2 / span 1 / span 2","marginTop":"0px","marginLeft":"24px"},"tablet":{},"mobile":{"marginLeft":"12px"}}}}',
parentGroup:'si5490',
retainState:false,
immo:false,
apsn:'Slide5512',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si5399',
t:15
}
,{
n:'si5427',
t:1268
}
]
,
containerType:'image-single-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-buttons":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":30,"bottom":30,"left":30,"right":30},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-buttons":"RIGHT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":3},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridTemplateRows":"minmax(10px,auto)","gridGap":"0 10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"3 / 2 / span 1 / span 2","marginTop":"0px","marginLeft":"24px"},"tablet":{},"mobile":{"marginLeft":"12px"}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si5490',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si5484c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:5484,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5484',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si5399:{
name:'cwaLogo',
type:15,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si5399c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{},"designOptionStyles":{"all":{"borderRadius":"0 50% 50% 0","overflow":"hidden"},"tablet":{"borderRadius":"0"},"mobile":{"borderRadius":"0"}}}',
parentGroup:'si5484',
retainState:false,
immo:false,
apsn:'Slide5512',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#000000',
o:0
}
,
o:100,
tiletype:1,
imageFocus:0,
irw:600,
irh:600,
w:600,
h:600,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[5399]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si5399c:{
b:[0,0,600,600],
fh:false,
fw:false,
uid:5399,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'171.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'171.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'171.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/064845.png',
dn:'si5399',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,601,601],
vb:[-1,-1,601,601]
},
si5427:{
name:'Image_Group_Text_40',
type:1268,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si5427c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"30px"},"tablet":{"paddingLeft":"0px"},"mobile":{"paddingLeft":"0px"}}}',
parentGroup:'si5484',
retainState:false,
immo:false,
apsn:'Slide5512',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si5411',
t:1250
}
,{
n:'si5421',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"30px"},"tablet":{"paddingLeft":"0px"},"mobile":{"paddingLeft":"0px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si5484',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si5427c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:5427,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5427',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si5411:{
name:'Text_105',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si5411c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"align-items":"start"},"tablet":{},"mobile":{}}}',
parentGroup:'si5427',
retainState:false,
immo:false,
apsn:'Slide5512',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"2g7ke","text":"The Orientation Handbook","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"defaultTextShadow:none"},{"offset":0,"length":24,"style":"textShadow:none"},{"offset":0,"length":24,"style":"textShadowX:0px"},{"offset":0,"length":24,"style":"fontStretch:normal"},{"offset":0,"length":24,"style":"fontType:regular"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":24,"style":"textShadowY:4px"},{"offset":0,"length":24,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":24,"style":"textHighlightEnable:false"},{"offset":0,"length":24,"style":"textTransform:none"},{"offset":0,"length":24,"style":"desktop-fontSize:60"},{"offset":0,"length":24,"style":"color:#020C1C"},{"offset":0,"length":24,"style":"lineHeight:100%"},{"offset":0,"length":24,"style":"textShadowOpacity:none"},{"offset":0,"length":24,"style":"overridden:true"},{"offset":0,"length":24,"style":"textDecoration:none"},{"offset":0,"length":24,"style":"fontFamily:Georgia"},{"offset":0,"length":24,"style":"borderBottomStyle:none"},{"offset":0,"length":24,"style":"mobile-fontSize:60"},{"offset":0,"length":24,"style":"textShadowEnable:false"},{"offset":0,"length":24,"style":"hlnk:"},{"offset":0,"length":24,"style":"fontWeight:normal"},{"offset":0,"length":24,"style":"textShadowBlur:8px"},{"offset":0,"length":24,"style":"tablet-fontSize:72"},{"offset":0,"length":24,"style":"backgroundColor:unset"},{"offset":0,"length":24,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":24,"style":"hlnkt:wp"},{"offset":0,"length":24,"style":"fontStyle:normal"},{"offset":0,"length":24,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":24,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"letterSpacing:-4%"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"center","marginBottom":"0%","presetId":"text-heading-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[5411]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si5411c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:5411,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5411',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si5421:{
name:'Text_106',
type:1250,
from:1,
to:90,
rp:0,
rpa:0,
mdi:'si5421c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:3,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"marginTop":"50px"},"tablet":{"marginTop":"0px"},"mobile":{"marginTop":"0px"}}}',
parentGroup:'si5427',
retainState:false,
immo:false,
apsn:'Slide5512',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"2civa","text":"Authored by Kobe Buckley","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":24,"style":"textShadow:none"},{"offset":0,"length":24,"style":"textShadowX:0px"},{"offset":0,"length":24,"style":"fontStretch:normal"},{"offset":0,"length":24,"style":"fontType:regular"},{"offset":0,"length":24,"style":"color:#333333"},{"offset":0,"length":24,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":24,"style":"textShadowY:4px"},{"offset":0,"length":24,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":24,"style":"lineHeight:135%"},{"offset":0,"length":24,"style":"letterSpacing:0%"},{"offset":0,"length":24,"style":"textHighlightEnable:false"},{"offset":0,"length":24,"style":"textTransform:none"},{"offset":0,"length":24,"style":"textShadowOpacity:none"},{"offset":0,"length":24,"style":"overridden:true"},{"offset":0,"length":24,"style":"textDecoration:none"},{"offset":0,"length":24,"style":"desktop-fontSize:30"},{"offset":0,"length":24,"style":"fontFamily:Georgia"},{"offset":0,"length":24,"style":"borderBottomStyle:none"},{"offset":0,"length":24,"style":"textShadowEnable:false"},{"offset":0,"length":24,"style":"hlnk:"},{"offset":0,"length":24,"style":"fontWeight:normal"},{"offset":0,"length":24,"style":"textShadowBlur:8px"},{"offset":0,"length":24,"style":"mobile-fontSize:20"},{"offset":0,"length":24,"style":"tablet-fontSize:24"},{"offset":0,"length":24,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":24,"style":"hlnkt:wp"},{"offset":0,"length":24,"style":"fontStyle:normal"},{"offset":0,"length":24,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":24,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":24,"style":"textOutlineEnable:false"},{"offset":0,"length":24,"style":"opacity:1"},{"offset":0,"length":24,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":24,"style":"hlnke:true"},{"offset":0,"length":24,"style":"defaultTextShadow:none"},{"offset":0,"length":24,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"center","marginBottom":"0%","presetId":"text-detail-4","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[5421]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si5421c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:5421,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5421',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
Slide5512:{
lb:'Onboarding Guide',
id:5512,
from:1,
to:90,
iols:0,
i360qs:false,
sdu:3,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide5512c',
st:'Normal Slide',
sk:'Introduction',
slideTag:'introduction-slide',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si5490',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
iso:false,
sc:'#333333',
ss:0,
sw:1,
sa:1,
se:true
}
,
bookmarks:[]
,
qs:''
},
Slide5512c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:5512,
dn:'Slide5512',
visible:'1'
},
si5777:{
name:'Paragraph_1',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5777c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":50,"bottom":50,"left":10,"right":10},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si5785',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"padding":{"top":50,"bottom":50,"left":10,"right":10},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'DEFAULT_PARAGRAPH_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si5777c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:5777,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5777',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--widget-container--fillcolor)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si5785:{
name:'Paragraph_Group_1',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5785c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"3 / 1 / span 1 / span 2"},"tablet":{},"mobile":{}}},"shouldDesignOptionHiddenInPI":true,"padding":{"top":20,"bottom":20,"left":20,"right":20},"groupedItemsVisibility":{"slide-item-buttons":1},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}}}',
parentGroup:'si5777',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si5793',
t:1250
}
,{
n:'si5813',
t:1250
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":true,"slide-item-buttons":false,"card":false},"alignment":{"slide-item-heading":"LEFT","slide-item-subtitle":"LEFT","slide-item-body":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"3 / 1 / span 1 / span 2"},"tablet":{},"mobile":{}}},"shouldDesignOptionHiddenInPI":true,"padding":{"top":20,"bottom":20,"left":20,"right":20},"groupedItemsVisibility":{"slide-item-buttons":1},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si5777',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si5785c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:5785,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5785',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si5793:{
name:'Text_107',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5793c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{},"meta":{"textHighlightEnable":true,"textOutlineEnable":true,"textShadowEnable":true}},"padding":{"top":10,"bottom":10,"left":10,"right":10},"autoFit":false}',
parentGroup:'si5785',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"ehtnt","text":"Welcome to Code with Aloha!","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":27,"style":"hlnkt:wp"},{"offset":0,"length":27,"style":"textOutlineEnable:false"},{"offset":0,"length":27,"style":"opacity:1"},{"offset":0,"length":27,"style":"hlnke:true"},{"offset":0,"length":27,"style":"backgroundColor:unset"},{"offset":0,"length":27,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":27,"style":"textHighlightEnable:false"},{"offset":0,"length":27,"style":"textShadowEnable:false"},{"offset":0,"length":27,"style":"overridden:false"},{"offset":0,"length":27,"style":"hlnk:"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"false","presetId":"text-heading-2"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[5793]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si5793c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:5793,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5793',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si5813:{
name:'Text_109',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5813c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si5785',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"1m56k","text":"We are a volunteer tech group centered around solving various civic issues such as affordable housing and economic sustainability.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":130,"style":"textHighlightEnable:false"},{"offset":0,"length":130,"style":"textTransform:none"},{"offset":0,"length":130,"style":"textShadowOpacity:none"},{"offset":0,"length":130,"style":"overridden:true"},{"offset":0,"length":130,"style":"textDecoration:none"},{"offset":0,"length":130,"style":"desktop-fontSize:30"},{"offset":0,"length":130,"style":"lineHeight:130%"},{"offset":0,"length":130,"style":"borderBottomStyle:none"},{"offset":0,"length":130,"style":"textShadowEnable:false"},{"offset":0,"length":130,"style":"hlnk:"},{"offset":0,"length":130,"style":"fontWeight:normal"},{"offset":0,"length":130,"style":"textShadowBlur:8px"},{"offset":0,"length":130,"style":"fontFamily:Arial"},{"offset":0,"length":130,"style":"backgroundColor:unset"},{"offset":0,"length":130,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":130,"style":"hlnkt:wp"},{"offset":0,"length":130,"style":"fontStyle:normal"},{"offset":0,"length":130,"style":"tablet-fontSize:20"},{"offset":0,"length":130,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":130,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":130,"style":"textOutlineEnable:false"},{"offset":0,"length":130,"style":"opacity:1"},{"offset":0,"length":130,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":130,"style":"hlnke:true"},{"offset":0,"length":130,"style":"defaultTextShadow:none"},{"offset":0,"length":130,"style":"textShadow:none"},{"offset":0,"length":130,"style":"mobile-fontSize:18"},{"offset":0,"length":130,"style":"textShadowX:0px"},{"offset":0,"length":130,"style":"fontStretch:normal"},{"offset":0,"length":130,"style":"fontType:regular"},{"offset":0,"length":130,"style":"color:#666666"},{"offset":0,"length":130,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":130,"style":"textShadowY:4px"},{"offset":0,"length":130,"style":"letterSpacing:3%"},{"offset":0,"length":130,"style":"textShadowColor:#F1EEE61F"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[5813]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si5813c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:5813,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5813',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si5871:{
name:'Image_Grid_1',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5871c',
tag:'container-image-grid',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":292,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_SCALE","padding":{"top":0,"bottom":0,"left":5,"right":5},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"20px","marginBottom":"15px"},"tablet":{"display":"flex","flexDirection":"column","marginBottom":"40px"},"mobile":{"display":"flex","flexDirection":"column","marginBottom":"40px"}},"appearanceProperties":{},"imageAspectRatio":1.34,"numberOfChildren":2}',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si5879',
t:1268
}
,{
n:'si5943',
t:1268
}
,{
n:'si6007',
t:1268
}
]
,
containerType:'image-grid',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":292,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_SCALE","padding":{"top":0,"bottom":0,"left":5,"right":5},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"20px","marginBottom":"15px"},"tablet":{"display":"flex","flexDirection":"column","marginBottom":"40px"},"mobile":{"display":"flex","flexDirection":"column","marginBottom":"40px"}},"appearanceProperties":{},"imageAspectRatio":1.34,"numberOfChildren":2}',
option:'IMAGE_GRID_OPTION_SQUARE',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si5871c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:5871,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5871',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si5879:{
name:'Image_Grid_Group_1',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5879c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-button":false},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-button":"RIGHT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"gridArea":"2 / 1 / span 1 / span 2"},"tablet":{},"mobile":{}}}}',
parentGroup:'si5871',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si5887',
t:15
}
,{
n:'si5899',
t:1268
}
]
,
containerType:'image-grid-card',
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-button":false},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-button":"RIGHT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"gridArea":"2 / 1 / span 1 / span 2"},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si5871',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si5879c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:5879,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5879',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si5887:{
name:'mike-presenting',
type:15,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5887c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si5879',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:3024,
irh:4032,
w:3024,
h:4032,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[5887]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si5887c:{
b:[0,0,3024,4032],
fh:false,
fw:false,
uid:5887,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025076.jpg',
dn:'si5887',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,3025,4033],
vb:[-1,-1,3025,4033]
},
si5899:{
name:'Image_Group_Text_41',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5899c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si5879',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si5907',
t:1250
}
,{
n:'si5917',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si5879',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si5899c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:5899,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5899',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si5907:{
name:'Text_110',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5907c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si5899',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"4dfgb","text":"Accessbility for our Community","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":30,"style":"textShadowX:0px"},{"offset":0,"length":30,"style":"fontStretch:normal"},{"offset":0,"length":30,"style":"color:#333333"},{"offset":0,"length":30,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":30,"style":"textShadowY:4px"},{"offset":0,"length":30,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":30,"style":"lineHeight:135%"},{"offset":0,"length":30,"style":"letterSpacing:0%"},{"offset":0,"length":30,"style":"textHighlightEnable:false"},{"offset":0,"length":30,"style":"textTransform:none"},{"offset":0,"length":30,"style":"textShadowOpacity:none"},{"offset":0,"length":30,"style":"overridden:true"},{"offset":0,"length":30,"style":"textDecoration:none"},{"offset":0,"length":30,"style":"fontType:bold"},{"offset":0,"length":30,"style":"fontFamily:Georgia"},{"offset":0,"length":30,"style":"borderBottomStyle:none"},{"offset":0,"length":30,"style":"textShadowEnable:false"},{"offset":0,"length":30,"style":"hlnk:"},{"offset":0,"length":30,"style":"fontWeight:normal"},{"offset":0,"length":30,"style":"textShadowBlur:8px"},{"offset":0,"length":30,"style":"desktop-fontSize:36"},{"offset":0,"length":30,"style":"mobile-fontSize:20"},{"offset":0,"length":30,"style":"backgroundColor:unset"},{"offset":0,"length":30,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":30,"style":"hlnkt:wp"},{"offset":0,"length":30,"style":"fontStyle:normal"},{"offset":0,"length":30,"style":"tablet-fontSize:20"},{"offset":0,"length":30,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":30,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":30,"style":"textOutlineEnable:false"},{"offset":0,"length":30,"style":"opacity:1"},{"offset":0,"length":30,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":30,"style":"hlnke:true"},{"offset":0,"length":30,"style":"defaultTextShadow:none"},{"offset":0,"length":30,"style":"textShadow:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-question-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[5907]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si5907c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:5907,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5907',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si5917:{
name:'Text_111',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5917c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si5899',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"dier9","text":"Our mission is to work with our community in developing free and open-source projects that make essential resources easily accessible.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":134,"style":"hlnkt:wp"},{"offset":0,"length":134,"style":"fontStyle:normal"},{"offset":0,"length":134,"style":"tablet-fontSize:20"},{"offset":0,"length":134,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":134,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":134,"style":"textOutlineEnable:false"},{"offset":0,"length":134,"style":"opacity:1"},{"offset":0,"length":134,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":134,"style":"hlnke:true"},{"offset":0,"length":134,"style":"defaultTextShadow:none"},{"offset":0,"length":134,"style":"textShadow:none"},{"offset":0,"length":134,"style":"mobile-fontSize:18"},{"offset":0,"length":134,"style":"textShadowX:0px"},{"offset":0,"length":134,"style":"fontStretch:normal"},{"offset":0,"length":134,"style":"fontType:regular"},{"offset":0,"length":134,"style":"color:#333333"},{"offset":0,"length":134,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":134,"style":"textShadowY:4px"},{"offset":0,"length":134,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":134,"style":"letterSpacing:0%"},{"offset":0,"length":134,"style":"textHighlightEnable:false"},{"offset":0,"length":134,"style":"textTransform:none"},{"offset":0,"length":134,"style":"textShadowOpacity:none"},{"offset":0,"length":134,"style":"overridden:true"},{"offset":0,"length":134,"style":"textDecoration:none"},{"offset":0,"length":134,"style":"desktop-fontSize:30"},{"offset":0,"length":134,"style":"lineHeight:130%"},{"offset":0,"length":134,"style":"fontFamily:Georgia"},{"offset":0,"length":134,"style":"borderBottomStyle:none"},{"offset":0,"length":134,"style":"textShadowEnable:false"},{"offset":0,"length":134,"style":"hlnk:"},{"offset":0,"length":134,"style":"fontWeight:normal"},{"offset":0,"length":134,"style":"textShadowBlur:8px"},{"offset":0,"length":134,"style":"backgroundColor:unset"},{"offset":0,"length":134,"style":"WebkitTextStrokeWidth:1px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"bpm9o","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"d7a2b","text":"For example, our Hawaii Zoning Atlas project simplifies complex zoning laws into an interactive visual map, ensuring everyone can understand them.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":146,"style":"fontWeight:normal"},{"offset":0,"length":146,"style":"textShadowBlur:8px"},{"offset":0,"length":146,"style":"backgroundColor:unset"},{"offset":0,"length":146,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":146,"style":"hlnkt:wp"},{"offset":0,"length":146,"style":"fontStyle:normal"},{"offset":0,"length":146,"style":"tablet-fontSize:20"},{"offset":0,"length":146,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":146,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":146,"style":"textOutlineEnable:false"},{"offset":0,"length":146,"style":"opacity:1"},{"offset":0,"length":146,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":146,"style":"hlnke:true"},{"offset":0,"length":146,"style":"defaultTextShadow:none"},{"offset":0,"length":146,"style":"textShadow:none"},{"offset":0,"length":146,"style":"mobile-fontSize:18"},{"offset":0,"length":146,"style":"textShadowX:0px"},{"offset":0,"length":146,"style":"fontStretch:normal"},{"offset":0,"length":146,"style":"fontType:regular"},{"offset":0,"length":146,"style":"color:#333333"},{"offset":0,"length":146,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":146,"style":"textShadowY:4px"},{"offset":0,"length":146,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":146,"style":"letterSpacing:0%"},{"offset":0,"length":146,"style":"textHighlightEnable:false"},{"offset":0,"length":146,"style":"textTransform:none"},{"offset":0,"length":146,"style":"textShadowOpacity:none"},{"offset":0,"length":146,"style":"overridden:true"},{"offset":0,"length":146,"style":"textDecoration:none"},{"offset":0,"length":146,"style":"desktop-fontSize:30"},{"offset":0,"length":146,"style":"lineHeight:130%"},{"offset":0,"length":146,"style":"fontFamily:Georgia"},{"offset":0,"length":146,"style":"borderBottomStyle:none"},{"offset":0,"length":146,"style":"textShadowEnable:false"},{"offset":0,"length":146,"style":"hlnk:"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[5917]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si5917c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:5917,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5917',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si5943:{
name:'Image_Grid_Group_2',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5943c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-button":false},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-button":"RIGHT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"gridArea":"2 / 1 / span 1 / span 2"},"tablet":{},"mobile":{}}}}',
parentGroup:'si5871',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si5951',
t:15
}
,{
n:'si5963',
t:1268
}
]
,
containerType:'image-grid-card',
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-button":false},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-button":"RIGHT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"gridArea":"2 / 1 / span 1 / span 2"},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si5871',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si5943c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:5943,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5943',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si5951:{
name:'boxjelly-pic_2',
type:15,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5951c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si5943',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:2,
imageFocus:0,
irw:4032,
irh:3024,
w:4032,
h:3024,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[5951]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si5951c:{
b:[0,0,4032,3024],
fh:false,
fw:false,
uid:5951,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025082.jpg',
dn:'si5951',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,4033,3025],
vb:[-1,-1,4033,3025]
},
si5963:{
name:'Image_Group_Text_42',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5963c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si5943',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si5971',
t:1250
}
,{
n:'si5981',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si5943',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si5963c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:5963,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5963',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si5971:{
name:'Text_112',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5971c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si5963',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"75o3g","text":"No Coding Experience Needed!","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":28,"style":"hlnke:true"},{"offset":0,"length":28,"style":"defaultTextShadow:none"},{"offset":0,"length":28,"style":"textShadow:none"},{"offset":0,"length":28,"style":"textShadowX:0px"},{"offset":0,"length":28,"style":"fontStretch:normal"},{"offset":0,"length":28,"style":"color:#333333"},{"offset":0,"length":28,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":28,"style":"textShadowY:4px"},{"offset":0,"length":28,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":28,"style":"lineHeight:135%"},{"offset":0,"length":28,"style":"letterSpacing:0%"},{"offset":0,"length":28,"style":"textHighlightEnable:false"},{"offset":0,"length":28,"style":"textTransform:none"},{"offset":0,"length":28,"style":"textShadowOpacity:none"},{"offset":0,"length":28,"style":"overridden:true"},{"offset":0,"length":28,"style":"textDecoration:none"},{"offset":0,"length":28,"style":"fontType:bold"},{"offset":0,"length":28,"style":"fontFamily:Georgia"},{"offset":0,"length":28,"style":"borderBottomStyle:none"},{"offset":0,"length":28,"style":"textShadowEnable:false"},{"offset":0,"length":28,"style":"hlnk:"},{"offset":0,"length":28,"style":"fontWeight:normal"},{"offset":0,"length":28,"style":"textShadowBlur:8px"},{"offset":0,"length":28,"style":"desktop-fontSize:36"},{"offset":0,"length":28,"style":"mobile-fontSize:20"},{"offset":0,"length":28,"style":"backgroundColor:unset"},{"offset":0,"length":28,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":28,"style":"hlnkt:wp"},{"offset":0,"length":28,"style":"fontStyle:normal"},{"offset":0,"length":28,"style":"tablet-fontSize:20"},{"offset":0,"length":28,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":28,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":28,"style":"textOutlineEnable:false"},{"offset":0,"length":28,"style":"opacity:1"},{"offset":0,"length":28,"style":"defaultTextStrokeColor:#F1EEE6"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-question-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[5971]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si5971c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:5971,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5971',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si5981:{
name:'Text_113',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si5981c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si5963',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6a5of","text":"There are various roles that can you can contribute to such as Copywriting, UI / UX Design, Web Design, Web Development, Research & Development, Onboarding, etc., \\n\\nWhether you are learning a new role or already experienced; there are many ways to contribute!","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":259,"style":"textOutlineEnable:false"},{"offset":0,"length":259,"style":"opacity:1"},{"offset":0,"length":259,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":259,"style":"hlnke:true"},{"offset":0,"length":259,"style":"defaultTextShadow:none"},{"offset":0,"length":259,"style":"textShadow:none"},{"offset":0,"length":259,"style":"mobile-fontSize:18"},{"offset":0,"length":259,"style":"textShadowX:0px"},{"offset":0,"length":259,"style":"fontStretch:normal"},{"offset":0,"length":259,"style":"fontType:regular"},{"offset":0,"length":259,"style":"color:#333333"},{"offset":0,"length":259,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":259,"style":"textShadowY:4px"},{"offset":0,"length":259,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":259,"style":"letterSpacing:0%"},{"offset":0,"length":259,"style":"textHighlightEnable:false"},{"offset":0,"length":259,"style":"textTransform:none"},{"offset":0,"length":259,"style":"textShadowOpacity:none"},{"offset":0,"length":259,"style":"overridden:true"},{"offset":0,"length":259,"style":"textDecoration:none"},{"offset":0,"length":259,"style":"desktop-fontSize:30"},{"offset":0,"length":259,"style":"lineHeight:130%"},{"offset":0,"length":259,"style":"fontFamily:Georgia"},{"offset":0,"length":259,"style":"borderBottomStyle:none"},{"offset":0,"length":259,"style":"textShadowEnable:false"},{"offset":0,"length":259,"style":"hlnk:"},{"offset":0,"length":259,"style":"fontWeight:normal"},{"offset":0,"length":259,"style":"textShadowBlur:8px"},{"offset":0,"length":259,"style":"backgroundColor:unset"},{"offset":0,"length":259,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":259,"style":"hlnkt:wp"},{"offset":0,"length":259,"style":"fontStyle:normal"},{"offset":0,"length":259,"style":"tablet-fontSize:20"},{"offset":0,"length":259,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":259,"style":"WebkitTextStrokeColor:#F1EEE6"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[5981]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si5981c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:5981,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si5981',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si6007:{
name:'Image_Grid_Group_3',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6007c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-button":false},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-button":"RIGHT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"gridArea":"2 / 1 / span 1 / span 2"},"tablet":{},"mobile":{}}}}',
parentGroup:'si5871',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6015',
t:15
}
,{
n:'si6027',
t:1268
}
]
,
containerType:'image-grid-card',
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-button":false},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-button":"RIGHT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"gridArea":"2 / 1 / span 1 / span 2"},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si5871',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si6007c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6007,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6007',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6015:{
name:'default_image3',
type:15,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6015c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si6007',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:612,
irh:758,
w:612,
h:758,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6015]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6015c:{
b:[0,0,612,758],
fh:false,
fw:false,
uid:6015,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/0673.png',
dn:'si6015',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,613,759],
vb:[-1,-1,613,759]
},
si6027:{
name:'Image_Group_Text_43',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6027c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6007',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6035',
t:1250
}
,{
n:'si6045',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6007',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si6027c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6027,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6027',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6035:{
name:'Text_114',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6035c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6027',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"85ofs","text":"Module 3","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-question-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6035]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6035c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6035,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6035',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6045:{
name:'Text_115',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6045c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6027',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"fbb62","text":"Lorem Ipsum is simply dummy text of the printing and typesetting industry.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":74,"style":"hlnk:"},{"offset":0,"length":74,"style":"hlnkt:wp"},{"offset":0,"length":74,"style":"textOutlineEnable:false"},{"offset":0,"length":74,"style":"opacity:1"},{"offset":0,"length":74,"style":"hlnke:true"},{"offset":0,"length":74,"style":"backgroundColor:unset"},{"offset":0,"length":74,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":74,"style":"textHighlightEnable:false"},{"offset":0,"length":74,"style":"textShadowEnable:false"},{"offset":0,"length":74,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6045]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6045c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6045,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6045',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6079:{
name:'default_image4',
type:15,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6079c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si6071',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:612,
irh:758,
w:612,
h:758,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6079]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6079c:{
b:[0,0,612,758],
fh:false,
fw:false,
uid:6079,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/0740.png',
dn:'si6079',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,613,759],
vb:[-1,-1,613,759]
},
si6091:{
name:'Image_Group_Text_44',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6091c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6071',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6099',
t:1250
}
,{
n:'si6109',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6071',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si6091c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6091,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6091',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6099:{
name:'Text_116',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6099c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6091',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"dvamn","text":"Module 4","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-question-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6099]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6099c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6099,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6099',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6109:{
name:'Text_117',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6109c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6091',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"dvqvi","text":"Lorem Ipsum is simply dummy text of the printing and typesetting industry.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":74,"style":"hlnk:"},{"offset":0,"length":74,"style":"hlnkt:wp"},{"offset":0,"length":74,"style":"textOutlineEnable:false"},{"offset":0,"length":74,"style":"opacity:1"},{"offset":0,"length":74,"style":"hlnke:true"},{"offset":0,"length":74,"style":"backgroundColor:unset"},{"offset":0,"length":74,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":74,"style":"textHighlightEnable:false"},{"offset":0,"length":74,"style":"textShadowEnable:false"},{"offset":0,"length":74,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6109]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6109c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6109,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6109',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6143:{
name:'default_image5',
type:15,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6143c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si6135',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:612,
irh:758,
w:612,
h:758,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6143]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6143c:{
b:[0,0,612,758],
fh:false,
fw:false,
uid:6143,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/0807.png',
dn:'si6143',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,613,759],
vb:[-1,-1,613,759]
},
si6155:{
name:'Image_Group_Text_45',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6155c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6135',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6163',
t:1250
}
,{
n:'si6173',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6135',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si6155c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6155,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6155',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6163:{
name:'Text_118',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6163c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6155',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"bm0h0","text":"Module 5","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-question-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6163]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6163c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6163,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6163',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6173:{
name:'Text_119',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6173c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6155',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"feso9","text":"Lorem Ipsum is simply dummy text of the printing and typesetting industry.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":74,"style":"hlnk:"},{"offset":0,"length":74,"style":"hlnkt:wp"},{"offset":0,"length":74,"style":"textOutlineEnable:false"},{"offset":0,"length":74,"style":"opacity:1"},{"offset":0,"length":74,"style":"hlnke:true"},{"offset":0,"length":74,"style":"backgroundColor:unset"},{"offset":0,"length":74,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":74,"style":"textHighlightEnable:false"},{"offset":0,"length":74,"style":"textShadowEnable:false"},{"offset":0,"length":74,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6173]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6173c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6173,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6173',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6207:{
name:'default_image6',
type:15,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6207c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si6199',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:612,
irh:758,
w:612,
h:758,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6207]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6207c:{
b:[0,0,612,758],
fh:false,
fw:false,
uid:6207,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'62.963%',
h:'124.671%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/0874.png',
dn:'si6207',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,613,759],
vb:[-1,-1,613,759]
},
si6219:{
name:'Image_Group_Text_46',
type:1268,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6219c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6199',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si6227',
t:1250
}
,{
n:'si6237',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si6199',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si6219c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:6219,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6219',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si6227:{
name:'Text_120',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6227c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6219',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"7ml6l","text":"Module 6","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-question-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6227]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6227c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6227,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6227',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si6237:{
name:'Text_121',
type:1250,
from:91,
to:276,
rp:0,
rpa:0,
mdi:'si6237c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si6219',
retainState:false,
immo:false,
apsn:'Slide5755',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"itce","text":"Lorem Ipsum is simply dummy text of the printing and typesetting industry.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":74,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":74,"style":"textHighlightEnable:false"},{"offset":0,"length":74,"style":"textShadowEnable:false"},{"offset":0,"length":74,"style":"overridden:false"},{"offset":0,"length":74,"style":"hlnk:"},{"offset":0,"length":74,"style":"hlnkt:wp"},{"offset":0,"length":74,"style":"textOutlineEnable:false"},{"offset":0,"length":74,"style":"opacity:1"},{"offset":0,"length":74,"style":"hlnke:true"},{"offset":0,"length":74,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[6237]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si6237c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:6237,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si6237',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
Slide5755:{
lb:'Welcome',
id:5755,
from:91,
to:276,
iols:0,
i360qs:false,
sdu:6.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide5755c',
st:'Normal Slide',
sk:'Title and Image',
slideTag:'title-image-slide',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si5777',
t:1268
}
,{
n:'si5871',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
iso:true,
sc:'#333333',
ss:0,
sw:1,
sa:1,
se:true
}
,
bookmarks:[]
,
qs:''
},
Slide5755c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:5755,
dn:'Slide5755',
visible:'1'
},
si17181:{
name:'Paragraph_20',
type:1268,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17181c',
tag:'container-paragraph',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"padding":{"top":20,"bottom":20,"left":10,"right":10},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si17189',
t:1268
}
]
,
containerType:'paragraph',
widgetProps:'{"padding":{"top":20,"bottom":20,"left":10,"right":10},"visibilityInfo":{"isDerivedFromChild":true},"groupedItemsVisibility":{"isDerivedFromChild":true},"alignment":{"isDerivedFromChild":true},"canBeCard":false,"appearanceProperties":{},"autoFit":false,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'PARAGRAPH_OPTION_SOLID_FILL',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si17181c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:17181,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17181',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si17189:{
name:'Paragraph_Group_20',
type:1268,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17189c',
tag:'container-paragraph-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":false,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-heading":"CENTER","slide-item-subtitle":"CENTER","slide-item-body":"CENTER","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si17181',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si17197',
t:1250
}
]
,
containerType:'paragraph-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-subtitle":false,"slide-item-body":false,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-heading":"CENTER","slide-item-subtitle":"CENTER","slide-item-body":"CENTER","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si17181',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si17189c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:17189,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17189',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si17197:{
name:'Text_394',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17197c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"shouldDesignOptionHiddenInPI":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{},"meta":{"textHighlightEnable":true,"textOutlineEnable":true,"textShadowEnable":true}}}',
parentGroup:'si17189',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"fk32e","text":"HZA & HIERR","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":11,"style":"textShadowEnable:false"},{"offset":0,"length":11,"style":"hlnk:"},{"offset":0,"length":11,"style":"fontWeight:normal"},{"offset":0,"length":11,"style":"textShadowBlur:8px"},{"offset":0,"length":11,"style":"mobile-fontSize:32"},{"offset":0,"length":11,"style":"textShadow:none"},{"offset":0,"length":11,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":11,"style":"hlnkt:wp"},{"offset":0,"length":11,"style":"fontStyle:normal"},{"offset":0,"length":11,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":11,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":11,"style":"textOutlineEnable:false"},{"offset":0,"length":11,"style":"opacity:1"},{"offset":0,"length":11,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":11,"style":"hlnke:true"},{"offset":0,"length":11,"style":"defaultTextShadow:none"},{"offset":0,"length":11,"style":"backgroundColor:unset"},{"offset":0,"length":11,"style":"tablet-fontSize:48"},{"offset":0,"length":11,"style":"textShadowX:0px"},{"offset":0,"length":11,"style":"fontStretch:normal"},{"offset":0,"length":11,"style":"fontType:regular"},{"offset":0,"length":11,"style":"color:#333333"},{"offset":0,"length":11,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":11,"style":"textShadowY:4px"},{"offset":0,"length":11,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":11,"style":"desktop-fontSize:80"},{"offset":0,"length":11,"style":"lineHeight:135%"},{"offset":0,"length":11,"style":"letterSpacing:0%"},{"offset":0,"length":11,"style":"textHighlightEnable:false"},{"offset":0,"length":11,"style":"textTransform:none"},{"offset":0,"length":11,"style":"textShadowOpacity:none"},{"offset":0,"length":11,"style":"overridden:true"},{"offset":0,"length":11,"style":"textDecoration:none"},{"offset":0,"length":11,"style":"fontFamily:Georgia"},{"offset":0,"length":11,"style":"borderBottomStyle:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"center","marginBottom":"0%","presetId":"text-heading-8","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17197]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17197c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:17197,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17197',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si17275:{
name:'Image_Grid_20',
type:1268,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17275c',
tag:'container-image-grid',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":292,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_SCALE","padding":{"top":0,"bottom":0,"left":5,"right":5},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"20px","marginBottom":"15px"},"tablet":{"display":"flex","flexDirection":"column","marginBottom":"40px"},"mobile":{"display":"flex","flexDirection":"column","marginBottom":"40px"}},"appearanceProperties":{},"imageAspectRatio":1.34,"numberOfChildren":2}',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si17283',
t:1268
}
,{
n:'si17349',
t:1268
}
]
,
containerType:'image-grid',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":292,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_SCALE","padding":{"top":0,"bottom":0,"left":5,"right":5},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"20px","marginBottom":"15px"},"tablet":{"display":"flex","flexDirection":"column","marginBottom":"40px"},"mobile":{"display":"flex","flexDirection":"column","marginBottom":"40px"}},"appearanceProperties":{},"imageAspectRatio":1.34,"numberOfChildren":2}',
option:'IMAGE_GRID_OPTION_SQUARE',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si17275c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:17275,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17275',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si17283:{
name:'Image_Grid_Group_115',
type:1268,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17283c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-button":true},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-button":"CENTER"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"order":3},"tablet":{},"mobile":{}}}}',
parentGroup:'si17275',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si17293',
t:15
}
,{
n:'si17305',
t:1268
}
,{
n:'si17333',
t:29
}
]
,
containerType:'image-grid-card',
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-button":true},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-button":"CENTER"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"order":3},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si17275',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si17283c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:17283,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17283',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si17293:{
name:'HawaiiZoningAtlas',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17293c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si17283',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.openURL(\\"https://hawaiizoningatlas.com/\\",\\"_blank\\");"]]}]}',
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1325,
irh:985,
w:1325,
h:985,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:64854,
stt:0,
dsr:'Default_State',
stsi:[17293]
}
,{
stn:64855,
stt:2,
dsr:'Hover',
stsi:[64856]
}
,{
stn:64874,
stt:10,
dsr:'Visited',
stsi:[64875]
}
,{
stn:64893,
stt:13,
dsr:'Selected',
stsi:[64894]
}
,{
stn:64912,
stt:14,
dsr:'Disabled',
stsi:[64913]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:true,
sihds:false,
stc:['si17293','si64856','si64875','si64894','si64913'],
siq:false,
isDD:false
},
si17293c:{
b:[0,0,1325,985],
fh:false,
fw:false,
uid:17293,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025060.png',
dn:'si17293',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1326,986],
vb:[-1,-1,1326,986]
},
si64856:{
name:'HawaiiZoningAtlas',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si64856c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_lighten',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}},"imgStateStyle":{"transformOrigin":"center","transform":"scale(1.05)","transition":"all .5s"}}',
parentGroup:'si17283',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'soft-light',
ift:'Lighten',
ifi:80,
iff:{
bc:'#ffffff',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1325,
irh:985,
w:1325,
h:985,
x:0,
y:0
}
,
trin:0,
trout:0,
bstin:'si17293',
stl:[{
stn:'Normal',
stt:0,
stsi:[64856]
}
]
,
stis:0,
bstiid:17293,
sipst:2,
sicbs:true,
sihhs:true,
sihds:false,
baseItemIdForPropertyFlow:17293,
isDD:false
},
si64856c:{
b:[0,0,1325,985],
fh:false,
fw:false,
uid:64856,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025060.png',
dn:'si64856',
visible:0,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1326,986],
vb:[-1,-1,1326,986]
},
si64875:{
name:'HawaiiZoningAtlas',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si64875c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_greyscale',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si17283',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:15,
c:15,
br:0,
ifbm:'saturation',
ift:'Greyscale',
ifi:0,
iff:{
bc:'#000000',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1325,
irh:985,
w:1325,
h:985,
x:0,
y:0
}
,
trin:0,
trout:0,
bstin:'si17293',
stl:[{
stn:'Normal',
stt:0,
stsi:[64875]
}
]
,
stis:0,
bstiid:17293,
sipst:10,
sicbs:true,
sihhs:true,
sihds:false,
baseItemIdForPropertyFlow:17293,
isDD:false
},
si64875c:{
b:[0,0,1325,985],
fh:false,
fw:false,
uid:64875,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025060.png',
dn:'si64875',
visible:0,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1326,986],
vb:[-1,-1,1326,986]
},
si64894:{
name:'HawaiiZoningAtlas',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si64894c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_overlay',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}},"imgStateStyle":{"transformOrigin":"center","transform":"scale(1.025)","transition":"all .5s"}}',
parentGroup:'si17283',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'overlay',
ift:'Overlay',
ifi:65,
iff:{
bc:'#000000',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1325,
irh:985,
w:1325,
h:985,
x:0,
y:0
}
,
trin:0,
trout:0,
bstin:'si17293',
stl:[{
stn:'Normal',
stt:0,
stsi:[64894]
}
]
,
stis:0,
bstiid:17293,
sipst:13,
sicbs:true,
sihhs:true,
sihds:false,
baseItemIdForPropertyFlow:17293,
isDD:false
},
si64894c:{
b:[0,0,1325,985],
fh:false,
fw:false,
uid:64894,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025060.png',
dn:'si64894',
visible:0,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1326,986],
vb:[-1,-1,1326,986]
},
si64913:{
name:'HawaiiZoningAtlas',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si64913c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si17283',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:50,
tiletype:0,
imageFocus:0,
irw:1325,
irh:985,
w:1325,
h:985,
x:0,
y:0
}
,
trin:0,
trout:0,
bstin:'si17293',
stl:[{
stn:'Normal',
stt:0,
stsi:[64913]
}
]
,
stis:0,
bstiid:17293,
sipst:14,
sicbs:true,
sihhs:true,
sihds:false,
baseItemIdForPropertyFlow:17293,
isDD:false
},
si64913c:{
b:[0,0,1325,985],
fh:false,
fw:false,
uid:64913,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025060.png',
dn:'si64913',
visible:0,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1326,986],
vb:[-1,-1,1326,986]
},
si17305:{
name:'Image_Group_Text_155',
type:1268,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17305c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17283',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si17313',
t:1250
}
,{
n:'si17323',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si17283',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si17305c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:17305,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17305',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si17313:{
name:'Text_397',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17313c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17305',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"4fv4r","text":"Hawaii Zoning Atlas","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":19,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":19,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":19,"style":"textOutlineEnable:false"},{"offset":0,"length":19,"style":"opacity:1"},{"offset":0,"length":19,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":19,"style":"hlnke:true"},{"offset":0,"length":19,"style":"defaultTextShadow:none"},{"offset":0,"length":19,"style":"backgroundColor:unset"},{"offset":0,"length":19,"style":"tablet-fontSize:36"},{"offset":0,"length":19,"style":"textShadowX:0px"},{"offset":0,"length":19,"style":"fontStretch:normal"},{"offset":0,"length":19,"style":"color:#333333"},{"offset":0,"length":19,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":19,"style":"textShadowY:4px"},{"offset":0,"length":19,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":19,"style":"lineHeight:135%"},{"offset":0,"length":19,"style":"letterSpacing:0%"},{"offset":0,"length":19,"style":"textHighlightEnable:false"},{"offset":0,"length":19,"style":"textTransform:none"},{"offset":0,"length":19,"style":"textShadowOpacity:none"},{"offset":0,"length":19,"style":"overridden:true"},{"offset":0,"length":19,"style":"textDecoration:none"},{"offset":0,"length":19,"style":"fontType:bold"},{"offset":0,"length":19,"style":"fontFamily:Georgia"},{"offset":0,"length":19,"style":"borderBottomStyle:none"},{"offset":0,"length":19,"style":"textShadowEnable:false"},{"offset":0,"length":19,"style":"hlnk:"},{"offset":0,"length":19,"style":"fontWeight:normal"},{"offset":0,"length":19,"style":"textShadowBlur:8px"},{"offset":0,"length":19,"style":"desktop-fontSize:36"},{"offset":0,"length":19,"style":"mobile-fontSize:20"},{"offset":0,"length":19,"style":"textShadow:none"},{"offset":0,"length":19,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":19,"style":"hlnkt:wp"},{"offset":0,"length":19,"style":"fontStyle:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-question-2","listSize":"100%"}},{"key":"bopkm","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-question-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17313]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17313c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:17313,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17313',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si17323:{
name:'Text_398',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17323c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17305',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"fjkv6","text":"This interactive map shows how outdated zoning laws make it hard to build diverse, affordable housing.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":102,"style":"textShadowBlur:8px"},{"offset":0,"length":102,"style":"backgroundColor:unset"},{"offset":0,"length":102,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":102,"style":"tablet-fontSize:30"},{"offset":0,"length":102,"style":"fontStyle:normal"},{"offset":0,"length":102,"style":"hlnkt:wp"},{"offset":0,"length":102,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":102,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":102,"style":"textOutlineEnable:false"},{"offset":0,"length":102,"style":"opacity:1"},{"offset":0,"length":102,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":102,"style":"hlnke:true"},{"offset":0,"length":102,"style":"defaultTextShadow:none"},{"offset":0,"length":102,"style":"textShadow:none"},{"offset":0,"length":102,"style":"mobile-fontSize:18"},{"offset":0,"length":102,"style":"textShadowX:0px"},{"offset":0,"length":102,"style":"fontStretch:normal"},{"offset":0,"length":102,"style":"fontType:regular"},{"offset":0,"length":102,"style":"color:#333333"},{"offset":0,"length":102,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":102,"style":"textShadowY:4px"},{"offset":0,"length":102,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":102,"style":"letterSpacing:0%"},{"offset":0,"length":102,"style":"textHighlightEnable:false"},{"offset":0,"length":102,"style":"textTransform:none"},{"offset":0,"length":102,"style":"textShadowOpacity:none"},{"offset":0,"length":102,"style":"overridden:true"},{"offset":0,"length":102,"style":"textDecoration:none"},{"offset":0,"length":102,"style":"desktop-fontSize:30"},{"offset":0,"length":102,"style":"lineHeight:130%"},{"offset":0,"length":102,"style":"fontFamily:Georgia"},{"offset":0,"length":102,"style":"borderBottomStyle:none"},{"offset":0,"length":102,"style":"textShadowEnable:false"},{"offset":0,"length":102,"style":"hlnk:"},{"offset":0,"length":102,"style":"fontWeight:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"4lsh8","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"59bun","text":"Project Focus","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":13,"style":"fontWeight:bold"},{"offset":0,"length":13,"style":"textShadowEnable:false"},{"offset":0,"length":13,"style":"hlnk:"},{"offset":0,"length":13,"style":"textShadowBlur:8px"},{"offset":0,"length":13,"style":"backgroundColor:unset"},{"offset":0,"length":13,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":13,"style":"tablet-fontSize:30"},{"offset":0,"length":13,"style":"fontStyle:normal"},{"offset":0,"length":13,"style":"hlnkt:wp"},{"offset":0,"length":13,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":13,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":13,"style":"textOutlineEnable:false"},{"offset":0,"length":13,"style":"opacity:1"},{"offset":0,"length":13,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":13,"style":"hlnke:true"},{"offset":0,"length":13,"style":"defaultTextShadow:none"},{"offset":0,"length":13,"style":"textShadow:none"},{"offset":0,"length":13,"style":"mobile-fontSize:18"},{"offset":0,"length":13,"style":"textShadowX:0px"},{"offset":0,"length":13,"style":"fontStretch:normal"},{"offset":0,"length":13,"style":"fontType:regular"},{"offset":0,"length":13,"style":"color:#333333"},{"offset":0,"length":13,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":13,"style":"textShadowY:4px"},{"offset":0,"length":13,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":13,"style":"letterSpacing:0%"},{"offset":0,"length":13,"style":"textHighlightEnable:false"},{"offset":0,"length":13,"style":"textTransform:none"},{"offset":0,"length":13,"style":"textShadowOpacity:none"},{"offset":0,"length":13,"style":"overridden:true"},{"offset":0,"length":13,"style":"textDecoration:none"},{"offset":0,"length":13,"style":"desktop-fontSize:30"},{"offset":0,"length":13,"style":"lineHeight:130%"},{"offset":0,"length":13,"style":"fontFamily:Georgia"},{"offset":0,"length":13,"style":"borderBottomStyle:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"6o9tb","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"24jba","text":"A zoning atlas that enables users to visualize the prevalence and nature of regulatory constraints, particularly on housing, can be an important tool to achieve that goal.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":171,"style":"lineHeight:130%"},{"offset":0,"length":171,"style":"fontFamily:Georgia"},{"offset":0,"length":171,"style":"borderBottomStyle:none"},{"offset":0,"length":171,"style":"textShadowEnable:false"},{"offset":0,"length":171,"style":"hlnk:"},{"offset":0,"length":171,"style":"fontWeight:normal"},{"offset":0,"length":171,"style":"textShadowBlur:8px"},{"offset":0,"length":171,"style":"backgroundColor:unset"},{"offset":0,"length":171,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":171,"style":"tablet-fontSize:30"},{"offset":0,"length":171,"style":"fontStyle:normal"},{"offset":0,"length":171,"style":"hlnkt:wp"},{"offset":0,"length":171,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":171,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":171,"style":"textOutlineEnable:false"},{"offset":0,"length":171,"style":"opacity:1"},{"offset":0,"length":171,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":171,"style":"hlnke:true"},{"offset":0,"length":171,"style":"defaultTextShadow:none"},{"offset":0,"length":171,"style":"textShadow:none"},{"offset":0,"length":171,"style":"mobile-fontSize:18"},{"offset":0,"length":171,"style":"textShadowX:0px"},{"offset":0,"length":171,"style":"fontStretch:normal"},{"offset":0,"length":171,"style":"fontType:regular"},{"offset":0,"length":171,"style":"color:#333333"},{"offset":0,"length":171,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":171,"style":"textShadowY:4px"},{"offset":0,"length":171,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":171,"style":"letterSpacing:0%"},{"offset":0,"length":171,"style":"textHighlightEnable:false"},{"offset":0,"length":171,"style":"textTransform:none"},{"offset":0,"length":171,"style":"textShadowOpacity:none"},{"offset":0,"length":171,"style":"overridden:true"},{"offset":0,"length":171,"style":"textDecoration:none"},{"offset":0,"length":171,"style":"desktop-fontSize:30"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"1n5hh","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"cmf0a","text":"Zoning laws, adopted by thousands of local governments across the country, dictate much of what can be built in the United States. We need to find better ways of helping people understand what zoning codes say, because they have a tremendous impact on our economy, on the environment, and on our society.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":304,"style":"overridden:true"},{"offset":0,"length":304,"style":"textDecoration:none"},{"offset":0,"length":304,"style":"desktop-fontSize:30"},{"offset":0,"length":304,"style":"lineHeight:130%"},{"offset":0,"length":304,"style":"fontFamily:Georgia"},{"offset":0,"length":304,"style":"borderBottomStyle:none"},{"offset":0,"length":304,"style":"textShadowEnable:false"},{"offset":0,"length":304,"style":"hlnk:"},{"offset":0,"length":304,"style":"fontWeight:normal"},{"offset":0,"length":304,"style":"textShadowBlur:8px"},{"offset":0,"length":304,"style":"backgroundColor:unset"},{"offset":0,"length":304,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":304,"style":"tablet-fontSize:30"},{"offset":0,"length":304,"style":"fontStyle:normal"},{"offset":0,"length":304,"style":"hlnkt:wp"},{"offset":0,"length":304,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":304,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":304,"style":"textOutlineEnable:false"},{"offset":0,"length":304,"style":"opacity:1"},{"offset":0,"length":304,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":304,"style":"hlnke:true"},{"offset":0,"length":304,"style":"defaultTextShadow:none"},{"offset":0,"length":304,"style":"textShadow:none"},{"offset":0,"length":304,"style":"mobile-fontSize:18"},{"offset":0,"length":304,"style":"textShadowX:0px"},{"offset":0,"length":304,"style":"fontStretch:normal"},{"offset":0,"length":304,"style":"fontType:regular"},{"offset":0,"length":304,"style":"color:#333333"},{"offset":0,"length":304,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":304,"style":"textShadowY:4px"},{"offset":0,"length":304,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":304,"style":"letterSpacing:0%"},{"offset":0,"length":304,"style":"textHighlightEnable:false"},{"offset":0,"length":304,"style":"textTransform:none"},{"offset":0,"length":304,"style":"textShadowOpacity:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"as5si","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"3qqf5","text":"TECH STACK","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"textTransform:none"},{"offset":0,"length":10,"style":"textShadowOpacity:none"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"desktop-fontSize:30"},{"offset":0,"length":10,"style":"lineHeight:130%"},{"offset":0,"length":10,"style":"fontFamily:Georgia"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"fontWeight:bold"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"textShadowBlur:8px"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"tablet-fontSize:30"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"defaultTextShadow:none"},{"offset":0,"length":10,"style":"textShadow:none"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"fontType:regular"},{"offset":0,"length":10,"style":"color:#333333"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"textShadowY:4px"},{"offset":0,"length":10,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":10,"style":"letterSpacing:0%"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"27edc","text":"------------------","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":18,"style":"textShadowY:4px"},{"offset":0,"length":18,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":18,"style":"letterSpacing:0%"},{"offset":0,"length":18,"style":"textHighlightEnable:false"},{"offset":0,"length":18,"style":"textTransform:none"},{"offset":0,"length":18,"style":"textShadowOpacity:none"},{"offset":0,"length":18,"style":"overridden:true"},{"offset":0,"length":18,"style":"textDecoration:none"},{"offset":0,"length":18,"style":"desktop-fontSize:30"},{"offset":0,"length":18,"style":"lineHeight:130%"},{"offset":0,"length":18,"style":"fontFamily:Georgia"},{"offset":0,"length":18,"style":"borderBottomStyle:none"},{"offset":0,"length":18,"style":"fontWeight:bold"},{"offset":0,"length":18,"style":"textShadowEnable:false"},{"offset":0,"length":18,"style":"hlnk:"},{"offset":0,"length":18,"style":"textShadowBlur:8px"},{"offset":0,"length":18,"style":"backgroundColor:unset"},{"offset":0,"length":18,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":18,"style":"tablet-fontSize:30"},{"offset":0,"length":18,"style":"fontStyle:normal"},{"offset":0,"length":18,"style":"hlnkt:wp"},{"offset":0,"length":18,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":18,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":18,"style":"textOutlineEnable:false"},{"offset":0,"length":18,"style":"opacity:1"},{"offset":0,"length":18,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":18,"style":"hlnke:true"},{"offset":0,"length":18,"style":"defaultTextShadow:none"},{"offset":0,"length":18,"style":"textShadow:none"},{"offset":0,"length":18,"style":"mobile-fontSize:18"},{"offset":0,"length":18,"style":"textShadowX:0px"},{"offset":0,"length":18,"style":"fontStretch:normal"},{"offset":0,"length":18,"style":"fontType:regular"},{"offset":0,"length":18,"style":"color:#333333"},{"offset":0,"length":18,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"5ek7c","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"9265h","text":"JavaScript","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"fontType:regular"},{"offset":0,"length":10,"style":"color:#333333"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"textShadowY:4px"},{"offset":0,"length":10,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":10,"style":"letterSpacing:0%"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"textTransform:none"},{"offset":0,"length":10,"style":"textShadowOpacity:none"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"desktop-fontSize:30"},{"offset":0,"length":10,"style":"lineHeight:130%"},{"offset":0,"length":10,"style":"fontFamily:Georgia"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"fontWeight:normal"},{"offset":0,"length":10,"style":"textShadowBlur:8px"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"tablet-fontSize:30"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"defaultTextShadow:none"},{"offset":0,"length":10,"style":"textShadow:none"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"9m204","text":"Jupyter Notebook / Python","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":25,"style":"mobile-fontSize:18"},{"offset":0,"length":25,"style":"textShadowX:0px"},{"offset":0,"length":25,"style":"fontStretch:normal"},{"offset":0,"length":25,"style":"fontType:regular"},{"offset":0,"length":25,"style":"color:#333333"},{"offset":0,"length":25,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":25,"style":"textShadowY:4px"},{"offset":0,"length":25,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":25,"style":"letterSpacing:0%"},{"offset":0,"length":25,"style":"textHighlightEnable:false"},{"offset":0,"length":25,"style":"textTransform:none"},{"offset":0,"length":25,"style":"textShadowOpacity:none"},{"offset":0,"length":25,"style":"overridden:true"},{"offset":0,"length":25,"style":"textDecoration:none"},{"offset":0,"length":25,"style":"desktop-fontSize:30"},{"offset":0,"length":25,"style":"lineHeight:130%"},{"offset":0,"length":25,"style":"fontFamily:Georgia"},{"offset":0,"length":25,"style":"borderBottomStyle:none"},{"offset":0,"length":25,"style":"textShadowEnable:false"},{"offset":0,"length":25,"style":"hlnk:"},{"offset":0,"length":25,"style":"fontWeight:normal"},{"offset":0,"length":25,"style":"textShadowBlur:8px"},{"offset":0,"length":25,"style":"backgroundColor:unset"},{"offset":0,"length":25,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":25,"style":"tablet-fontSize:30"},{"offset":0,"length":25,"style":"fontStyle:normal"},{"offset":0,"length":25,"style":"hlnkt:wp"},{"offset":0,"length":25,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":25,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":25,"style":"textOutlineEnable:false"},{"offset":0,"length":25,"style":"opacity:1"},{"offset":0,"length":25,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":25,"style":"hlnke:true"},{"offset":0,"length":25,"style":"defaultTextShadow:none"},{"offset":0,"length":25,"style":"textShadow:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"9o19b","text":"HTML","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"defaultTextShadow:none"},{"offset":0,"length":4,"style":"textShadow:none"},{"offset":0,"length":4,"style":"mobile-fontSize:18"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"fontStretch:normal"},{"offset":0,"length":4,"style":"fontType:regular"},{"offset":0,"length":4,"style":"color:#333333"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"textShadowY:4px"},{"offset":0,"length":4,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":4,"style":"letterSpacing:0%"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textTransform:none"},{"offset":0,"length":4,"style":"textShadowOpacity:none"},{"offset":0,"length":4,"style":"overridden:true"},{"offset":0,"length":4,"style":"textDecoration:none"},{"offset":0,"length":4,"style":"desktop-fontSize:30"},{"offset":0,"length":4,"style":"lineHeight:130%"},{"offset":0,"length":4,"style":"fontFamily:Georgia"},{"offset":0,"length":4,"style":"borderBottomStyle:none"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"fontWeight:normal"},{"offset":0,"length":4,"style":"textShadowBlur:8px"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":4,"style":"tablet-fontSize:30"},{"offset":0,"length":4,"style":"fontStyle:normal"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"defaultTextStrokeColor:#F1EEE6"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"fdj0a","text":"CSS","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":3,"style":"textOutlineEnable:false"},{"offset":0,"length":3,"style":"opacity:1"},{"offset":0,"length":3,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":3,"style":"hlnke:true"},{"offset":0,"length":3,"style":"defaultTextShadow:none"},{"offset":0,"length":3,"style":"textShadow:none"},{"offset":0,"length":3,"style":"mobile-fontSize:18"},{"offset":0,"length":3,"style":"textShadowX:0px"},{"offset":0,"length":3,"style":"fontStretch:normal"},{"offset":0,"length":3,"style":"fontType:regular"},{"offset":0,"length":3,"style":"color:#333333"},{"offset":0,"length":3,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":3,"style":"textShadowY:4px"},{"offset":0,"length":3,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":3,"style":"letterSpacing:0%"},{"offset":0,"length":3,"style":"textHighlightEnable:false"},{"offset":0,"length":3,"style":"textTransform:none"},{"offset":0,"length":3,"style":"textShadowOpacity:none"},{"offset":0,"length":3,"style":"overridden:true"},{"offset":0,"length":3,"style":"textDecoration:none"},{"offset":0,"length":3,"style":"desktop-fontSize:30"},{"offset":0,"length":3,"style":"lineHeight:130%"},{"offset":0,"length":3,"style":"fontFamily:Georgia"},{"offset":0,"length":3,"style":"borderBottomStyle:none"},{"offset":0,"length":3,"style":"textShadowEnable:false"},{"offset":0,"length":3,"style":"hlnk:"},{"offset":0,"length":3,"style":"fontWeight:normal"},{"offset":0,"length":3,"style":"textShadowBlur:8px"},{"offset":0,"length":3,"style":"backgroundColor:unset"},{"offset":0,"length":3,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":3,"style":"tablet-fontSize:30"},{"offset":0,"length":3,"style":"fontStyle:normal"},{"offset":0,"length":3,"style":"hlnkt:wp"},{"offset":0,"length":3,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":3,"style":"WebkitTextStrokeColor:#F1EEE6"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17323]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17323c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:17323,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17323',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si17333:{
name:'Button_261',
type:29,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17333c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8vkps","text":"HZA","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":3,"style":"textShadowX:0px"},{"offset":0,"length":3,"style":"textShadowY:0px"},{"offset":0,"length":3,"style":"fontStretch:normal"},{"offset":0,"length":3,"style":"fontType:regular"},{"offset":0,"length":3,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":3,"style":"color:#FFFFFF"},{"offset":0,"length":3,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":3,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":3,"style":"lineHeight:125%"},{"offset":0,"length":3,"style":"textShadowBlur:0px"},{"offset":0,"length":3,"style":"textHighlightEnable:false"},{"offset":0,"length":3,"style":"overridden:true"},{"offset":0,"length":3,"style":"textDecoration:none"},{"offset":0,"length":3,"style":"desktop-fontSize:30"},{"offset":0,"length":3,"style":"fontFamily:Georgia"},{"offset":0,"length":3,"style":"textTransform:uppercase"},{"offset":0,"length":3,"style":"borderBottomStyle:none"},{"offset":0,"length":3,"style":"textShadowEnable:false"},{"offset":0,"length":3,"style":"hlnk:"},{"offset":0,"length":3,"style":"fontWeight:normal"},{"offset":0,"length":3,"style":"fontStyle:normal"},{"offset":0,"length":3,"style":"letterSpacing:12%"},{"offset":0,"length":3,"style":"tablet-fontSize:30"},{"offset":0,"length":3,"style":"hlnkt:wp"},{"offset":0,"length":3,"style":"textOutlineEnable:false"},{"offset":0,"length":3,"style":"opacity:1"},{"offset":0,"length":3,"style":"mobile-fontSize:16"},{"offset":0,"length":3,"style":"textShadowColor:ffffff00"},{"offset":0,"length":3,"style":"hlnke:true"},{"offset":0,"length":3,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color7)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"#D6D5D1FF","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"70fbf","text":"HZA","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":3,"style":"textOutlineEnable:false"},{"offset":0,"length":3,"style":"opacity:1"},{"offset":0,"length":3,"style":"mobile-fontSize:16"},{"offset":0,"length":3,"style":"textShadowColor:ffffff00"},{"offset":0,"length":3,"style":"hlnke:true"},{"offset":0,"length":3,"style":"backgroundColor:unset"},{"offset":0,"length":3,"style":"textShadowX:0px"},{"offset":0,"length":3,"style":"textShadowY:0px"},{"offset":0,"length":3,"style":"fontStretch:normal"},{"offset":0,"length":3,"style":"fontType:regular"},{"offset":0,"length":3,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":3,"style":"color:#FFFFFF"},{"offset":0,"length":3,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":3,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":3,"style":"lineHeight:125%"},{"offset":0,"length":3,"style":"textShadowBlur:0px"},{"offset":0,"length":3,"style":"textHighlightEnable:false"},{"offset":0,"length":3,"style":"overridden:true"},{"offset":0,"length":3,"style":"textDecoration:none"},{"offset":0,"length":3,"style":"desktop-fontSize:30"},{"offset":0,"length":3,"style":"fontFamily:Georgia"},{"offset":0,"length":3,"style":"textTransform:uppercase"},{"offset":0,"length":3,"style":"borderBottomStyle:none"},{"offset":0,"length":3,"style":"textShadowEnable:false"},{"offset":0,"length":3,"style":"hlnk:"},{"offset":0,"length":3,"style":"fontWeight:normal"},{"offset":0,"length":3,"style":"fontStyle:normal"},{"offset":0,"length":3,"style":"letterSpacing:12%"},{"offset":0,"length":3,"style":"tablet-fontSize:30"},{"offset":0,"length":3,"style":"hlnkt:wp"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"var(--design-option-color5)"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"var(--design-option-color5)","dasharray":0,"enabled":true,"linecap":0,"width":2}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"BUTTON_ITEM_OPTION_3","designOptionStyles":{},"iconProps":{"srcPath":"060649.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7pv1a","text":"HZA","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":3,"style":"mobile-fontSize:16"},{"offset":0,"length":3,"style":"textShadowColor:ffffff00"},{"offset":0,"length":3,"style":"hlnke:true"},{"offset":0,"length":3,"style":"backgroundColor:unset"},{"offset":0,"length":3,"style":"textShadowX:0px"},{"offset":0,"length":3,"style":"textShadowY:0px"},{"offset":0,"length":3,"style":"fontStretch:normal"},{"offset":0,"length":3,"style":"fontType:regular"},{"offset":0,"length":3,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":3,"style":"color:#FFFFFF"},{"offset":0,"length":3,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":3,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":3,"style":"lineHeight:125%"},{"offset":0,"length":3,"style":"textShadowBlur:0px"},{"offset":0,"length":3,"style":"textHighlightEnable:false"},{"offset":0,"length":3,"style":"overridden:true"},{"offset":0,"length":3,"style":"textDecoration:none"},{"offset":0,"length":3,"style":"desktop-fontSize:30"},{"offset":0,"length":3,"style":"fontFamily:Georgia"},{"offset":0,"length":3,"style":"textTransform:uppercase"},{"offset":0,"length":3,"style":"borderBottomStyle:none"},{"offset":0,"length":3,"style":"textShadowEnable:false"},{"offset":0,"length":3,"style":"hlnk:"},{"offset":0,"length":3,"style":"fontWeight:normal"},{"offset":0,"length":3,"style":"fontStyle:normal"},{"offset":0,"length":3,"style":"letterSpacing:12%"},{"offset":0,"length":3,"style":"tablet-fontSize:30"},{"offset":0,"length":3,"style":"hlnkt:wp"},{"offset":0,"length":3,"style":"textOutlineEnable:false"},{"offset":0,"length":3,"style":"opacity:1"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"enabled":true,"color":"#D6D5D1FF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":1,"shadowX":1,"shadowY":2},"stroke":{"color":"#D6D5D1FF","dasharray":0,"enabled":false,"linecap":0,"width":2}},"overriddenProperties":["fillColor","strokeEnable","strokeColor"]},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2nclv","text":"HZA","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":3,"style":"tablet-fontSize:30"},{"offset":0,"length":3,"style":"hlnkt:wp"},{"offset":0,"length":3,"style":"textOutlineEnable:false"},{"offset":0,"length":3,"style":"opacity:1"},{"offset":0,"length":3,"style":"mobile-fontSize:16"},{"offset":0,"length":3,"style":"textShadowColor:ffffff00"},{"offset":0,"length":3,"style":"hlnke:true"},{"offset":0,"length":3,"style":"backgroundColor:unset"},{"offset":0,"length":3,"style":"textShadowX:0px"},{"offset":0,"length":3,"style":"textShadowY:0px"},{"offset":0,"length":3,"style":"fontStretch:normal"},{"offset":0,"length":3,"style":"fontType:regular"},{"offset":0,"length":3,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":3,"style":"color:#FFFFFF"},{"offset":0,"length":3,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":3,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":3,"style":"lineHeight:125%"},{"offset":0,"length":3,"style":"textShadowBlur:0px"},{"offset":0,"length":3,"style":"textHighlightEnable:false"},{"offset":0,"length":3,"style":"overridden:true"},{"offset":0,"length":3,"style":"textDecoration:none"},{"offset":0,"length":3,"style":"desktop-fontSize:30"},{"offset":0,"length":3,"style":"fontFamily:Georgia"},{"offset":0,"length":3,"style":"textTransform:uppercase"},{"offset":0,"length":3,"style":"borderBottomStyle:none"},{"offset":0,"length":3,"style":"textShadowEnable:false"},{"offset":0,"length":3,"style":"hlnk:"},{"offset":0,"length":3,"style":"fontWeight:normal"},{"offset":0,"length":3,"style":"fontStyle:normal"},{"offset":0,"length":3,"style":"letterSpacing:12%"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"appearenceProperties":{"fill":{"enabled":true,"color":"#666666FF"},"shadow":{"enabled":false,"shadowBlur":4,"shadowColor":"var(--color4)","shadowType":0,"shadowX":1,"shadowY":2},"stroke":{"color":"#D6D5D1FF","dasharray":0,"enabled":true,"linecap":0,"width":2}},"overriddenProperties":["fillColor"]},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cv040","text":"HZA","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":3,"style":"hlnke:true"},{"offset":0,"length":3,"style":"backgroundColor:unset"},{"offset":0,"length":3,"style":"textShadowX:0px"},{"offset":0,"length":3,"style":"textShadowY:0px"},{"offset":0,"length":3,"style":"fontStretch:normal"},{"offset":0,"length":3,"style":"fontType:regular"},{"offset":0,"length":3,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":3,"style":"color:#666666"},{"offset":0,"length":3,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":3,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":3,"style":"lineHeight:125%"},{"offset":0,"length":3,"style":"textShadowBlur:0px"},{"offset":0,"length":3,"style":"textHighlightEnable:false"},{"offset":0,"length":3,"style":"overridden:true"},{"offset":0,"length":3,"style":"textDecoration:none"},{"offset":0,"length":3,"style":"desktop-fontSize:30"},{"offset":0,"length":3,"style":"fontFamily:Georgia"},{"offset":0,"length":3,"style":"textTransform:uppercase"},{"offset":0,"length":3,"style":"borderBottomStyle:none"},{"offset":0,"length":3,"style":"textShadowEnable:false"},{"offset":0,"length":3,"style":"hlnk:"},{"offset":0,"length":3,"style":"fontWeight:normal"},{"offset":0,"length":3,"style":"fontStyle:normal"},{"offset":0,"length":3,"style":"letterSpacing:12%"},{"offset":0,"length":3,"style":"tablet-fontSize:30"},{"offset":0,"length":3,"style":"hlnkt:wp"},{"offset":0,"length":3,"style":"textOutlineEnable:false"},{"offset":0,"length":3,"style":"opacity:1"},{"offset":0,"length":3,"style":"mobile-fontSize:16"},{"offset":0,"length":3,"style":"textShadowColor:ffffff00"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si17283',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.openURL(\\"https://github.com/CodeWithAloha/Hawaii-Zoning-Atlas\\",\\"_blank\\");"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17333]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17333c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:17333,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17333',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si17349:{
name:'Image_Grid_Group_116',
type:1268,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17349c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-button":true},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-button":"CENTER"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"order":3},"tablet":{},"mobile":{}}}}',
parentGroup:'si17275',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si17359',
t:15
}
,{
n:'si17371',
t:1268
}
,{
n:'si17399',
t:29
}
]
,
containerType:'image-grid-card',
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"card":true,"slide-item-button":true},"padding":{"top":10,"bottom":10,"left":10,"right":10},"alignment":{"slide-item-image":"CENTER","slide-item-caption":"CENTER","slide-item-subtitle":"CENTER","slide-item-button":"CENTER"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":true,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"order":3},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si17275',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si17349c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:17349,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17349',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si17359:{
name:'HIERR',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17359c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si17349',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.openURL(\\"https://hierr.online/\\",\\"_blank\\");"]]}]}',
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1126,
irh:873,
w:1126,
h:873,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:64945,
stt:0,
dsr:'Default_State',
stsi:[17359]
}
,{
stn:64946,
stt:2,
dsr:'Hover',
stsi:[64947]
}
,{
stn:64965,
stt:10,
dsr:'Visited',
stsi:[64966]
}
,{
stn:64984,
stt:13,
dsr:'Selected',
stsi:[64985]
}
,{
stn:65003,
stt:14,
dsr:'Disabled',
stsi:[65004]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:true,
sihds:false,
stc:['si17359','si64947','si64966','si64985','si65004'],
siq:false,
isDD:false
},
si17359c:{
b:[0,0,1126,873],
fh:false,
fw:false,
uid:17359,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025063.png',
dn:'si17359',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1127,874],
vb:[-1,-1,1127,874]
},
si64947:{
name:'HIERR',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si64947c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_lighten',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}},"imgStateStyle":{"transformOrigin":"center","transform":"scale(1.05)","transition":"all .5s"}}',
parentGroup:'si17349',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'soft-light',
ift:'Lighten',
ifi:80,
iff:{
bc:'#ffffff',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1126,
irh:873,
w:1126,
h:873,
x:0,
y:0
}
,
trin:0,
trout:0,
bstin:'si17359',
stl:[{
stn:'Normal',
stt:0,
stsi:[64947]
}
]
,
stis:0,
bstiid:17359,
sipst:2,
sicbs:true,
sihhs:true,
sihds:false,
baseItemIdForPropertyFlow:17359,
isDD:false
},
si64947c:{
b:[0,0,1126,873],
fh:false,
fw:false,
uid:64947,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025063.png',
dn:'si64947',
visible:0,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1127,874],
vb:[-1,-1,1127,874]
},
si64966:{
name:'HIERR',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si64966c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_greyscale',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si17349',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:15,
c:15,
br:0,
ifbm:'saturation',
ift:'Greyscale',
ifi:0,
iff:{
bc:'#000000',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1126,
irh:873,
w:1126,
h:873,
x:0,
y:0
}
,
trin:0,
trout:0,
bstin:'si17359',
stl:[{
stn:'Normal',
stt:0,
stsi:[64966]
}
]
,
stis:0,
bstiid:17359,
sipst:10,
sicbs:true,
sihhs:true,
sihds:false,
baseItemIdForPropertyFlow:17359,
isDD:false
},
si64966c:{
b:[0,0,1126,873],
fh:false,
fw:false,
uid:64966,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025063.png',
dn:'si64966',
visible:0,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1127,874],
vb:[-1,-1,1127,874]
},
si64985:{
name:'HIERR',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si64985c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_overlay',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}},"imgStateStyle":{"transformOrigin":"center","transform":"scale(1.025)","transition":"all .5s"}}',
parentGroup:'si17349',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'overlay',
ift:'Overlay',
ifi:65,
iff:{
bc:'#000000',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1126,
irh:873,
w:1126,
h:873,
x:0,
y:0
}
,
trin:0,
trout:0,
bstin:'si17359',
stl:[{
stn:'Normal',
stt:0,
stsi:[64985]
}
]
,
stis:0,
bstiid:17359,
sipst:13,
sicbs:true,
sihhs:true,
sihds:false,
baseItemIdForPropertyFlow:17359,
isDD:false
},
si64985c:{
b:[0,0,1126,873],
fh:false,
fw:false,
uid:64985,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025063.png',
dn:'si64985',
visible:0,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1127,874],
vb:[-1,-1,1127,874]
},
si65004:{
name:'HIERR',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si65004c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si17349',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:50,
tiletype:0,
imageFocus:0,
irw:1126,
irh:873,
w:1126,
h:873,
x:0,
y:0
}
,
trin:0,
trout:0,
bstin:'si17359',
stl:[{
stn:'Normal',
stt:0,
stsi:[65004]
}
]
,
stis:0,
bstiid:17359,
sipst:14,
sicbs:true,
sihhs:true,
sihds:false,
baseItemIdForPropertyFlow:17359,
isDD:false
},
si65004c:{
b:[0,0,1126,873],
fh:false,
fw:false,
uid:65004,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025063.png',
dn:'si65004',
visible:0,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1127,874],
vb:[-1,-1,1127,874]
},
si17371:{
name:'Image_Group_Text_156',
type:1268,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17371c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17349',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si17379',
t:1250
}
,{
n:'si17389',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si17349',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si17371c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:17371,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17371',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si17379:{
name:'Text_399',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17379c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17371',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5f0ae","text":"Hawaiʻi Economic Recovery & Resilience","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":38,"style":"fontStretch:normal"},{"offset":0,"length":38,"style":"color:#333333"},{"offset":0,"length":38,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":38,"style":"textShadowY:4px"},{"offset":0,"length":38,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":38,"style":"lineHeight:135%"},{"offset":0,"length":38,"style":"letterSpacing:0%"},{"offset":0,"length":38,"style":"textHighlightEnable:false"},{"offset":0,"length":38,"style":"textTransform:none"},{"offset":0,"length":38,"style":"textShadowOpacity:none"},{"offset":0,"length":38,"style":"overridden:true"},{"offset":0,"length":38,"style":"textDecoration:none"},{"offset":0,"length":38,"style":"fontType:bold"},{"offset":0,"length":38,"style":"fontFamily:Georgia"},{"offset":0,"length":38,"style":"borderBottomStyle:none"},{"offset":0,"length":38,"style":"textShadowEnable:false"},{"offset":0,"length":38,"style":"hlnk:"},{"offset":0,"length":38,"style":"fontWeight:normal"},{"offset":0,"length":38,"style":"textShadowBlur:8px"},{"offset":0,"length":38,"style":"desktop-fontSize:36"},{"offset":0,"length":38,"style":"mobile-fontSize:20"},{"offset":0,"length":38,"style":"textShadow:none"},{"offset":0,"length":38,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":38,"style":"hlnkt:wp"},{"offset":0,"length":38,"style":"fontStyle:normal"},{"offset":0,"length":38,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":38,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":38,"style":"textOutlineEnable:false"},{"offset":0,"length":38,"style":"opacity:1"},{"offset":0,"length":38,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":38,"style":"hlnke:true"},{"offset":0,"length":38,"style":"defaultTextShadow:none"},{"offset":0,"length":38,"style":"backgroundColor:unset"},{"offset":0,"length":38,"style":"tablet-fontSize:36"},{"offset":0,"length":38,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-question-2","listSize":"100%"}},{"key":"4gtis","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-question-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17379]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17379c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:17379,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17379',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si17389:{
name:'Text_400',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17389c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17371',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"10ffk","text":"The HIERR Project aims to enable actions toward a more resilient, equitable, and sustainable economy. ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":102,"style":"defaultTextShadow:none"},{"offset":0,"length":102,"style":"textShadow:none"},{"offset":0,"length":102,"style":"mobile-fontSize:18"},{"offset":0,"length":102,"style":"textShadowX:0px"},{"offset":0,"length":102,"style":"fontStretch:normal"},{"offset":0,"length":102,"style":"fontType:regular"},{"offset":0,"length":102,"style":"color:#333333"},{"offset":0,"length":102,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":102,"style":"textShadowY:4px"},{"offset":0,"length":102,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":102,"style":"letterSpacing:0%"},{"offset":0,"length":102,"style":"textHighlightEnable:false"},{"offset":0,"length":102,"style":"textTransform:none"},{"offset":0,"length":102,"style":"textShadowOpacity:none"},{"offset":0,"length":102,"style":"overridden:true"},{"offset":0,"length":102,"style":"textDecoration:none"},{"offset":0,"length":102,"style":"desktop-fontSize:30"},{"offset":0,"length":102,"style":"lineHeight:130%"},{"offset":0,"length":102,"style":"fontFamily:Georgia"},{"offset":0,"length":102,"style":"borderBottomStyle:none"},{"offset":0,"length":102,"style":"textShadowEnable:false"},{"offset":0,"length":102,"style":"hlnk:"},{"offset":0,"length":102,"style":"fontWeight:normal"},{"offset":0,"length":102,"style":"textShadowBlur:8px"},{"offset":0,"length":102,"style":"backgroundColor:unset"},{"offset":0,"length":102,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":102,"style":"tablet-fontSize:30"},{"offset":0,"length":102,"style":"fontStyle:normal"},{"offset":0,"length":102,"style":"hlnkt:wp"},{"offset":0,"length":102,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":102,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":102,"style":"textOutlineEnable:false"},{"offset":0,"length":102,"style":"opacity:1"},{"offset":0,"length":102,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":102,"style":"hlnke:true"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"2l815","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"9f1d8","text":"This planning process is designed to learn from the economic impacts and experiences of hardship associated with the COVID-19 pandemic.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":135,"style":"opacity:1"},{"offset":0,"length":135,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":135,"style":"hlnke:true"},{"offset":0,"length":135,"style":"defaultTextShadow:none"},{"offset":0,"length":135,"style":"textShadow:none"},{"offset":0,"length":135,"style":"mobile-fontSize:18"},{"offset":0,"length":135,"style":"textShadowX:0px"},{"offset":0,"length":135,"style":"fontStretch:normal"},{"offset":0,"length":135,"style":"fontType:regular"},{"offset":0,"length":135,"style":"color:#333333"},{"offset":0,"length":135,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":135,"style":"textShadowY:4px"},{"offset":0,"length":135,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":135,"style":"letterSpacing:0%"},{"offset":0,"length":135,"style":"textHighlightEnable:false"},{"offset":0,"length":135,"style":"textTransform:none"},{"offset":0,"length":135,"style":"textShadowOpacity:none"},{"offset":0,"length":135,"style":"overridden:true"},{"offset":0,"length":135,"style":"textDecoration:none"},{"offset":0,"length":135,"style":"desktop-fontSize:30"},{"offset":0,"length":135,"style":"lineHeight:130%"},{"offset":0,"length":135,"style":"fontFamily:Georgia"},{"offset":0,"length":135,"style":"borderBottomStyle:none"},{"offset":0,"length":135,"style":"textShadowEnable:false"},{"offset":0,"length":135,"style":"hlnk:"},{"offset":0,"length":135,"style":"fontWeight:normal"},{"offset":0,"length":135,"style":"textShadowBlur:8px"},{"offset":0,"length":135,"style":"backgroundColor:unset"},{"offset":0,"length":135,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":135,"style":"tablet-fontSize:30"},{"offset":0,"length":135,"style":"fontStyle:normal"},{"offset":0,"length":135,"style":"hlnkt:wp"},{"offset":0,"length":135,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":135,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":135,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"cm6ev","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"2ubbe","text":"Project Focus","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":13,"style":"hlnkt:wp"},{"offset":0,"length":13,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":13,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":13,"style":"textOutlineEnable:false"},{"offset":0,"length":13,"style":"opacity:1"},{"offset":0,"length":13,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":13,"style":"hlnke:true"},{"offset":0,"length":13,"style":"defaultTextShadow:none"},{"offset":0,"length":13,"style":"textShadow:none"},{"offset":0,"length":13,"style":"mobile-fontSize:18"},{"offset":0,"length":13,"style":"textShadowX:0px"},{"offset":0,"length":13,"style":"fontStretch:normal"},{"offset":0,"length":13,"style":"fontType:regular"},{"offset":0,"length":13,"style":"color:#333333"},{"offset":0,"length":13,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":13,"style":"textShadowY:4px"},{"offset":0,"length":13,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":13,"style":"letterSpacing:0%"},{"offset":0,"length":13,"style":"textHighlightEnable:false"},{"offset":0,"length":13,"style":"textTransform:none"},{"offset":0,"length":13,"style":"textShadowOpacity:none"},{"offset":0,"length":13,"style":"overridden:true"},{"offset":0,"length":13,"style":"textDecoration:none"},{"offset":0,"length":13,"style":"desktop-fontSize:30"},{"offset":0,"length":13,"style":"lineHeight:130%"},{"offset":0,"length":13,"style":"fontFamily:Georgia"},{"offset":0,"length":13,"style":"borderBottomStyle:none"},{"offset":0,"length":13,"style":"fontWeight:bold"},{"offset":0,"length":13,"style":"textShadowEnable:false"},{"offset":0,"length":13,"style":"hlnk:"},{"offset":0,"length":13,"style":"textShadowBlur:8px"},{"offset":0,"length":13,"style":"backgroundColor:unset"},{"offset":0,"length":13,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":13,"style":"tablet-fontSize:30"},{"offset":0,"length":13,"style":"fontStyle:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"5ks1v","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"dka7m","text":"The main portion of this project being work on is using Pol.is to gather opinions from Hawaii residents about the state\'s economic future. ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":139,"style":"textShadowBlur:8px"},{"offset":0,"length":139,"style":"backgroundColor:unset"},{"offset":0,"length":139,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":139,"style":"tablet-fontSize:30"},{"offset":0,"length":139,"style":"fontStyle:normal"},{"offset":0,"length":139,"style":"hlnkt:wp"},{"offset":0,"length":139,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":139,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":139,"style":"textOutlineEnable:false"},{"offset":0,"length":139,"style":"opacity:1"},{"offset":0,"length":139,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":139,"style":"hlnke:true"},{"offset":0,"length":139,"style":"defaultTextShadow:none"},{"offset":0,"length":139,"style":"textShadow:none"},{"offset":0,"length":139,"style":"mobile-fontSize:18"},{"offset":0,"length":139,"style":"textShadowX:0px"},{"offset":0,"length":139,"style":"fontStretch:normal"},{"offset":0,"length":139,"style":"fontType:regular"},{"offset":0,"length":139,"style":"color:#333333"},{"offset":0,"length":139,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":139,"style":"textShadowY:4px"},{"offset":0,"length":139,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":139,"style":"letterSpacing:0%"},{"offset":0,"length":139,"style":"textHighlightEnable:false"},{"offset":0,"length":139,"style":"textTransform:none"},{"offset":0,"length":139,"style":"textShadowOpacity:none"},{"offset":0,"length":139,"style":"overridden:true"},{"offset":0,"length":139,"style":"textDecoration:none"},{"offset":0,"length":139,"style":"desktop-fontSize:30"},{"offset":0,"length":139,"style":"lineHeight:130%"},{"offset":0,"length":139,"style":"fontFamily:Georgia"},{"offset":0,"length":139,"style":"borderBottomStyle:none"},{"offset":0,"length":139,"style":"textShadowEnable:false"},{"offset":0,"length":139,"style":"hlnk:"},{"offset":0,"length":139,"style":"fontWeight:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"bnbvo","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"fgrtv","text":"Pol.is will allow people to share their thoughts on existing and new ideas about Hawaii.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":88,"style":"textShadowEnable:false"},{"offset":0,"length":88,"style":"hlnk:"},{"offset":0,"length":88,"style":"fontWeight:normal"},{"offset":0,"length":88,"style":"textShadowBlur:8px"},{"offset":0,"length":88,"style":"backgroundColor:unset"},{"offset":0,"length":88,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":88,"style":"tablet-fontSize:30"},{"offset":0,"length":88,"style":"fontStyle:normal"},{"offset":0,"length":88,"style":"hlnkt:wp"},{"offset":0,"length":88,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":88,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":88,"style":"textOutlineEnable:false"},{"offset":0,"length":88,"style":"opacity:1"},{"offset":0,"length":88,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":88,"style":"hlnke:true"},{"offset":0,"length":88,"style":"defaultTextShadow:none"},{"offset":0,"length":88,"style":"textShadow:none"},{"offset":0,"length":88,"style":"mobile-fontSize:18"},{"offset":0,"length":88,"style":"textShadowX:0px"},{"offset":0,"length":88,"style":"fontStretch:normal"},{"offset":0,"length":88,"style":"fontType:regular"},{"offset":0,"length":88,"style":"color:#333333"},{"offset":0,"length":88,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":88,"style":"textShadowY:4px"},{"offset":0,"length":88,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":88,"style":"letterSpacing:0%"},{"offset":0,"length":88,"style":"textHighlightEnable:false"},{"offset":0,"length":88,"style":"textTransform:none"},{"offset":0,"length":88,"style":"textShadowOpacity:none"},{"offset":0,"length":88,"style":"overridden:true"},{"offset":0,"length":88,"style":"textDecoration:none"},{"offset":0,"length":88,"style":"desktop-fontSize:30"},{"offset":0,"length":88,"style":"lineHeight:130%"},{"offset":0,"length":88,"style":"fontFamily:Georgia"},{"offset":0,"length":88,"style":"borderBottomStyle:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"5g3ff","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"59idr","text":"TECH STACK","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":10,"style":"lineHeight:130%"},{"offset":0,"length":10,"style":"fontFamily:Georgia"},{"offset":0,"length":10,"style":"borderBottomStyle:none"},{"offset":0,"length":10,"style":"fontWeight:bold"},{"offset":0,"length":10,"style":"textShadowEnable:false"},{"offset":0,"length":10,"style":"hlnk:"},{"offset":0,"length":10,"style":"textShadowBlur:8px"},{"offset":0,"length":10,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"backgroundColor:unset"},{"offset":0,"length":10,"style":"fontStyle:normal"},{"offset":0,"length":10,"style":"tablet-fontSize:30"},{"offset":0,"length":10,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":10,"style":"hlnkt:wp"},{"offset":0,"length":10,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"textOutlineEnable:false"},{"offset":0,"length":10,"style":"opacity:1"},{"offset":0,"length":10,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":10,"style":"hlnke:true"},{"offset":0,"length":10,"style":"defaultTextShadow:none"},{"offset":0,"length":10,"style":"textShadow:none"},{"offset":0,"length":10,"style":"mobile-fontSize:18"},{"offset":0,"length":10,"style":"textShadowX:0px"},{"offset":0,"length":10,"style":"fontStretch:normal"},{"offset":0,"length":10,"style":"fontType:regular"},{"offset":0,"length":10,"style":"color:#333333"},{"offset":0,"length":10,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":10,"style":"textShadowY:4px"},{"offset":0,"length":10,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":10,"style":"letterSpacing:0%"},{"offset":0,"length":10,"style":"textHighlightEnable:false"},{"offset":0,"length":10,"style":"textTransform:none"},{"offset":0,"length":10,"style":"textShadowOpacity:none"},{"offset":0,"length":10,"style":"overridden:true"},{"offset":0,"length":10,"style":"textDecoration:none"},{"offset":0,"length":10,"style":"desktop-fontSize:30"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"17hqk","text":"------------------","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":18,"style":"overridden:true"},{"offset":0,"length":18,"style":"textDecoration:none"},{"offset":0,"length":18,"style":"desktop-fontSize:30"},{"offset":0,"length":18,"style":"lineHeight:130%"},{"offset":0,"length":18,"style":"fontFamily:Georgia"},{"offset":0,"length":18,"style":"borderBottomStyle:none"},{"offset":0,"length":18,"style":"fontWeight:bold"},{"offset":0,"length":18,"style":"textShadowEnable:false"},{"offset":0,"length":18,"style":"hlnk:"},{"offset":0,"length":18,"style":"textShadowBlur:8px"},{"offset":0,"length":18,"style":"backgroundColor:unset"},{"offset":0,"length":18,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":18,"style":"tablet-fontSize:30"},{"offset":0,"length":18,"style":"fontStyle:normal"},{"offset":0,"length":18,"style":"hlnkt:wp"},{"offset":0,"length":18,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":18,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":18,"style":"textOutlineEnable:false"},{"offset":0,"length":18,"style":"opacity:1"},{"offset":0,"length":18,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":18,"style":"hlnke:true"},{"offset":0,"length":18,"style":"defaultTextShadow:none"},{"offset":0,"length":18,"style":"textShadow:none"},{"offset":0,"length":18,"style":"mobile-fontSize:18"},{"offset":0,"length":18,"style":"textShadowX:0px"},{"offset":0,"length":18,"style":"fontStretch:normal"},{"offset":0,"length":18,"style":"fontType:regular"},{"offset":0,"length":18,"style":"color:#333333"},{"offset":0,"length":18,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":18,"style":"textShadowY:4px"},{"offset":0,"length":18,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":18,"style":"letterSpacing:0%"},{"offset":0,"length":18,"style":"textHighlightEnable:false"},{"offset":0,"length":18,"style":"textTransform:none"},{"offset":0,"length":18,"style":"textShadowOpacity:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"3ruk","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"djab2","text":"TypeScript / JavaScript","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":23,"style":"textHighlightEnable:false"},{"offset":0,"length":23,"style":"textTransform:none"},{"offset":0,"length":23,"style":"textShadowOpacity:none"},{"offset":0,"length":23,"style":"overridden:true"},{"offset":0,"length":23,"style":"textDecoration:none"},{"offset":0,"length":23,"style":"desktop-fontSize:30"},{"offset":0,"length":23,"style":"lineHeight:130%"},{"offset":0,"length":23,"style":"fontFamily:Georgia"},{"offset":0,"length":23,"style":"borderBottomStyle:none"},{"offset":0,"length":23,"style":"textShadowEnable:false"},{"offset":0,"length":23,"style":"hlnk:"},{"offset":0,"length":23,"style":"fontWeight:normal"},{"offset":0,"length":23,"style":"textShadowBlur:8px"},{"offset":0,"length":23,"style":"backgroundColor:unset"},{"offset":0,"length":23,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":23,"style":"tablet-fontSize:30"},{"offset":0,"length":23,"style":"fontStyle:normal"},{"offset":0,"length":23,"style":"hlnkt:wp"},{"offset":0,"length":23,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":23,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":23,"style":"textOutlineEnable:false"},{"offset":0,"length":23,"style":"opacity:1"},{"offset":0,"length":23,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":23,"style":"hlnke:true"},{"offset":0,"length":23,"style":"defaultTextShadow:none"},{"offset":0,"length":23,"style":"textShadow:none"},{"offset":0,"length":23,"style":"mobile-fontSize:18"},{"offset":0,"length":23,"style":"textShadowX:0px"},{"offset":0,"length":23,"style":"fontStretch:normal"},{"offset":0,"length":23,"style":"fontType:regular"},{"offset":0,"length":23,"style":"color:#333333"},{"offset":0,"length":23,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":23,"style":"textShadowY:4px"},{"offset":0,"length":23,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":23,"style":"letterSpacing:0%"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"b0d6b","text":"TSQL","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"textShadowY:4px"},{"offset":0,"length":4,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":4,"style":"letterSpacing:0%"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textTransform:none"},{"offset":0,"length":4,"style":"textShadowOpacity:none"},{"offset":0,"length":4,"style":"overridden:true"},{"offset":0,"length":4,"style":"textDecoration:none"},{"offset":0,"length":4,"style":"desktop-fontSize:30"},{"offset":0,"length":4,"style":"lineHeight:130%"},{"offset":0,"length":4,"style":"fontFamily:Georgia"},{"offset":0,"length":4,"style":"borderBottomStyle:none"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"fontWeight:normal"},{"offset":0,"length":4,"style":"textShadowBlur:8px"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":4,"style":"tablet-fontSize:30"},{"offset":0,"length":4,"style":"fontStyle:normal"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"defaultTextShadow:none"},{"offset":0,"length":4,"style":"textShadow:none"},{"offset":0,"length":4,"style":"mobile-fontSize:18"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"fontStretch:normal"},{"offset":0,"length":4,"style":"fontType:regular"},{"offset":0,"length":4,"style":"color:#333333"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"5s3r0","text":"CSS","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":3,"style":"fontType:regular"},{"offset":0,"length":3,"style":"color:#333333"},{"offset":0,"length":3,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":3,"style":"textShadowY:4px"},{"offset":0,"length":3,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":3,"style":"letterSpacing:0%"},{"offset":0,"length":3,"style":"textHighlightEnable:false"},{"offset":0,"length":3,"style":"textTransform:none"},{"offset":0,"length":3,"style":"textShadowOpacity:none"},{"offset":0,"length":3,"style":"overridden:true"},{"offset":0,"length":3,"style":"textDecoration:none"},{"offset":0,"length":3,"style":"desktop-fontSize:30"},{"offset":0,"length":3,"style":"lineHeight:130%"},{"offset":0,"length":3,"style":"fontFamily:Georgia"},{"offset":0,"length":3,"style":"borderBottomStyle:none"},{"offset":0,"length":3,"style":"textShadowEnable:false"},{"offset":0,"length":3,"style":"hlnk:"},{"offset":0,"length":3,"style":"fontWeight:normal"},{"offset":0,"length":3,"style":"textShadowBlur:8px"},{"offset":0,"length":3,"style":"backgroundColor:unset"},{"offset":0,"length":3,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":3,"style":"tablet-fontSize:30"},{"offset":0,"length":3,"style":"fontStyle:normal"},{"offset":0,"length":3,"style":"hlnkt:wp"},{"offset":0,"length":3,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":3,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":3,"style":"textOutlineEnable:false"},{"offset":0,"length":3,"style":"opacity:1"},{"offset":0,"length":3,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":3,"style":"hlnke:true"},{"offset":0,"length":3,"style":"defaultTextShadow:none"},{"offset":0,"length":3,"style":"textShadow:none"},{"offset":0,"length":3,"style":"mobile-fontSize:18"},{"offset":0,"length":3,"style":"textShadowX:0px"},{"offset":0,"length":3,"style":"fontStretch:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}},{"key":"7l76g","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17389]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17389c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:17389,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17389',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si17399:{
name:'Button_262',
type:29,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17399c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dm0fp","text":"HIERR","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"overridden:true"},{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"desktop-fontSize:30"},{"offset":0,"length":5,"style":"fontFamily:Georgia"},{"offset":0,"length":5,"style":"textTransform:uppercase"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"fontWeight:normal"},{"offset":0,"length":5,"style":"fontStyle:normal"},{"offset":0,"length":5,"style":"letterSpacing:12%"},{"offset":0,"length":5,"style":"tablet-fontSize:30"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"mobile-fontSize:16"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"},{"offset":0,"length":5,"style":"fontType:regular"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"color:#FFFFFF"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"lineHeight:125%"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"color":"#020C1CFF"},"shadow":{},"stroke":{"enabled":true,"color":"#D6D5D1FF"}}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9ag7g","text":"HIERR","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"fontType:regular"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"color:#FFFFFF"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"lineHeight:125%"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"overridden:true"},{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"desktop-fontSize:30"},{"offset":0,"length":5,"style":"fontFamily:Georgia"},{"offset":0,"length":5,"style":"textTransform:uppercase"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"fontWeight:normal"},{"offset":0,"length":5,"style":"fontStyle:normal"},{"offset":0,"length":5,"style":"letterSpacing:12%"},{"offset":0,"length":5,"style":"tablet-fontSize:30"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"mobile-fontSize:16"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{},"shadow":{},"stroke":{"enabled":true}}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0472.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"fcaue","text":"HIERR","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"color:#FFFFFF"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"lineHeight:125%"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"overridden:true"},{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"desktop-fontSize:30"},{"offset":0,"length":5,"style":"fontFamily:Georgia"},{"offset":0,"length":5,"style":"textTransform:uppercase"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"fontWeight:normal"},{"offset":0,"length":5,"style":"fontStyle:normal"},{"offset":0,"length":5,"style":"letterSpacing:12%"},{"offset":0,"length":5,"style":"tablet-fontSize:30"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"mobile-fontSize:16"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"},{"offset":0,"length":5,"style":"fontType:regular"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{"color":"#D6D5D1FF"},"shadow":{},"stroke":{"enabled":false}},"overriddenProperties":["strokeEnable","fillColor"]},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ffvhk","text":"HIERR","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"},{"offset":0,"length":5,"style":"fontType:regular"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"color:#FFFFFF"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"lineHeight:125%"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"overridden:true"},{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"desktop-fontSize:30"},{"offset":0,"length":5,"style":"fontFamily:Georgia"},{"offset":0,"length":5,"style":"textTransform:uppercase"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"fontWeight:normal"},{"offset":0,"length":5,"style":"fontStyle:normal"},{"offset":0,"length":5,"style":"letterSpacing:12%"},{"offset":0,"length":5,"style":"tablet-fontSize:30"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"mobile-fontSize:16"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true},"overriddenProperties":["fillColor"],"appearenceProperties":{"fill":{"color":"#666666FF"},"shadow":{},"stroke":{"enabled":true}}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4tn54","text":"HIERR","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":5,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":5,"style":"lineHeight:125%"},{"offset":0,"length":5,"style":"textShadowBlur:0px"},{"offset":0,"length":5,"style":"textHighlightEnable:false"},{"offset":0,"length":5,"style":"overridden:true"},{"offset":0,"length":5,"style":"textDecoration:none"},{"offset":0,"length":5,"style":"desktop-fontSize:30"},{"offset":0,"length":5,"style":"fontFamily:Georgia"},{"offset":0,"length":5,"style":"textTransform:uppercase"},{"offset":0,"length":5,"style":"borderBottomStyle:none"},{"offset":0,"length":5,"style":"textShadowEnable:false"},{"offset":0,"length":5,"style":"hlnk:"},{"offset":0,"length":5,"style":"fontWeight:normal"},{"offset":0,"length":5,"style":"fontStyle:normal"},{"offset":0,"length":5,"style":"letterSpacing:12%"},{"offset":0,"length":5,"style":"tablet-fontSize:30"},{"offset":0,"length":5,"style":"hlnkt:wp"},{"offset":0,"length":5,"style":"textOutlineEnable:false"},{"offset":0,"length":5,"style":"opacity:1"},{"offset":0,"length":5,"style":"mobile-fontSize:16"},{"offset":0,"length":5,"style":"textShadowColor:ffffff00"},{"offset":0,"length":5,"style":"hlnke:true"},{"offset":0,"length":5,"style":"backgroundColor:unset"},{"offset":0,"length":5,"style":"textShadowX:0px"},{"offset":0,"length":5,"style":"textShadowY:0px"},{"offset":0,"length":5,"style":"fontStretch:normal"},{"offset":0,"length":5,"style":"fontType:regular"},{"offset":0,"length":5,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":5,"style":"color:#666666"},{"offset":0,"length":5,"style":"defaultBackgroundColor:#E8D01B"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"true","textAlign":"center"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false},"appearenceProperties":{"fill":{},"shadow":{},"stroke":{"enabled":true}}}}',
parentGroup:'si17349',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.openURL(\\"https://github.com/codewithaloha/hierr\\",\\"_blank\\");"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17399]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17399c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:17399,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17399',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si17425:{
name:'default_image3(2)',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17425c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si17415',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:782,
irh:584,
w:782,
h:584,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17425]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17425c:{
b:[0,0,782,584],
fh:false,
fw:false,
uid:17425,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/017423.png',
dn:'si17425',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,783,585],
vb:[-1,-1,783,585]
},
si17437:{
name:'Image_Group_Text_157',
type:1268,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17437c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17415',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si17445',
t:1250
}
,{
n:'si17455',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si17415',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si17437c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:17437,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17437',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si17445:{
name:'Text_401',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17445c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17437',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5bs3q","text":"Raelene Thomas","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-question-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17445]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17445c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:17445,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17445',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si17455:{
name:'Text_402',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17455c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17437',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"8s608","text":"VP, Sales and Marketing","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":23,"style":"hlnk:"},{"offset":0,"length":23,"style":"hlnkt:wp"},{"offset":0,"length":23,"style":"textOutlineEnable:false"},{"offset":0,"length":23,"style":"opacity:1"},{"offset":0,"length":23,"style":"hlnke:true"},{"offset":0,"length":23,"style":"backgroundColor:unset"},{"offset":0,"length":23,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":23,"style":"textHighlightEnable:false"},{"offset":0,"length":23,"style":"textShadowEnable:false"},{"offset":0,"length":23,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17455]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17455c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:17455,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17455',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si17465:{
name:'Button_263',
type:29,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17465c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"d51nq","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dq9ee","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0472.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ef9pp","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7bavq","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"an8gd","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si17415',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17465]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17465c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:17465,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17465',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si17491:{
name:'default_image4(2)',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17491c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si17481',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:782,
irh:584,
w:782,
h:584,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17491]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17491c:{
b:[0,0,782,584],
fh:false,
fw:false,
uid:17491,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/017489.png',
dn:'si17491',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,783,585],
vb:[-1,-1,783,585]
},
si17503:{
name:'Image_Group_Text_158',
type:1268,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17503c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17481',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si17511',
t:1250
}
,{
n:'si17521',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si17481',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si17503c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:17503,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17503',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si17511:{
name:'Text_403',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17511c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17503',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"ca8j6","text":"Lyn Bryan","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-question-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17511]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17511c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:17511,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17511',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si17521:{
name:'Text_404',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17521c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17503',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"bdtm3","text":"CEO","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":3,"style":"overridden:false"},{"offset":0,"length":3,"style":"hlnk:"},{"offset":0,"length":3,"style":"hlnkt:wp"},{"offset":0,"length":3,"style":"textOutlineEnable:false"},{"offset":0,"length":3,"style":"opacity:1"},{"offset":0,"length":3,"style":"hlnke:true"},{"offset":0,"length":3,"style":"backgroundColor:unset"},{"offset":0,"length":3,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":3,"style":"textHighlightEnable:false"},{"offset":0,"length":3,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17521]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17521c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:17521,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17521',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si17531:{
name:'Button_264',
type:29,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17531c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"fjahl","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8sn3k","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0472.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a5h1f","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7tqlk","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ajoth","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si17481',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17531]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17531c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:17531,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17531',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si17557:{
name:'default_image5(2)',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17557c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si17547',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:782,
irh:584,
w:782,
h:584,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17557]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17557c:{
b:[0,0,782,584],
fh:false,
fw:false,
uid:17557,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/017555.png',
dn:'si17557',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,783,585],
vb:[-1,-1,783,585]
},
si17569:{
name:'Image_Group_Text_159',
type:1268,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17569c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17547',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si17577',
t:1250
}
,{
n:'si17587',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si17547',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si17569c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:17569,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17569',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si17577:{
name:'Text_405',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17577c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17569',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3q56e","text":"Lyn Bryan","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-question-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17577]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17577c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:17577,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17577',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si17587:{
name:'Text_406',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17587c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17569',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"aen96","text":"CEO","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":3,"style":"backgroundColor:unset"},{"offset":0,"length":3,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":3,"style":"textHighlightEnable:false"},{"offset":0,"length":3,"style":"textShadowEnable:false"},{"offset":0,"length":3,"style":"overridden:false"},{"offset":0,"length":3,"style":"hlnk:"},{"offset":0,"length":3,"style":"hlnkt:wp"},{"offset":0,"length":3,"style":"textOutlineEnable:false"},{"offset":0,"length":3,"style":"opacity:1"},{"offset":0,"length":3,"style":"hlnke:true"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17587]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17587c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:17587,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17587',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si17597:{
name:'Button_265',
type:29,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17597c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2djrp","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"b7mam","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0472.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5r5p9","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"fo2dv","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"72kbs","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si17547',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17597]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17597c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:17597,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17597',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si17623:{
name:'default_image6(2)',
type:15,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17623c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":1,"color":"#666666FF","enabled":false,"style":0}},"designOptionStyles":{"all":{"borderRadius":"20px","overflow":"hidden"},"tablet":{},"mobile":{}}}',
parentGroup:'si17613',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:782,
irh:584,
w:782,
h:584,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17623]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17623c:{
b:[0,0,782,584],
fh:false,
fw:false,
uid:17623,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/017621.png',
dn:'si17623',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,783,585],
vb:[-1,-1,783,585]
},
si17635:{
name:'Image_Group_Text_160',
type:1268,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17635c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17613',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si17643',
t:1250
}
,{
n:'si17653',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":10,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"12px","paddingTop":"40px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si17613',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si17635c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:17635,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17635',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si17643:{
name:'Text_407',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17643c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingTop":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17635',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"b2e6d","text":"Lyn Bryan","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":9,"style":"hlnk:"},{"offset":0,"length":9,"style":"hlnkt:wp"},{"offset":0,"length":9,"style":"textOutlineEnable:false"},{"offset":0,"length":9,"style":"opacity:1"},{"offset":0,"length":9,"style":"hlnke:true"},{"offset":0,"length":9,"style":"backgroundColor:unset"},{"offset":0,"length":9,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":9,"style":"textHighlightEnable:false"},{"offset":0,"length":9,"style":"textShadowEnable:false"},{"offset":0,"length":9,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-question-2","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17643]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17643c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:17643,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17643',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si17653:{
name:'Text_408',
type:1250,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17653c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"25px"},"tablet":{},"mobile":{}}}',
parentGroup:'si17635',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"6c0l4","text":"CEO","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":3,"style":"hlnkt:wp"},{"offset":0,"length":3,"style":"textOutlineEnable:false"},{"offset":0,"length":3,"style":"opacity:1"},{"offset":0,"length":3,"style":"hlnke:true"},{"offset":0,"length":3,"style":"backgroundColor:unset"},{"offset":0,"length":3,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":3,"style":"textHighlightEnable:false"},{"offset":0,"length":3,"style":"textShadowEnable:false"},{"offset":0,"length":3,"style":"overridden:false"},{"offset":0,"length":3,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-body-1","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17653]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17653c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:17653,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17653',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si17663:{
name:'Button_266',
type:29,
from:277,
to:462,
rp:0,
rpa:0,
mdi:'si17663c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"2ie87","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"fs5qm","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0472.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"89kln","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cs7ik","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5bqp9","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si17613',
retainState:false,
immo:false,
apsn:'Slide17159',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[17663]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si17663c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:17663,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si17663',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide17159:{
lb:'Active Projects Overview',
id:17159,
from:277,
to:462,
iols:0,
i360qs:false,
sdu:6.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide17159c',
st:'Normal Slide',
sk:'Meet the Team',
slideTag:'team-slide',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si17181',
t:1268
}
,{
n:'si17275',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
iso:true,
sc:'#333333',
ss:0,
sw:1,
sa:1,
se:true
}
,
bookmarks:[]
,
qs:'',
iph:{
64936:{
ts:''
}
,
60663:{
ts:''
}
,
60657:{
ts:''
}
,
65027:{
ts:''
}

}

},
Slide17159c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:17159,
dn:'Slide17159',
visible:'1'
},
si24316:{
name:'Character-Block-2_1',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24316c',
tag:'character-block-2-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"character-image":true,"character-speech-card-1":true,"character-speech-card-2":true,"slide-item-body-1":true,"slide-item-body-2":true,"slide-item-prev-button":false,"slide-item-next-button":false,"card":false},"imageHeight":324,"autoFit":false,"alignment":{},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"left":5,"right":5,"top":0,"bottom":0},"designOptionStyles":{"all":{"position":"relative","display":"grid","gridTemplateColumns":"1fr 4fr 1fr","gridTemplateAreas":"\'cp-character-container-1 cp-character-speech-1 cp-character-container-2\' \'cp-character-container-1 cp-character-speech-2 cp-character-container-2\' \'cp-slide-buttons-container cp-slide-buttons-container cp-slide-buttons-container\'"},"tablet":{},"mobile":{"gridTemplateColumns":"1fr 1fr 1fr","gridTemplateAreas":"\'cp-character-container-1 cp-character-speech-1 cp-character-speech-1\' \'cp-character-speech-2 cp-character-speech-2 cp-character-container-2\' \'cp-slide-buttons-container cp-slide-buttons-container cp-slide-buttons-container\'"},"mobile_landscape":{"position":"relative","display":"grid","gridTemplateColumns":"1fr 4fr 1fr","gridTemplateAreas":"\'cp-character-container-1 cp-character-speech-1 cp-character-container-2\' \'cp-character-container-1 cp-character-speech-2 cp-character-container-2\' \'cp-slide-buttons-container cp-slide-buttons-container cp-slide-buttons-container\'"}},"appearanceProperties":{},"numberOfChildren":2}',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si24324',
t:1268
}
,{
n:'si24346',
t:1268
}
,{
n:'si24364',
t:1268
}
,{
n:'si24382',
t:1268
}
,{
n:'si24404',
t:1268
}
]
,
containerType:'character-block-2',
widgetProps:'{"visibilityInfo":{"character-image":true,"character-speech-card-1":true,"character-speech-card-2":true,"slide-item-body-1":true,"slide-item-body-2":true,"slide-item-prev-button":false,"slide-item-next-button":false,"card":false},"imageHeight":324,"autoFit":false,"alignment":{},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"left":5,"right":5,"top":0,"bottom":0},"designOptionStyles":{"all":{"position":"relative","display":"grid","gridTemplateColumns":"1fr 4fr 1fr","gridTemplateAreas":"\'cp-character-container-1 cp-character-speech-1 cp-character-container-2\' \'cp-character-container-1 cp-character-speech-2 cp-character-container-2\' \'cp-slide-buttons-container cp-slide-buttons-container cp-slide-buttons-container\'"},"tablet":{},"mobile":{"gridTemplateColumns":"1fr 1fr 1fr","gridTemplateAreas":"\'cp-character-container-1 cp-character-speech-1 cp-character-speech-1\' \'cp-character-speech-2 cp-character-speech-2 cp-character-container-2\' \'cp-slide-buttons-container cp-slide-buttons-container cp-slide-buttons-container\'"},"mobile_landscape":{"position":"relative","display":"grid","gridTemplateColumns":"1fr 4fr 1fr","gridTemplateAreas":"\'cp-character-container-1 cp-character-speech-1 cp-character-container-2\' \'cp-character-container-1 cp-character-speech-2 cp-character-container-2\' \'cp-slide-buttons-container cp-slide-buttons-container cp-slide-buttons-container\'"}},"appearanceProperties":{},"numberOfChildren":2}',
option:'DEFAULT_DOUBLE_CHARACTER_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si24316c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:24316,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si24316',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--widget-container--fillcolor)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si24324:{
name:'Character-Image_1',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24324c',
tag:'character-container-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"character-image":true},"imageHeight":350,"alignment":{},"canBeCard":false,"isCharacterImageContainer":true,"shouldRender":true,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"gridArea":"cp-character-container-1","width":"280px","maxWidth":"506px"},"tablet":{"maxWidth":"150px"},"mobile":{"maxWidth":"150px"}}}',
parentGroup:'si24316',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si24334',
t:15
}
]
,
containerType:'character-container-1',
widgetProps:'{"visibilityInfo":{"character-image":true},"imageHeight":350,"alignment":{},"canBeCard":false,"isCharacterImageContainer":true,"shouldRender":true,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"gridArea":"cp-character-container-1","width":"280px","maxWidth":"506px"},"tablet":{"maxWidth":"150px"},"mobile":{"maxWidth":"150px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si24316',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si24324c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:24324,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si24324',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si24334:{
name:'Stick_Woman44_1',
type:15,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24334c',
tag:'character-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si24324',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:901,
irh:2000,
w:901,
h:2000,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[24334]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si24334c:{
b:[0,0,901,2000],
fh:false,
fw:false,
uid:24334,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/026743.png',
dn:'si24334',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,902,2001],
vb:[-1,-1,902,2001]
},
si24346:{
name:'Character-Speech-Card_1',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24346c',
tag:'character-speech-card-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-body-1":true,"card":true},"padding":{"top":32,"bottom":32,"left":32,"right":32},"alignment":{"slide-item-body-1":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"#D87564","size":4,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":0,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":0,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center","gridArea":"cp-character-speech-1"},"tablet":{},"mobile":{}}}',
parentGroup:'si24316',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si24354',
t:1250
}
]
,
containerType:'character-speech-card-1',
widgetProps:'{"visibilityInfo":{"slide-item-body-1":true,"card":true},"padding":{"top":32,"bottom":32,"left":32,"right":32},"alignment":{"slide-item-body-1":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"#D87564","size":4,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":0,"bottomRight":20,"topRight":20}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":0,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center","gridArea":"cp-character-speech-1"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si24316',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si24346c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:24346,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si24346',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#d87564',
fe:true,
fca:0.84,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si24354:{
name:'Text_438',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24354c',
tag:'slide-item-body-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"gridArea":"cp-character-speech","alignSelf":"center"},"tablet":{},"mobile":{}}}',
parentGroup:'si24346',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5uia3","text":"Please explain more about the roles!","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":36,"style":"tablet-fontSize:20"},{"offset":0,"length":36,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":36,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":36,"style":"textOutlineEnable:false"},{"offset":0,"length":36,"style":"opacity:1"},{"offset":0,"length":36,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":36,"style":"hlnke:true"},{"offset":0,"length":36,"style":"defaultTextShadow:none"},{"offset":0,"length":36,"style":"textShadow:none"},{"offset":0,"length":36,"style":"mobile-fontSize:18"},{"offset":0,"length":36,"style":"textShadowX:0px"},{"offset":0,"length":36,"style":"fontStretch:normal"},{"offset":0,"length":36,"style":"fontType:regular"},{"offset":0,"length":36,"style":"color:#333333"},{"offset":0,"length":36,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":36,"style":"textShadowY:4px"},{"offset":0,"length":36,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":36,"style":"letterSpacing:0%"},{"offset":0,"length":36,"style":"textHighlightEnable:false"},{"offset":0,"length":36,"style":"textTransform:none"},{"offset":0,"length":36,"style":"textShadowOpacity:none"},{"offset":0,"length":36,"style":"overridden:true"},{"offset":0,"length":36,"style":"textDecoration:none"},{"offset":0,"length":36,"style":"lineHeight:130%"},{"offset":0,"length":36,"style":"fontFamily:Georgia"},{"offset":0,"length":36,"style":"borderBottomStyle:none"},{"offset":0,"length":36,"style":"fontWeight:bold"},{"offset":0,"length":36,"style":"textShadowEnable:false"},{"offset":0,"length":36,"style":"hlnk:"},{"offset":0,"length":36,"style":"textShadowBlur:8px"},{"offset":0,"length":36,"style":"desktop-fontSize:36"},{"offset":0,"length":36,"style":"backgroundColor:unset"},{"offset":0,"length":36,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":36,"style":"hlnkt:wp"},{"offset":0,"length":36,"style":"fontStyle:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[24354]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si24354c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:24354,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si24354',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si24364:{
name:'Character-Speech-Card_2',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24364c',
tag:'character-speech-card-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-body-2":true,"card":true},"padding":{"top":32,"bottom":32,"left":32,"right":32},"alignment":{"slide-item-body-2":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"#FDD05B","size":4,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":0,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center","gridArea":"cp-character-speech-2"},"tablet":{},"mobile":{}}}',
parentGroup:'si24316',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si24372',
t:1250
}
]
,
containerType:'character-speech-card-2',
widgetProps:'{"visibilityInfo":{"slide-item-body-2":true,"card":true},"padding":{"top":32,"bottom":32,"left":32,"right":32},"alignment":{"slide-item-body-2":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":true,"color":"#FDD05B","size":4,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":20,"bottomLeft":20,"bottomRight":20,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":0,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","flex":"3.7","justifyContent":"center","gridArea":"cp-character-speech-2"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si24316',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si24364c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:24364,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si24364',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#fdd05b',
fe:true,
fca:0.84,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si24372:{
name:'Text_439',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24372c',
tag:'slide-item-body-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"designOptionStyles":{"all":{"gridArea":"cp-character-speech","alignSelf":"center"},"tablet":{},"mobile":{}}}',
parentGroup:'si24364',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"7jtfg","text":"Sure! Lets look into the 3 main groups","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":38,"style":"desktop-fontSize:36"},{"offset":0,"length":38,"style":"backgroundColor:unset"},{"offset":0,"length":38,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":38,"style":"hlnkt:wp"},{"offset":0,"length":38,"style":"fontStyle:normal"},{"offset":0,"length":38,"style":"tablet-fontSize:20"},{"offset":0,"length":38,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":38,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":38,"style":"textOutlineEnable:false"},{"offset":0,"length":38,"style":"opacity:1"},{"offset":0,"length":38,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":38,"style":"hlnke:true"},{"offset":0,"length":38,"style":"defaultTextShadow:none"},{"offset":0,"length":38,"style":"textShadow:none"},{"offset":0,"length":38,"style":"mobile-fontSize:18"},{"offset":0,"length":38,"style":"textShadowX:0px"},{"offset":0,"length":38,"style":"fontStretch:normal"},{"offset":0,"length":38,"style":"fontType:regular"},{"offset":0,"length":38,"style":"color:#333333"},{"offset":0,"length":38,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":38,"style":"textShadowY:4px"},{"offset":0,"length":38,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":38,"style":"letterSpacing:0%"},{"offset":0,"length":38,"style":"textHighlightEnable:false"},{"offset":0,"length":38,"style":"textTransform:none"},{"offset":0,"length":38,"style":"textShadowOpacity:none"},{"offset":0,"length":38,"style":"overridden:true"},{"offset":0,"length":38,"style":"textDecoration:none"},{"offset":0,"length":38,"style":"lineHeight:130%"},{"offset":0,"length":38,"style":"fontFamily:Georgia"},{"offset":0,"length":38,"style":"borderBottomStyle:none"},{"offset":0,"length":38,"style":"fontWeight:bold"},{"offset":0,"length":38,"style":"textShadowEnable:false"},{"offset":0,"length":38,"style":"hlnk:"},{"offset":0,"length":38,"style":"textShadowBlur:8px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-1","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[24372]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si24372c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:24372,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si24372',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si24382:{
name:'Character-Image_2',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24382c',
tag:'character-container-2',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"character-image":true},"imageHeight":350,"alignment":{},"canBeCard":false,"isCharacterImageContainer":true,"shouldRender":true,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"gridArea":"cp-character-container-2","width":"280px","maxWidth":"506px"},"tablet":{"maxWidth":"150px"},"mobile":{"maxWidth":"150px"}}}',
parentGroup:'si24316',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si24392',
t:15
}
]
,
containerType:'character-container-2',
widgetProps:'{"visibilityInfo":{"character-image":true},"imageHeight":350,"alignment":{},"canBeCard":false,"isCharacterImageContainer":true,"shouldRender":true,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"gridArea":"cp-character-container-2","width":"280px","maxWidth":"506px"},"tablet":{"maxWidth":"150px"},"mobile":{"maxWidth":"150px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si24316',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si24382c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:24382,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si24382',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si24392:{
name:'Stick_Man12',
type:15,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24392c',
tag:'character-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si24382',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1569,
irh:2000,
w:1569,
h:2000,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[24392]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si24392c:{
b:[0,0,1569,2000],
fh:false,
fw:false,
uid:24392,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'18.519%',
h:'59.211%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/024458.png',
dn:'si24392',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1570,2001],
vb:[-1,-1,1570,2001]
},
si24404:{
name:'Slide_Buttons_Widget_1',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24404c',
tag:'slide-buttons-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","justifyContent":"space-between","padding":"18px 0px 0px"}}}',
parentGroup:'si24316',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si24415',
t:29
}
,{
n:'si24437',
t:29
}
]
,
containerType:'slide-buttons',
widgetProps:'{"canBeCard":false,"areStatesSupported":false,"visibilityInfo":{},"appearanceProperties":{},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","justifyContent":"space-between","padding":"18px 0px 0px"}}}',
option:'SLIDE_BUTTONS_DEFAULT_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si24316',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si24404c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:24404,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si24404',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ff0000',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:8,
ss:0,
sa:1,
se:false,
vbwr:[-5,-5,4,4],
vb:[-5,-5,4,4]
},
si24415:{
name:'Button_278',
type:29,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24415c',
tag:'slide-buttons-previous-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"a8p1d","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_default","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"am5kv","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"30"}},"designOption":"SLIDE_PREVIOUS_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"024412.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"4d9j3","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ftfcs","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"b2fdu","text":"Previous","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":8,"style":"hlnkt:wp"},{"offset":0,"length":8,"style":"textOutlineEnable:false"},{"offset":0,"length":8,"style":"opacity:1"},{"offset":0,"length":8,"style":"textShadowColor:ffffff00"},{"offset":0,"length":8,"style":"hlnke:true"},{"offset":0,"length":8,"style":"backgroundColor:unset"},{"offset":0,"length":8,"style":"textShadowX:0px"},{"offset":0,"length":8,"style":"textShadowY:0px"},{"offset":0,"length":8,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":8,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":8,"style":"textShadowBlur:0px"},{"offset":0,"length":8,"style":"textHighlightEnable:false"},{"offset":0,"length":8,"style":"textShadowEnable:false"},{"offset":0,"length":8,"style":"hlnk:"},{"offset":0,"length":8,"style":"overridden:false"},{"offset":0,"length":8,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si24404',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToPreviousSlide(24433);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[24415]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si24415c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:24415,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si24415',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si24437:{
name:'Button_279',
type:29,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si24437c',
tag:'slide-buttons-next-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":true,"hover":true,"visited":false},"normal":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"cr5mj","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_default","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ej47d","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"30"}},"designOption":"SLIDE_NEXT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"024434.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9lat7","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8spvt","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"},{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":15,"opacity":100,"textEnabled":false,"svgAppearenceProperties":{"iconEnabled":true,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ad1il","text":"Next","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":4,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":4,"style":"hlnkt:wp"},{"offset":0,"length":4,"style":"textOutlineEnable:false"},{"offset":0,"length":4,"style":"opacity:1"},{"offset":0,"length":4,"style":"textShadowColor:ffffff00"},{"offset":0,"length":4,"style":"hlnke:true"},{"offset":0,"length":4,"style":"backgroundColor:unset"},{"offset":0,"length":4,"style":"textShadowX:0px"},{"offset":0,"length":4,"style":"textShadowY:0px"},{"offset":0,"length":4,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":4,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":4,"style":"textShadowBlur:0px"},{"offset":0,"length":4,"style":"textHighlightEnable:false"},{"offset":0,"length":4,"style":"textShadowEnable:false"},{"offset":0,"length":4,"style":"hlnk:"},{"offset":0,"length":4,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_navigate_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si24404',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
oca:'{"scripts":[{"then":[["cp.jumpToNextSlide(24455);"]]}]}',
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[24437]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si24437c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:24437,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si24437',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si23490:{
name:'Image_Grid_21',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23490c',
tag:'container-image-grid',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":292,"autoFit":false,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_SCALE","padding":{"top":10,"bottom":10,"left":5,"right":5},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"28px"},"tablet":{},"mobile":{"display":"flex","flexDirection":"column"}},"appearanceProperties":{},"imageAspectRatio":1.34,"numberOfChildren":3}',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si23498',
t:1268
}
,{
n:'si23562',
t:1268
}
,{
n:'si23626',
t:1268
}
]
,
containerType:'image-grid',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":292,"autoFit":false,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_SCALE","padding":{"top":10,"bottom":10,"left":5,"right":5},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"28px"},"tablet":{},"mobile":{"display":"flex","flexDirection":"column"}},"appearanceProperties":{},"imageAspectRatio":1.34,"numberOfChildren":3}',
option:'DEFAULT_IMAGE_GRID_OPTION',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si23490c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:23490,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23490',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--widget-container--fillcolor)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si23498:{
name:'Image_Grid_Group_121',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23498c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","gap":"20px"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"order":3},"tablet":{},"mobile":{}}}}',
parentGroup:'si23490',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si23506',
t:15
}
,{
n:'si23518',
t:1268
}
]
,
containerType:'image-grid-card',
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","gap":"20px"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"order":3},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si23490',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si23498c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:23498,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23498',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si23506:{
name:'AdobeStock_280873995',
type:15,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23506c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23498',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#000000',
o:0
}
,
o:100,
tiletype:1,
imageFocus:0,
irw:2000,
irh:1287,
w:2000,
h:1287,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23506]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23506c:{
b:[0,0,2000,1287],
fh:false,
fw:false,
uid:23506,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/024562.jpeg',
dn:'si23506',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,2001,1288],
vb:[-1,-1,2001,1288]
},
si23518:{
name:'Image_Group_Text_161',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23518c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si23498',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si23526',
t:1250
}
,{
n:'si23536',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si23498',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si23518c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:23518,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23518',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si23526:{
name:'Text_426',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23526c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23518',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"5cgrq","text":"Creative Roles","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"textShadowBlur:8px"},{"offset":0,"length":14,"style":"desktop-fontSize:36"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"fontStyle:normal"},{"offset":0,"length":14,"style":"mobile-fontSize:24"},{"offset":0,"length":14,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":14,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"defaultTextShadow:none"},{"offset":0,"length":14,"style":"tablet-fontSize:24"},{"offset":0,"length":14,"style":"textShadow:none"},{"offset":0,"length":14,"style":"textShadowX:0px"},{"offset":0,"length":14,"style":"fontStretch:normal"},{"offset":0,"length":14,"style":"fontType:regular"},{"offset":0,"length":14,"style":"color:#333333"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textShadowY:4px"},{"offset":0,"length":14,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":14,"style":"lineHeight:125%"},{"offset":0,"length":14,"style":"letterSpacing:0%"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textTransform:none"},{"offset":0,"length":14,"style":"textShadowOpacity:none"},{"offset":0,"length":14,"style":"overridden:true"},{"offset":0,"length":14,"style":"textDecoration:none"},{"offset":0,"length":14,"style":"fontFamily:Georgia"},{"offset":0,"length":14,"style":"borderBottomStyle:none"},{"offset":0,"length":14,"style":"fontWeight:bold"},{"offset":0,"length":14,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}},{"key":"9foth","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23526]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23526c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:23526,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23526',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si23536:{
name:'Text_427',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23536c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23518',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"71jki","text":"Copywriting involves communicating the group\'s mission, values, and overall information. The goal is typically encouraging volunteer participation and media growth.","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":164,"style":"backgroundColor:unset"},{"offset":0,"length":164,"style":"textShadowX:0px"},{"offset":0,"length":164,"style":"tablet-fontSize:18"},{"offset":0,"length":164,"style":"fontStretch:normal"},{"offset":0,"length":164,"style":"fontType:regular"},{"offset":0,"length":164,"style":"color:#666666"},{"offset":0,"length":164,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":164,"style":"textShadowY:4px"},{"offset":0,"length":164,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":164,"style":"lineHeight:135%"},{"offset":0,"length":164,"style":"letterSpacing:0%"},{"offset":0,"length":164,"style":"textHighlightEnable:false"},{"offset":0,"length":164,"style":"textTransform:none"},{"offset":0,"length":164,"style":"textShadowOpacity:none"},{"offset":0,"length":164,"style":"overridden:true"},{"offset":0,"length":164,"style":"textDecoration:none"},{"offset":0,"length":164,"style":"desktop-fontSize:30"},{"offset":0,"length":164,"style":"fontFamily:Georgia"},{"offset":0,"length":164,"style":"borderBottomStyle:none"},{"offset":0,"length":164,"style":"textShadowEnable:false"},{"offset":0,"length":164,"style":"hlnk:"},{"offset":0,"length":164,"style":"fontWeight:normal"},{"offset":0,"length":164,"style":"textShadowBlur:8px"},{"offset":0,"length":164,"style":"mobile-fontSize:21"},{"offset":0,"length":164,"style":"textShadow:none"},{"offset":0,"length":164,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":164,"style":"hlnkt:wp"},{"offset":0,"length":164,"style":"fontStyle:normal"},{"offset":0,"length":164,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":164,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":164,"style":"textOutlineEnable:false"},{"offset":0,"length":164,"style":"opacity:1"},{"offset":0,"length":164,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":164,"style":"hlnke:true"},{"offset":0,"length":164,"style":"defaultTextShadow:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"pel9","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"enoh0","text":"The UX / UI Designers\' goal is to enhance user satisfaction by making interactions with the websites efficient and easy to navigate.","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":132,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":132,"style":"hlnke:true"},{"offset":0,"length":132,"style":"defaultTextShadow:none"},{"offset":0,"length":132,"style":"backgroundColor:unset"},{"offset":0,"length":132,"style":"textShadowX:0px"},{"offset":0,"length":132,"style":"tablet-fontSize:18"},{"offset":0,"length":132,"style":"fontStretch:normal"},{"offset":0,"length":132,"style":"fontType:regular"},{"offset":0,"length":132,"style":"color:#666666"},{"offset":0,"length":132,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":132,"style":"textShadowY:4px"},{"offset":0,"length":132,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":132,"style":"lineHeight:135%"},{"offset":0,"length":132,"style":"letterSpacing:0%"},{"offset":0,"length":132,"style":"textHighlightEnable:false"},{"offset":0,"length":132,"style":"textTransform:none"},{"offset":0,"length":132,"style":"textShadowOpacity:none"},{"offset":0,"length":132,"style":"overridden:true"},{"offset":0,"length":132,"style":"textDecoration:none"},{"offset":0,"length":132,"style":"desktop-fontSize:30"},{"offset":0,"length":132,"style":"fontFamily:Georgia"},{"offset":0,"length":132,"style":"borderBottomStyle:none"},{"offset":0,"length":132,"style":"textShadowEnable:false"},{"offset":0,"length":132,"style":"hlnk:"},{"offset":0,"length":132,"style":"fontWeight:normal"},{"offset":0,"length":132,"style":"textShadowBlur:8px"},{"offset":0,"length":132,"style":"mobile-fontSize:21"},{"offset":0,"length":132,"style":"textShadow:none"},{"offset":0,"length":132,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":132,"style":"hlnkt:wp"},{"offset":0,"length":132,"style":"fontStyle:normal"},{"offset":0,"length":132,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":132,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":132,"style":"textOutlineEnable:false"},{"offset":0,"length":132,"style":"opacity:1"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"4ppsp","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"6v1jb","text":"Web design is more focused on CSS and styling suggestions to promote visual enhancements.","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":89,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":89,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":89,"style":"textOutlineEnable:false"},{"offset":0,"length":89,"style":"opacity:1"},{"offset":0,"length":89,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":89,"style":"hlnke:true"},{"offset":0,"length":89,"style":"defaultTextShadow:none"},{"offset":0,"length":89,"style":"backgroundColor:unset"},{"offset":0,"length":89,"style":"textShadowX:0px"},{"offset":0,"length":89,"style":"tablet-fontSize:18"},{"offset":0,"length":89,"style":"fontStretch:normal"},{"offset":0,"length":89,"style":"fontType:regular"},{"offset":0,"length":89,"style":"color:#666666"},{"offset":0,"length":89,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":89,"style":"textShadowY:4px"},{"offset":0,"length":89,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":89,"style":"lineHeight:135%"},{"offset":0,"length":89,"style":"letterSpacing:0%"},{"offset":0,"length":89,"style":"textHighlightEnable:false"},{"offset":0,"length":89,"style":"textTransform:none"},{"offset":0,"length":89,"style":"textShadowOpacity:none"},{"offset":0,"length":89,"style":"overridden:true"},{"offset":0,"length":89,"style":"textDecoration:none"},{"offset":0,"length":89,"style":"desktop-fontSize:30"},{"offset":0,"length":89,"style":"fontFamily:Georgia"},{"offset":0,"length":89,"style":"borderBottomStyle:none"},{"offset":0,"length":89,"style":"textShadowEnable:false"},{"offset":0,"length":89,"style":"hlnk:"},{"offset":0,"length":89,"style":"fontWeight:normal"},{"offset":0,"length":89,"style":"textShadowBlur:8px"},{"offset":0,"length":89,"style":"mobile-fontSize:21"},{"offset":0,"length":89,"style":"textShadow:none"},{"offset":0,"length":89,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":89,"style":"hlnkt:wp"},{"offset":0,"length":89,"style":"fontStyle:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23536]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23536c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:23536,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23536',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si23562:{
name:'Image_Grid_Group_122',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23562c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","gap":"20px"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"order":3},"tablet":{},"mobile":{}}}}',
parentGroup:'si23490',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si23570',
t:15
}
,{
n:'si23582',
t:1268
}
]
,
containerType:'image-grid-card',
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","gap":"20px"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"order":3},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si23490',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si23562c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:23562,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23562',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si23570:{
name:'AdobeStock_259463465',
type:15,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23570c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23562',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:7360,
irh:4912,
w:7360,
h:4912,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23570]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23570c:{
b:[0,0,7360,4912],
fh:false,
fw:false,
uid:23570,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/024951.jpeg',
dn:'si23570',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,7361,4913],
vb:[-1,-1,7361,4913]
},
si23582:{
name:'Image_Group_Text_162',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23582c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si23562',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si23590',
t:1250
}
,{
n:'si23600',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si23562',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si23582c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:23582,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23582',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si23590:{
name:'Text_428',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23590c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23582',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"84i54","text":"Technical Roles","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":15,"style":"borderBottomStyle:none"},{"offset":0,"length":15,"style":"textShadowEnable:false"},{"offset":0,"length":15,"style":"hlnk:"},{"offset":0,"length":15,"style":"fontWeight:normal"},{"offset":0,"length":15,"style":"textShadowBlur:8px"},{"offset":0,"length":15,"style":"desktop-fontSize:36"},{"offset":0,"length":15,"style":"backgroundColor:unset"},{"offset":0,"length":15,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":15,"style":"hlnkt:wp"},{"offset":0,"length":15,"style":"fontStyle:normal"},{"offset":0,"length":15,"style":"mobile-fontSize:24"},{"offset":0,"length":15,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":15,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":15,"style":"textOutlineEnable:false"},{"offset":0,"length":15,"style":"opacity:1"},{"offset":0,"length":15,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":15,"style":"hlnke:true"},{"offset":0,"length":15,"style":"defaultTextShadow:none"},{"offset":0,"length":15,"style":"tablet-fontSize:24"},{"offset":0,"length":15,"style":"textShadow:none"},{"offset":0,"length":15,"style":"textShadowX:0px"},{"offset":0,"length":15,"style":"fontStretch:normal"},{"offset":0,"length":15,"style":"color:#333333"},{"offset":0,"length":15,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":15,"style":"textShadowY:4px"},{"offset":0,"length":15,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":15,"style":"lineHeight:125%"},{"offset":0,"length":15,"style":"letterSpacing:0%"},{"offset":0,"length":15,"style":"textHighlightEnable:false"},{"offset":0,"length":15,"style":"textTransform:none"},{"offset":0,"length":15,"style":"textShadowOpacity:none"},{"offset":0,"length":15,"style":"overridden:true"},{"offset":0,"length":15,"style":"textDecoration:none"},{"offset":0,"length":15,"style":"fontType:bold"},{"offset":0,"length":15,"style":"fontFamily:Georgia"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}},{"key":"6f87f","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23590]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23590c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:23590,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23590',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si23600:{
name:'Text_429',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23600c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23582',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"fshur","text":"Web Development is focused on using programming languages past just Html and CSS. They aim to make the designs usable while also implementing new features, bug fixes, performance, and more. A sub category of this could be a QA tester or other roles depending on what tasks can be are available.","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":294,"style":"mobile-fontSize:21"},{"offset":0,"length":294,"style":"textShadow:none"},{"offset":0,"length":294,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":294,"style":"hlnkt:wp"},{"offset":0,"length":294,"style":"fontStyle:normal"},{"offset":0,"length":294,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":294,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":294,"style":"textOutlineEnable:false"},{"offset":0,"length":294,"style":"opacity:1"},{"offset":0,"length":294,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":294,"style":"hlnke:true"},{"offset":0,"length":294,"style":"defaultTextShadow:none"},{"offset":0,"length":294,"style":"backgroundColor:unset"},{"offset":0,"length":294,"style":"textShadowX:0px"},{"offset":0,"length":294,"style":"tablet-fontSize:18"},{"offset":0,"length":294,"style":"fontStretch:normal"},{"offset":0,"length":294,"style":"fontType:regular"},{"offset":0,"length":294,"style":"color:#666666"},{"offset":0,"length":294,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":294,"style":"textShadowY:4px"},{"offset":0,"length":294,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":294,"style":"lineHeight:135%"},{"offset":0,"length":294,"style":"letterSpacing:0%"},{"offset":0,"length":294,"style":"textHighlightEnable:false"},{"offset":0,"length":294,"style":"textTransform:none"},{"offset":0,"length":294,"style":"textShadowOpacity:none"},{"offset":0,"length":294,"style":"overridden:true"},{"offset":0,"length":294,"style":"textDecoration:none"},{"offset":0,"length":294,"style":"desktop-fontSize:30"},{"offset":0,"length":294,"style":"fontFamily:Georgia"},{"offset":0,"length":294,"style":"borderBottomStyle:none"},{"offset":0,"length":294,"style":"textShadowEnable:false"},{"offset":0,"length":294,"style":"hlnk:"},{"offset":0,"length":294,"style":"fontWeight:normal"},{"offset":0,"length":294,"style":"textShadowBlur:8px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"3p4t5","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"6gv1u","text":"Technical writers convey complex technical information in an easily understandable manner such as user guides, manuals, FAQs, and tutorials","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":139,"style":"hlnk:"},{"offset":0,"length":18,"style":"fontWeight:normal"},{"offset":0,"length":18,"style":"textShadowBlur:8px"},{"offset":0,"length":139,"style":"mobile-fontSize:21"},{"offset":0,"length":18,"style":"textShadow:none"},{"offset":0,"length":18,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":139,"style":"hlnkt:wp"},{"offset":0,"length":18,"style":"fontStyle:normal"},{"offset":0,"length":18,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":18,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":139,"style":"textOutlineEnable:false"},{"offset":0,"length":139,"style":"opacity:1"},{"offset":0,"length":18,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":139,"style":"hlnke:true"},{"offset":0,"length":18,"style":"defaultTextShadow:none"},{"offset":0,"length":139,"style":"backgroundColor:unset"},{"offset":0,"length":18,"style":"textShadowX:0px"},{"offset":0,"length":139,"style":"tablet-fontSize:18"},{"offset":0,"length":18,"style":"fontStretch:normal"},{"offset":0,"length":139,"style":"fontType:regular"},{"offset":0,"length":18,"style":"color:#666666"},{"offset":0,"length":139,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":18,"style":"textShadowY:4px"},{"offset":0,"length":18,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":18,"style":"lineHeight:135%"},{"offset":0,"length":18,"style":"letterSpacing:0%"},{"offset":0,"length":139,"style":"textHighlightEnable:false"},{"offset":0,"length":18,"style":"textTransform:none"},{"offset":0,"length":18,"style":"textShadowOpacity:none"},{"offset":0,"length":139,"style":"overridden:true"},{"offset":0,"length":18,"style":"textDecoration:none"},{"offset":0,"length":139,"style":"desktop-fontSize:30"},{"offset":0,"length":139,"style":"fontFamily:Georgia"},{"offset":0,"length":18,"style":"borderBottomStyle:none"},{"offset":0,"length":139,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"listType":"S_Bullets08","listColor":"#666666","listIndent":"100%","listSize":"100%","listDepth":"0","overridden":"true","presetId":"text-body-4"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23600]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23600c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:23600,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23600',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si23626:{
name:'Image_Grid_Group_123',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23626c',
tag:'container-image-grid-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","gap":"20px"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"order":3},"tablet":{},"mobile":{}}}}',
parentGroup:'si23490',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si23634',
t:15
}
,{
n:'si23646',
t:1268
}
]
,
containerType:'image-grid-card',
widgetProps:'{"shouldRender":true,"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-button":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":8,"bottomLeft":8,"bottomRight":8,"topRight":8}},"shadow":{"shadowX":0,"shadowY":4,"shadowBlur":8,"enabled":true,"color":"var(--design-option-color3)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column","gap":"20px"},"tablet":{},"mobile":{}},"childNodesCustomStyles":{"slide-item-button":{"all":{"order":3},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si23490',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si23626c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:23626,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23626',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--design-option-color1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si23634:{
name:'AdobeStock_284867628',
type:15,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23634c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23626',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:2000,
irh:1333,
w:2000,
h:1333,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23634]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23634c:{
b:[0,0,2000,1333],
fh:false,
fw:false,
uid:23634,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/024570.jpeg',
dn:'si23634',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,2001,1334],
vb:[-1,-1,2001,1334]
},
si23646:{
name:'Image_Group_Text_163',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23646c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si23626',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si23654',
t:1250
}
,{
n:'si23664',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si23626',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si23646c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:23646,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23646',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si23654:{
name:'Text_430',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23654c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23646',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"9iigt","text":"Leadership and Planning Roles","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":29,"style":"textTransform:none"},{"offset":0,"length":29,"style":"textShadowOpacity:none"},{"offset":0,"length":29,"style":"overridden:true"},{"offset":0,"length":29,"style":"textDecoration:none"},{"offset":0,"length":29,"style":"fontType:bold"},{"offset":0,"length":29,"style":"fontFamily:Georgia"},{"offset":0,"length":29,"style":"borderBottomStyle:none"},{"offset":0,"length":29,"style":"textShadowEnable:false"},{"offset":0,"length":29,"style":"hlnk:"},{"offset":0,"length":29,"style":"fontWeight:normal"},{"offset":0,"length":29,"style":"textShadowBlur:8px"},{"offset":0,"length":29,"style":"desktop-fontSize:36"},{"offset":0,"length":29,"style":"backgroundColor:unset"},{"offset":0,"length":29,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":29,"style":"hlnkt:wp"},{"offset":0,"length":29,"style":"fontStyle:normal"},{"offset":0,"length":29,"style":"mobile-fontSize:24"},{"offset":0,"length":29,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":29,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":29,"style":"textOutlineEnable:false"},{"offset":0,"length":29,"style":"opacity:1"},{"offset":0,"length":29,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":29,"style":"hlnke:true"},{"offset":0,"length":29,"style":"defaultTextShadow:none"},{"offset":0,"length":29,"style":"tablet-fontSize:24"},{"offset":0,"length":29,"style":"textShadow:none"},{"offset":0,"length":29,"style":"textShadowX:0px"},{"offset":0,"length":29,"style":"fontStretch:normal"},{"offset":0,"length":29,"style":"color:#333333"},{"offset":0,"length":29,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":29,"style":"textShadowY:4px"},{"offset":0,"length":29,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":29,"style":"lineHeight:125%"},{"offset":0,"length":29,"style":"letterSpacing:0%"},{"offset":0,"length":29,"style":"textHighlightEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}},{"key":"1n913","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-subheading-6","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23654]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23654c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:23654,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23654',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si23664:{
name:'Text_431',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23664c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23646',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"74ecp","text":"Planning roles could be various sections such as helping with onboarding, project management, leadership, and others around research.","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":133,"style":"fontFamily:Georgia"},{"offset":0,"length":133,"style":"borderBottomStyle:none"},{"offset":0,"length":133,"style":"textShadowEnable:false"},{"offset":0,"length":133,"style":"hlnk:"},{"offset":0,"length":133,"style":"fontWeight:normal"},{"offset":0,"length":133,"style":"textShadowBlur:8px"},{"offset":0,"length":133,"style":"mobile-fontSize:21"},{"offset":0,"length":133,"style":"textShadow:none"},{"offset":0,"length":133,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":133,"style":"hlnkt:wp"},{"offset":0,"length":133,"style":"fontStyle:normal"},{"offset":0,"length":133,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":133,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":133,"style":"textOutlineEnable:false"},{"offset":0,"length":133,"style":"opacity:1"},{"offset":0,"length":133,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":133,"style":"hlnke:true"},{"offset":0,"length":133,"style":"defaultTextShadow:none"},{"offset":0,"length":133,"style":"backgroundColor:unset"},{"offset":0,"length":133,"style":"textShadowX:0px"},{"offset":0,"length":133,"style":"tablet-fontSize:18"},{"offset":0,"length":133,"style":"fontStretch:normal"},{"offset":0,"length":133,"style":"fontType:regular"},{"offset":0,"length":133,"style":"color:#666666"},{"offset":0,"length":133,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":133,"style":"textShadowY:4px"},{"offset":0,"length":133,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":133,"style":"lineHeight:135%"},{"offset":0,"length":133,"style":"letterSpacing:0%"},{"offset":0,"length":133,"style":"textHighlightEnable:false"},{"offset":0,"length":133,"style":"textTransform:none"},{"offset":0,"length":133,"style":"textShadowOpacity:none"},{"offset":0,"length":133,"style":"overridden:true"},{"offset":0,"length":133,"style":"textDecoration:none"},{"offset":0,"length":133,"style":"desktop-fontSize:30"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"ci274","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"1r2tl","text":"Roles such as onboarding could include hosting as example. This is where someone could be one of the dedicated members who assist new people who have questions outside of the onboarding guide. ","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":193,"style":"overridden:true"},{"offset":0,"length":193,"style":"textDecoration:none"},{"offset":0,"length":193,"style":"desktop-fontSize:30"},{"offset":0,"length":193,"style":"fontFamily:Georgia"},{"offset":0,"length":193,"style":"borderBottomStyle:none"},{"offset":0,"length":193,"style":"textShadowEnable:false"},{"offset":0,"length":193,"style":"hlnk:"},{"offset":0,"length":193,"style":"fontWeight:normal"},{"offset":0,"length":193,"style":"textShadowBlur:8px"},{"offset":0,"length":193,"style":"mobile-fontSize:21"},{"offset":0,"length":193,"style":"textShadow:none"},{"offset":0,"length":193,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":193,"style":"hlnkt:wp"},{"offset":0,"length":193,"style":"fontStyle:normal"},{"offset":0,"length":193,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":193,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":193,"style":"textOutlineEnable:false"},{"offset":0,"length":193,"style":"opacity:1"},{"offset":0,"length":193,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":193,"style":"hlnke:true"},{"offset":0,"length":193,"style":"defaultTextShadow:none"},{"offset":0,"length":193,"style":"backgroundColor:unset"},{"offset":0,"length":193,"style":"textShadowX:0px"},{"offset":0,"length":193,"style":"tablet-fontSize:18"},{"offset":0,"length":193,"style":"fontStretch:normal"},{"offset":0,"length":193,"style":"fontType:regular"},{"offset":0,"length":193,"style":"color:#666666"},{"offset":0,"length":193,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":193,"style":"textShadowY:4px"},{"offset":0,"length":193,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":193,"style":"lineHeight:135%"},{"offset":0,"length":193,"style":"letterSpacing:0%"},{"offset":0,"length":193,"style":"textHighlightEnable:false"},{"offset":0,"length":193,"style":"textTransform:none"},{"offset":0,"length":193,"style":"textShadowOpacity:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"3r78e","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}},{"key":"8ineu","text":"Other examples of ways to assist in this role could be gathering feedback from members, providing suggestions to other member roles, and joining team discussions about where a project is headed.","type":"unordered-list-item","depth":0,"inlineStyleRanges":[{"offset":0,"length":194,"style":"textHighlightEnable:false"},{"offset":0,"length":194,"style":"textTransform:none"},{"offset":0,"length":194,"style":"textShadowOpacity:none"},{"offset":0,"length":194,"style":"overridden:true"},{"offset":0,"length":194,"style":"textDecoration:none"},{"offset":0,"length":194,"style":"desktop-fontSize:30"},{"offset":0,"length":194,"style":"fontFamily:Georgia"},{"offset":0,"length":194,"style":"borderBottomStyle:none"},{"offset":0,"length":194,"style":"textShadowEnable:false"},{"offset":0,"length":194,"style":"hlnk:"},{"offset":0,"length":194,"style":"fontWeight:normal"},{"offset":0,"length":194,"style":"textShadowBlur:8px"},{"offset":0,"length":194,"style":"mobile-fontSize:21"},{"offset":0,"length":194,"style":"textShadow:none"},{"offset":0,"length":194,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":194,"style":"hlnkt:wp"},{"offset":0,"length":194,"style":"fontStyle:normal"},{"offset":0,"length":194,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":194,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":194,"style":"textOutlineEnable:false"},{"offset":0,"length":194,"style":"opacity:1"},{"offset":0,"length":194,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":194,"style":"hlnke:true"},{"offset":0,"length":194,"style":"defaultTextShadow:none"},{"offset":0,"length":194,"style":"backgroundColor:unset"},{"offset":0,"length":194,"style":"textShadowX:0px"},{"offset":0,"length":194,"style":"tablet-fontSize:18"},{"offset":0,"length":194,"style":"fontStretch:normal"},{"offset":0,"length":194,"style":"fontType:regular"},{"offset":0,"length":194,"style":"color:#666666"},{"offset":0,"length":194,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":194,"style":"textShadowY:4px"},{"offset":0,"length":194,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":194,"style":"lineHeight:135%"},{"offset":0,"length":194,"style":"letterSpacing:0%"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-body-4","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23664]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23664c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:23664,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23664',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si23698:{
name:'default_image4(3)',
type:15,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23698c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23690',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:782,
irh:584,
w:782,
h:584,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23698]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23698c:{
b:[0,0,782,584],
fh:false,
fw:false,
uid:23698,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/020855.png',
dn:'si23698',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,783,585],
vb:[-1,-1,783,585]
},
si23710:{
name:'Image_Group_Text_164',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23710c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si23690',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si23718',
t:1250
}
,{
n:'si23728',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si23690',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si23710c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:23710,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23710',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si23718:{
name:'Text_432',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23718c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23710',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"b6hej","text":"At vero eos et accusamus et iusto.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":34,"style":"opacity:1"},{"offset":0,"length":34,"style":"hlnke:true"},{"offset":0,"length":34,"style":"backgroundColor:unset"},{"offset":0,"length":34,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":34,"style":"textHighlightEnable:false"},{"offset":0,"length":34,"style":"textShadowEnable:false"},{"offset":0,"length":34,"style":"overridden:false"},{"offset":0,"length":34,"style":"hlnk:"},{"offset":0,"length":34,"style":"hlnkt:wp"},{"offset":0,"length":34,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23718]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23718c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:23718,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23718',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si23728:{
name:'Text_433',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23728c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23710',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"9i77b","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod tempor incididunt.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":89,"style":"hlnk:"},{"offset":0,"length":89,"style":"hlnkt:wp"},{"offset":0,"length":89,"style":"textOutlineEnable:false"},{"offset":0,"length":89,"style":"opacity:1"},{"offset":0,"length":89,"style":"hlnke:true"},{"offset":0,"length":89,"style":"backgroundColor:unset"},{"offset":0,"length":89,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":89,"style":"textHighlightEnable:false"},{"offset":0,"length":89,"style":"textShadowEnable:false"},{"offset":0,"length":89,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23728]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23728c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:23728,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23728',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si23738:{
name:'Button_275',
type:29,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23738c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"blf91","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1h021","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0472.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3tp0s","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"ekiqj","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"3j8jp","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si23690',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23738]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23738c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:23738,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23738',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si23762:{
name:'default_image5(3)',
type:15,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23762c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23754',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:782,
irh:584,
w:782,
h:584,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23762]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23762c:{
b:[0,0,782,584],
fh:false,
fw:false,
uid:23762,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/020922.png',
dn:'si23762',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,783,585],
vb:[-1,-1,783,585]
},
si23774:{
name:'Image_Group_Text_165',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23774c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si23754',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si23782',
t:1250
}
,{
n:'si23792',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si23754',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si23774c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:23774,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23774',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si23782:{
name:'Text_434',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23782c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23774',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"70b8v","text":"At vero eos et accusamus et iusto.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":34,"style":"hlnk:"},{"offset":0,"length":34,"style":"hlnkt:wp"},{"offset":0,"length":34,"style":"textOutlineEnable:false"},{"offset":0,"length":34,"style":"opacity:1"},{"offset":0,"length":34,"style":"hlnke:true"},{"offset":0,"length":34,"style":"backgroundColor:unset"},{"offset":0,"length":34,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":34,"style":"textHighlightEnable:false"},{"offset":0,"length":34,"style":"textShadowEnable:false"},{"offset":0,"length":34,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23782]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23782c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:23782,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23782',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si23792:{
name:'Text_435',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23792c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23774',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"ajto9","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod tempor incididunt.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":89,"style":"hlnk:"},{"offset":0,"length":89,"style":"hlnkt:wp"},{"offset":0,"length":89,"style":"textOutlineEnable:false"},{"offset":0,"length":89,"style":"opacity:1"},{"offset":0,"length":89,"style":"hlnke:true"},{"offset":0,"length":89,"style":"backgroundColor:unset"},{"offset":0,"length":89,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":89,"style":"textHighlightEnable:false"},{"offset":0,"length":89,"style":"textShadowEnable:false"},{"offset":0,"length":89,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23792]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23792c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:23792,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23792',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si23802:{
name:'Button_276',
type:29,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23802c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"dsdis","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8aarc","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0472.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5latm","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"95q33","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"6smh3","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si23754',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23802]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23802c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:23802,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23802',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
si23826:{
name:'default_image6(3)',
type:15,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23826c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23818',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:782,
irh:584,
w:782,
h:584,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23826]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23826c:{
b:[0,0,782,584],
fh:false,
fw:false,
uid:23826,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'80.453%',
h:'96.053%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/020989.png',
dn:'si23826',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,783,585],
vb:[-1,-1,783,585]
},
si23838:{
name:'Image_Group_Text_166',
type:1268,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23838c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si23818',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si23846',
t:1250
}
,{
n:'si23856',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"visibilityInfo":{"slide-item-caption":true,"slide-item-subtitle":true},"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si23818',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si23838c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:23838,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23838',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si23846:{
name:'Text_436',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23846c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23838',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"4bbi8","text":"At vero eos et accusamus et iusto.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":34,"style":"hlnk:"},{"offset":0,"length":34,"style":"hlnkt:wp"},{"offset":0,"length":34,"style":"textOutlineEnable:false"},{"offset":0,"length":34,"style":"opacity:1"},{"offset":0,"length":34,"style":"hlnke:true"},{"offset":0,"length":34,"style":"backgroundColor:unset"},{"offset":0,"length":34,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":34,"style":"textHighlightEnable:false"},{"offset":0,"length":34,"style":"textShadowEnable:false"},{"offset":0,"length":34,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-subheading-6","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23846]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23846c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:23846,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23846',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si23856:{
name:'Text_437',
type:1250,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23856c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{},"tablet":{},"mobile":{}}}',
parentGroup:'si23838',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"alsci","text":"Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod tempor incididunt.","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":89,"style":"hlnk:"},{"offset":0,"length":89,"style":"hlnkt:wp"},{"offset":0,"length":89,"style":"textOutlineEnable:false"},{"offset":0,"length":89,"style":"opacity:1"},{"offset":0,"length":89,"style":"hlnke:true"},{"offset":0,"length":89,"style":"backgroundColor:unset"},{"offset":0,"length":89,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":89,"style":"textHighlightEnable:false"},{"offset":0,"length":89,"style":"textShadowEnable:false"},{"offset":0,"length":89,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-body-4","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23856]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23856c:{
b:[-1,-1,149,29],
fh:false,
fw:false,
uid:23856,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'15.432%',
h:'4.934%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23856',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-2,-2,150,30],
vb:[-2,-2,150,30]
},
si23866:{
name:'Button_277',
type:29,
from:463,
to:648,
rp:0,
rpa:0,
mdi:'si23866c',
tag:'slide-item-button',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:7,
isOverridden:false
}
]
,
widgetProps:'{"stateVisibility":{"normal":true,"selected":true,"disabled":false,"hover":true,"visited":false},"normal":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"9cp9o","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-normal","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_normal","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shouldRender":true,"visited":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"8audl","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-visited","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_visited","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"shapeData":{"type":"rect","attributes":{"rx":"20"}},"designOption":"DEFAULT_BUTTON_ITEM_OPTION","designOptionStyles":{},"iconProps":{"srcPath":"0472.svg","size":"medium","position":0,"offset":0},"currentState":"normal","selected":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"5e4u2","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-selected","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_selected","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}},"hover":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"7brte","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"},{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"}],"entityRanges":[],"data":{"presetId":"text-button-hover","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_hover","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":true}},"disabled":{"padding":"10","opacity":100,"textEnabled":true,"svgAppearenceProperties":{"iconEnabled":false,"fill":{"enabled":false,"color":"var(--color1)"},"stroke":{"enabled":false,"dasharray":0,"width":1,"linecap":2,"color":"var(--color5)"}},"editorState":{"blocks":[{"key":"1m3v3","text":"Button","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":6,"style":"textShadowX:0px"},{"offset":0,"length":6,"style":"textShadowY:0px"},{"offset":0,"length":6,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":6,"style":"WebkitTextStrokeWidth:unset"},{"offset":0,"length":6,"style":"textShadowBlur:0px"},{"offset":0,"length":6,"style":"textHighlightEnable:false"},{"offset":0,"length":6,"style":"textShadowEnable:false"},{"offset":0,"length":6,"style":"hlnk:"},{"offset":0,"length":6,"style":"overridden:false"},{"offset":0,"length":6,"style":"WebkitTextStrokeColor:unset"},{"offset":0,"length":6,"style":"hlnkt:wp"},{"offset":0,"length":6,"style":"textOutlineEnable:false"},{"offset":0,"length":6,"style":"opacity:1"},{"offset":0,"length":6,"style":"textShadowColor:ffffff00"},{"offset":0,"length":6,"style":"hlnke:true"},{"offset":0,"length":6,"style":"backgroundColor:unset"}],"entityRanges":[],"data":{"presetId":"text-button-disabled","listDepth":"0","listType":"S_Bullets08","listIndent":"100%","listSize":"100%","listColor":"#666666","overridden":"false"}}],"entityMap":{}},"shapePresetData":{"presetId":"button_shape_1_disabled","fillEnable":true,"fillType":1,"strokeEnable":true,"shadowEnable":false}}}',
parentGroup:'si23818',
retainState:false,
immo:false,
apsn:'Slide23468',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[]
,
te:true,
ie:false,
bt:-1,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[23866]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si23866c:{
b:[-2,-2,-1,-1],
fh:false,
fw:false,
uid:23866,
iso:false,
css:{
360:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'8.889%',
h:'4.211%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'5.333%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'-0.103%',
t:'-0.164%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'-0.103%',
lhID:-1,
lvEID:0,
lvV:'-0.164%',
lvID:-1,
w:'3.292%',
h:'5.263%',
cah:false,
cav:false,
rpmm:{
mw:'32px',
mh:'32px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si23866',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bp:10,
btha:1,
fa:100,
vbwr:[-2,-2,-1,-1],
vb:[-2,-2,-1,-1]
},
Slide23468:{
lb:'Roles',
id:23468,
from:463,
to:648,
iols:0,
i360qs:false,
sdu:6.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:true
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide23468c',
st:'Normal Slide',
sk:'Blank',
slideTag:'',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si24316',
t:1268
}
,{
n:'si23490',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#f8f7f4',
fa:1,
fe:true,
iso:true,
sc:'#333333',
ss:0,
sw:1,
sa:1,
se:true
}
,
bookmarks:[]
,
qs:'',
iph:{
24433:{
ts:''
}
,
24455:{
ts:''
}

}

},
Slide23468c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:23468,
dn:'Slide23468',
visible:'1'
},
si25444:{
name:'Scenario-Block_1',
type:1268,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25444c',
tag:'character-block-container',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":450,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"left":5,"right":5,"top":120,"bottom":120},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"0px"},"tablet":{},"mobile":{"flexDirection":"column"}},"appearanceProperties":{}}',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si25452',
t:1268
}
,{
n:'si25472',
t:1268
}
]
,
containerType:'scenario-block',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":450,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIT","padding":{"left":5,"right":5,"top":120,"bottom":120},"designOptionStyles":{"all":{"display":"flex","flexDirection":"row","gap":"0px"},"tablet":{},"mobile":{"flexDirection":"column"}},"appearanceProperties":{}}',
option:'SINGLE_SCENARIO_CUSTOM_OPTION_3',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si25444c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:25444,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25444',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#f1eee6',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si25452:{
name:'character-image_1',
type:1268,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25452c',
tag:'character-container-1',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"visibilityInfo":{"character-image":true},"imageHeight":600,"alignment":{},"canBeCard":false,"isCharacterImageContainer":true,"shouldRender":true,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"width":"280px","alignSelf":"center"},"tablet":{},"mobile":{"width":"150px","alignSelf":"center"}}}',
parentGroup:'si25444',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si25460',
t:15
}
]
,
containerType:'character-container-1',
widgetProps:'{"visibilityInfo":{"character-image":true},"imageHeight":600,"alignment":{},"canBeCard":false,"isCharacterImageContainer":true,"shouldRender":true,"imageBehavior":"IG_FIT","padding":{"top":10,"bottom":10,"left":2,"right":2},"designOptionStyles":{"all":{"width":"280px","alignSelf":"center"},"tablet":{},"mobile":{"width":"150px","alignSelf":"center"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si25444',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si25452c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:25452,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25452',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si25460:{
name:'Stick_Man06',
type:15,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25460c',
tag:'character-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"},"border":{"type":0,"size":10,"color":"#FFFFFFFF","enabled":true,"style":0}},"designOptionStyles":{"all":{"flex":"none"},"tablet":{},"mobile":{}},"imageHeight":300}',
parentGroup:'si25452',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:1055,
irh:2000,
w:1055,
h:2000,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[25460]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si25460c:{
b:[0,0,1055,2000],
fh:false,
fw:false,
uid:25460,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'57.613%',
h:'197.368%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'57.613%',
h:'197.368%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'57.613%',
h:'197.368%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025516.png',
dn:'si25460',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1056,2001],
vb:[-1,-1,1056,2001]
},
si25472:{
name:'Character_Group_1',
type:1268,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25472c',
tag:'character-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-body":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"CENTER","slide-item-body":"CENTER","slide-item-button":"CENTER"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"#F1EEE6FF","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
parentGroup:'si25444',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si25480',
t:1250
}
,{
n:'si25490',
t:1250
}
]
,
containerType:'character-card',
widgetProps:'{"visibilityInfo":{"slide-item-heading":true,"slide-item-body":true,"slide-item-button":false,"card":true},"padding":{"top":20,"bottom":20,"left":20,"right":20},"alignment":{"slide-item-heading":"CENTER","slide-item-body":"CENTER","slide-item-button":"CENTER"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"#F1EEE6FF","size":8,"type":0},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si25444',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si25472c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:25472,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25472',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si25480:{
name:'Text_440',
type:1250,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25480c',
tag:'slide-item-heading',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"marginLeft":"0px"},"tablet":{},"mobile":{}}}',
parentGroup:'si25472',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"dpf0t","text":"Working as a Team","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"hlnke:true"},{"offset":0,"length":17,"style":"defaultTextShadow:none"},{"offset":0,"length":17,"style":"textShadow:none"},{"offset":0,"length":17,"style":"tablet-fontSize:36"},{"offset":0,"length":17,"style":"textShadowX:0px"},{"offset":0,"length":17,"style":"fontStretch:normal"},{"offset":0,"length":17,"style":"fontType:regular"},{"offset":0,"length":17,"style":"color:#333333"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textShadowY:4px"},{"offset":0,"length":17,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":17,"style":"desktop-fontSize:80"},{"offset":0,"length":17,"style":"lineHeight:135%"},{"offset":0,"length":17,"style":"letterSpacing:0%"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textTransform:none"},{"offset":0,"length":17,"style":"textShadowOpacity:none"},{"offset":0,"length":17,"style":"overridden:true"},{"offset":0,"length":17,"style":"textDecoration:none"},{"offset":0,"length":17,"style":"fontFamily:Georgia"},{"offset":0,"length":17,"style":"borderBottomStyle:none"},{"offset":0,"length":17,"style":"fontWeight:bold"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"textShadowBlur:8px"},{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"fontStyle:normal"},{"offset":0,"length":17,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"textOutlineEnable:false"},{"offset":0,"length":17,"style":"mobile-fontSize:36"},{"offset":0,"length":17,"style":"opacity:1"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"center","marginBottom":"0%","presetId":"text-heading-8","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[25480]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si25480c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:25480,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25480',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si25490:{
name:'Text_441',
type:1250,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25490c',
tag:'slide-item-body',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingBottom":"10px","margin":"0 auto"},"tablet":{},"mobile":{}}}',
parentGroup:'si25472',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"bnvfr","text":"We communicate through our in person and remote meetups, as well as through Slack ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":82,"style":"textDecoration:none"},{"offset":0,"length":82,"style":"desktop-fontSize:30"},{"offset":0,"length":82,"style":"fontFamily:Georgia"},{"offset":0,"length":82,"style":"borderBottomStyle:none"},{"offset":0,"length":82,"style":"textShadowEnable:false"},{"offset":0,"length":82,"style":"hlnk:"},{"offset":0,"length":82,"style":"fontWeight:normal"},{"offset":0,"length":82,"style":"textShadowBlur:8px"},{"offset":0,"length":82,"style":"mobile-fontSize:21"},{"offset":0,"length":82,"style":"defaultTextShadow:none"},{"offset":0,"length":82,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":82,"style":"hlnkt:wp"},{"offset":0,"length":82,"style":"fontStyle:normal"},{"offset":0,"length":82,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":82,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":82,"style":"fontType:italic"},{"offset":0,"length":82,"style":"textOutlineEnable:false"},{"offset":0,"length":82,"style":"tablet-fontSize:21"},{"offset":0,"length":82,"style":"opacity:1"},{"offset":0,"length":82,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":82,"style":"hlnke:true"},{"offset":0,"length":82,"style":"backgroundColor:unset"},{"offset":0,"length":82,"style":"textShadow:none"},{"offset":0,"length":82,"style":"textShadowX:0px"},{"offset":0,"length":82,"style":"fontStretch:normal"},{"offset":0,"length":82,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":82,"style":"textShadowY:4px"},{"offset":0,"length":82,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":82,"style":"lineHeight:135%"},{"offset":0,"length":82,"style":"letterSpacing:0%"},{"offset":0,"length":82,"style":"textHighlightEnable:false"},{"offset":0,"length":82,"style":"textTransform:none"},{"offset":0,"length":82,"style":"color:#020C1C"},{"offset":0,"length":82,"style":"textShadowOpacity:none"},{"offset":0,"length":82,"style":"overridden:true"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"center","marginBottom":"0%","presetId":"text-body-5","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[25490]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si25490c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:25490,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25490',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si25630:{
name:'Image_12',
type:1268,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25630c',
tag:'container-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":623,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIXED_HEIGHT","padding":{"left":0,"right":0,"top":0,"bottom":0},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"justifyContent":"flex-start"},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":1}',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si25638',
t:1268
}
]
,
containerType:'image',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":623,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIXED_HEIGHT","padding":{"left":0,"right":0,"top":0,"bottom":0},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"justifyContent":"flex-start"},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":1}',
option:'INTRODUCTION_SINGLE_IMAGE_OPTION_ROW_C3',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si25630c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:25630,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25630',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c6)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si25638:{
name:'Image_Group_12',
type:1268,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25638c',
tag:'container-image-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-buttons":false,"card":true},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":28,"bottom":28,"right":28,"left":28},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"#666666FF","size":8,"type":3},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","paddingLeft":"60px","paddingRight":"60px","boxSizing":"border-box"},"tablet":{"display":"flex","flexDirection":"column","paddingLeft":"20px","paddingRight":"20px"},"mobile":{"display":"flex","flexDirection":"column","paddingLeft":"20px","paddingRight":"20px"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"2 / 1 / span 1 / span 2","marginTop":"10px"},"tablet":{},"mobile":{}}}}',
parentGroup:'si25630',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si25646',
t:15
}
,{
n:'si25658',
t:1268
}
]
,
containerType:'image-single-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-buttons":false,"card":true},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":28,"bottom":28,"right":28,"left":28},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"#666666FF","size":8,"type":3},"cornerRadius":{"type":1,"value":{"topLeft":0,"bottomLeft":0,"bottomRight":0,"topRight":0}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"#666666FF"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","paddingLeft":"60px","paddingRight":"60px","boxSizing":"border-box"},"tablet":{"display":"flex","flexDirection":"column","paddingLeft":"20px","paddingRight":"20px"},"mobile":{"display":"flex","flexDirection":"column","paddingLeft":"20px","paddingRight":"20px"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"2 / 1 / span 1 / span 2","marginTop":"10px"},"tablet":{},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si25630',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si25638c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:25638,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25638',
visible:1,
effectiveVi:1,
JSONEffectData:false,
gf:{
b:[0,0,0,0],
t:3,
x1:0,
y1:0,
x2:100,
y2:100,
s:0,
cs:[{
p:0,
c:'#f8f7f4',
o:255
}
,{
p:100,
c:'#d6d5d1',
o:255
}
]

}
,
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si25646:{
name:'boxjelly-faraway-pic',
type:15,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25646c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{"shadowX":0,"shadowY":5,"shadowBlur":10,"enabled":true,"color":"var(--design-option-color4)"},"border":{"type":0,"size":5,"color":"var(--design-option-color1)","enabled":true,"style":0}},"designOptionStyles":{"all":{"imageContainerStyles":{"minWidth":"100%","maxWidth":"100%","gridArea":"1 / 2 / span 1 / span 1"},"borderRadius":"0px 0px 40px 40px"},"tablet":{"height":"100%"},"mobile":{"imageContainerStyles":{"minWidth":"100%","maxWidth":"100%"},"height":"100%","borderRadius":"0"}}}',
parentGroup:'si25638',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:0,
imageFocus:0,
irw:4032,
irh:3024,
w:4032,
h:3024,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[25646]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si25646c:{
b:[0,0,4032,3024],
fh:false,
fw:false,
uid:25646,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'131.579%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'131.579%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'281.070%',
h:'131.579%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025079.jpg',
dn:'si25646',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,4033,3025],
vb:[-1,-1,4033,3025]
},
si25658:{
name:'Image_Group_Text_168',
type:1268,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25658c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
parentGroup:'si25638',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si25666',
t:1250
}
,{
n:'si25676',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"gap":"8px"},"tablet":{},"mobile":{}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si25638',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si25658c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:25658,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25658',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si25666:{
name:'Text_444',
type:1250,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25666c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingLeft":"0","paddingRight":"60px","grid-area":"auto","marginBottom":"18px"},"tablet":{"paddingRight":"30px"},"mobile":{}}}',
parentGroup:'si25658',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"1n3ks","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-1","listSize":"100%"}},{"key":"abt5k","text":"Weekly Meetups","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":14,"style":"hlnk:"},{"offset":0,"length":14,"style":"textShadowBlur:8px"},{"offset":0,"length":14,"style":"tablet-fontSize:60"},{"offset":0,"length":14,"style":"backgroundColor:unset"},{"offset":0,"length":14,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":14,"style":"hlnkt:wp"},{"offset":0,"length":14,"style":"fontStyle:normal"},{"offset":0,"length":14,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":14,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":14,"style":"textOutlineEnable:false"},{"offset":0,"length":14,"style":"opacity:1"},{"offset":0,"length":14,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":14,"style":"mobile-fontSize:48"},{"offset":0,"length":14,"style":"hlnke:true"},{"offset":0,"length":14,"style":"defaultTextShadow:none"},{"offset":0,"length":14,"style":"letterSpacing:-1%"},{"offset":0,"length":14,"style":"textShadow:none"},{"offset":0,"length":14,"style":"textShadowX:0px"},{"offset":0,"length":14,"style":"fontStretch:normal"},{"offset":0,"length":14,"style":"fontType:regular"},{"offset":0,"length":14,"style":"lineHeight:107%"},{"offset":0,"length":14,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":14,"style":"textShadowY:4px"},{"offset":0,"length":14,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":14,"style":"desktop-fontSize:80"},{"offset":0,"length":14,"style":"textHighlightEnable:false"},{"offset":0,"length":14,"style":"textTransform:none"},{"offset":0,"length":14,"style":"color:#020C1C"},{"offset":0,"length":14,"style":"textShadowOpacity:none"},{"offset":0,"length":14,"style":"overridden:true"},{"offset":0,"length":14,"style":"textDecoration:none"},{"offset":0,"length":14,"style":"fontFamily:Georgia"},{"offset":0,"length":14,"style":"borderBottomStyle:none"},{"offset":0,"length":14,"style":"fontWeight:bold"},{"offset":0,"length":14,"style":"textShadowEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-1","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[25666]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si25666c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:25666,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25666',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si25676:{
name:'Text_445',
type:1250,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25676c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"paddingLeft":"0","paddingRight":"60px"},"tablet":{"paddingRight":"30px"},"mobile":{}}}',
parentGroup:'si25658',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"3f5p4","text":"We have weekly meetups that alternate between online and in-person meetings the first 3 Mondays of each month. ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":111,"style":"tablet-fontSize:21"},{"offset":0,"length":111,"style":"opacity:1"},{"offset":0,"length":111,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":111,"style":"hlnke:true"},{"offset":0,"length":111,"style":"defaultTextShadow:none"},{"offset":0,"length":111,"style":"textShadow:none"},{"offset":0,"length":111,"style":"textShadowX:0px"},{"offset":0,"length":111,"style":"fontStretch:normal"},{"offset":0,"length":111,"style":"fontType:regular"},{"offset":0,"length":111,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":111,"style":"textShadowY:4px"},{"offset":0,"length":111,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":111,"style":"lineHeight:135%"},{"offset":0,"length":111,"style":"letterSpacing:0%"},{"offset":0,"length":111,"style":"textHighlightEnable:false"},{"offset":0,"length":111,"style":"textTransform:none"},{"offset":0,"length":111,"style":"color:#020C1C"},{"offset":0,"length":111,"style":"textShadowOpacity:none"},{"offset":0,"length":111,"style":"overridden:true"},{"offset":0,"length":111,"style":"textDecoration:none"},{"offset":0,"length":111,"style":"desktop-fontSize:30"},{"offset":0,"length":111,"style":"fontFamily:Georgia"},{"offset":0,"length":111,"style":"borderBottomStyle:none"},{"offset":0,"length":111,"style":"textShadowEnable:false"},{"offset":0,"length":111,"style":"hlnk:"},{"offset":0,"length":111,"style":"fontWeight:normal"},{"offset":0,"length":111,"style":"textShadowBlur:8px"},{"offset":0,"length":111,"style":"mobile-fontSize:21"},{"offset":0,"length":111,"style":"backgroundColor:unset"},{"offset":0,"length":111,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":111,"style":"hlnkt:wp"},{"offset":0,"length":111,"style":"fontStyle:normal"},{"offset":0,"length":111,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":111,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":111,"style":"textOutlineEnable:false"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-detail-4","listSize":"100%"}},{"key":"dcvae","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-detail-4","listSize":"100%"}},{"key":"941v4","text":"The only time commitment we ask contributors for are during these 2 hour weekly meetups. What we typically do during these meetups is ask any questions that we feel are better asked in person, work on any tasks for our project. There are also opportunites to network and socialize!","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":281,"style":"hlnkt:wp"},{"offset":0,"length":281,"style":"fontStyle:normal"},{"offset":0,"length":281,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":281,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":281,"style":"textOutlineEnable:false"},{"offset":0,"length":281,"style":"tablet-fontSize:21"},{"offset":0,"length":281,"style":"opacity:1"},{"offset":0,"length":281,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":281,"style":"hlnke:true"},{"offset":0,"length":281,"style":"defaultTextShadow:none"},{"offset":0,"length":281,"style":"textShadow:none"},{"offset":0,"length":281,"style":"textShadowX:0px"},{"offset":0,"length":281,"style":"fontStretch:normal"},{"offset":0,"length":281,"style":"fontType:regular"},{"offset":0,"length":281,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":281,"style":"textShadowY:4px"},{"offset":0,"length":281,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":281,"style":"lineHeight:135%"},{"offset":0,"length":281,"style":"letterSpacing:0%"},{"offset":0,"length":281,"style":"textHighlightEnable:false"},{"offset":0,"length":281,"style":"textTransform:none"},{"offset":0,"length":281,"style":"color:#020C1C"},{"offset":0,"length":281,"style":"textShadowOpacity:none"},{"offset":0,"length":281,"style":"overridden:true"},{"offset":0,"length":281,"style":"textDecoration:none"},{"offset":0,"length":281,"style":"desktop-fontSize:30"},{"offset":0,"length":281,"style":"fontFamily:Georgia"},{"offset":0,"length":281,"style":"borderBottomStyle:none"},{"offset":0,"length":281,"style":"textShadowEnable:false"},{"offset":0,"length":281,"style":"hlnk:"},{"offset":0,"length":281,"style":"fontWeight:normal"},{"offset":0,"length":281,"style":"textShadowBlur:8px"},{"offset":0,"length":281,"style":"mobile-fontSize:21"},{"offset":0,"length":281,"style":"backgroundColor:unset"},{"offset":0,"length":281,"style":"WebkitTextStrokeWidth:1px"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-detail-4","listSize":"100%"}},{"key":"57ufl","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-detail-4","listSize":"100%"}},{"key":"39ct7","text":"Sometimes after an in person meeting is over, we have an optional hangout at a nearby boba shop!","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":96,"style":"textShadowBlur:8px"},{"offset":0,"length":96,"style":"mobile-fontSize:21"},{"offset":0,"length":96,"style":"backgroundColor:unset"},{"offset":0,"length":96,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":96,"style":"hlnkt:wp"},{"offset":0,"length":96,"style":"fontStyle:normal"},{"offset":0,"length":96,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":96,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":96,"style":"textOutlineEnable:false"},{"offset":0,"length":96,"style":"tablet-fontSize:21"},{"offset":0,"length":96,"style":"opacity:1"},{"offset":0,"length":96,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":96,"style":"hlnke:true"},{"offset":0,"length":96,"style":"defaultTextShadow:none"},{"offset":0,"length":96,"style":"textShadow:none"},{"offset":0,"length":96,"style":"textShadowX:0px"},{"offset":0,"length":96,"style":"fontStretch:normal"},{"offset":0,"length":96,"style":"fontType:regular"},{"offset":0,"length":96,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":96,"style":"textShadowY:4px"},{"offset":0,"length":96,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":96,"style":"lineHeight:135%"},{"offset":0,"length":96,"style":"letterSpacing:0%"},{"offset":0,"length":96,"style":"textHighlightEnable:false"},{"offset":0,"length":96,"style":"textTransform:none"},{"offset":0,"length":96,"style":"color:#020C1C"},{"offset":0,"length":96,"style":"textShadowOpacity:none"},{"offset":0,"length":96,"style":"overridden:true"},{"offset":0,"length":96,"style":"textDecoration:none"},{"offset":0,"length":96,"style":"desktop-fontSize:30"},{"offset":0,"length":96,"style":"fontFamily:Georgia"},{"offset":0,"length":96,"style":"borderBottomStyle:none"},{"offset":0,"length":96,"style":"textShadowEnable:false"},{"offset":0,"length":96,"style":"hlnk:"},{"offset":0,"length":96,"style":"fontWeight:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-detail-4","listSize":"100%"}},{"key":"6rft2","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-detail-4","listSize":"100%"}},{"key":"1rrg7","text":"Check out the meetups to RSVP and be updated on any schedule changes, events, and more information about the meetups. ","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":118,"style":"borderBottomStyle:none"},{"offset":0,"length":118,"style":"textShadowEnable:false"},{"offset":0,"length":14,"style":"hlnk:"},{"offset":21,"length":97,"style":"hlnk:"},{"offset":0,"length":118,"style":"fontWeight:normal"},{"offset":0,"length":118,"style":"textShadowBlur:8px"},{"offset":0,"length":118,"style":"backgroundColor:unset"},{"offset":0,"length":118,"style":"mobile-fontSize:21"},{"offset":0,"length":118,"style":"hlnkt:wp"},{"offset":0,"length":118,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":118,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":118,"style":"fontStyle:normal"},{"offset":0,"length":118,"style":"textOutlineEnable:false"},{"offset":0,"length":118,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":118,"style":"tablet-fontSize:21"},{"offset":0,"length":118,"style":"opacity:1"},{"offset":0,"length":118,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":118,"style":"hlnke:true"},{"offset":0,"length":118,"style":"defaultTextShadow:none"},{"offset":0,"length":118,"style":"textShadow:none"},{"offset":0,"length":118,"style":"textShadowX:0px"},{"offset":0,"length":118,"style":"fontStretch:normal"},{"offset":0,"length":118,"style":"fontType:regular"},{"offset":0,"length":118,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":118,"style":"textShadowY:4px"},{"offset":0,"length":118,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":118,"style":"lineHeight:135%"},{"offset":0,"length":118,"style":"letterSpacing:0%"},{"offset":0,"length":118,"style":"textHighlightEnable:false"},{"offset":0,"length":118,"style":"textTransform:none"},{"offset":0,"length":118,"style":"color:#020C1C"},{"offset":14,"length":7,"style":"hlnk:https://www.meetup.com/code-with-aloha/"},{"offset":0,"length":118,"style":"textShadowOpacity:none"},{"offset":0,"length":118,"style":"overridden:true"},{"offset":0,"length":118,"style":"textDecoration:none"},{"offset":0,"length":118,"style":"desktop-fontSize:30"},{"offset":0,"length":118,"style":"fontFamily:Georgia"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-detail-4","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[25676]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si25676c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:25676,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'0.164%',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25676',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si25524:{
name:'Image_11',
type:1268,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25524c',
tag:'container-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":520,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIXED_HEIGHT","padding":{"left":3,"right":5,"top":53,"bottom":53},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":1.2384615384615385}',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si25532',
t:1268
}
]
,
containerType:'image',
widgetProps:'{"visibilityInfo":{"isDerivedFromChild":true},"imageHeight":520,"autoFit":true,"alignment":{"isDerivedFromChild":true},"canBeCard":false,"imageBehavior":"IG_FIXED_HEIGHT","padding":{"left":3,"right":5,"top":53,"bottom":53},"groupedItemsVisibility":{"isDerivedFromChild":true},"designOptionStyles":{"all":{"display":"flex","flexDirection":"column"},"tablet":{},"mobile":{}},"appearanceProperties":{},"imageAspectRatio":1.2384615384615385}',
option:'SINGLE_IMAGE_OPTION_ROW_C1',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si25524c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:25524,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25524',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#f1eee6',
fe:true,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'var(--c4)',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si25532:{
name:'Image_Group_11',
type:1268,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25532c',
tag:'container-image-card',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:true
}
,{
presetId:'',
presetType:2,
isOverridden:true
}
]
,
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":30,"bottom":30,"left":30,"right":30},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":3},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridTemplateRows":"minmax(10px,auto)","gridGap":"0 10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"2 / 1 / span 1 / span 2","marginLeft":"30px","align-items":"flex-end"},"tablet":{"marginLeft":"10px"},"mobile":{}}}}',
parentGroup:'si25524',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si25540',
t:15
}
,{
n:'si25552',
t:1268
}
]
,
containerType:'image-single-card',
widgetProps:'{"visibilityInfo":{"slide-item-image":true,"slide-item-caption":true,"slide-item-subtitle":true,"slide-item-buttons":false,"card":false},"groupedItemsVisibility":{"slide-item-buttons":1},"padding":{"top":30,"bottom":30,"left":30,"right":30},"alignment":{"slide-item-image":"LEFT","slide-item-caption":"LEFT","slide-item-subtitle":"LEFT","slide-item-buttons":"LEFT"},"canBeCard":true,"appearanceProperties":{"border":{"enabled":false,"color":"var(--c4)","size":8,"type":3},"cornerRadius":{"type":1,"value":{"topLeft":4,"bottomLeft":4,"bottomRight":4,"topRight":4}},"shadow":{"shadowX":0,"shadowY":0,"shadowBlur":10,"enabled":false,"color":"var(--c4)"}},"designOptionStyles":{"all":{"display":"grid","gridTemplateColumns":"1fr 1fr","gridTemplateRows":"minmax(10px,auto)","gridGap":"0 10px"},"tablet":{"display":"flex","flexDirection":"column"},"mobile":{"display":"flex","flexDirection":"column"}},"childNodesCustomStyles":{"slide-item-buttons":{"all":{"gridArea":"2 / 1 / span 1 / span 2","marginLeft":"30px","align-items":"flex-end"},"tablet":{"marginLeft":"10px"},"mobile":{}}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si25524',
selectable:true,
trin:0,
trout:0,
isDD:false
},
si25532c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:25532,
iso:true,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25532',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'var(--c1)',
fe:false,
fca:1,
fa:100,
iso:true,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si25540:{
name:'Slack-logo-RGB',
type:15,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25540c',
tag:'slide-item-image',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'theme_image_default',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"shouldRender":true,"imageFilterProps":{"blur":0,"brightness":0,"contrast":0},"appearanceProperties":{"shadow":{},"border":{}},"designOptionStyles":{"all":{"borderRadius":"0 50% 50% 0","overflow":"hidden"},"tablet":{"borderRadius":"0"},"mobile":{"borderRadius":"0"}}}',
parentGroup:'si25532',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
iip:{
cs:false,
fh:false,
fw:false,
fl:-1,
b:0,
c:0,
br:0,
ifbm:'normal',
ift:'Normal',
ifi:0,
iff:{
bc:'#ffe2c8',
o:1
}
,
o:100,
tiletype:1,
imageFocus:0,
irw:1035,
irh:263,
w:1035,
h:263,
x:0,
y:0
}
,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[25540]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si25540c:{
b:[0,0,1035,263],
fh:false,
fw:false,
uid:25540,
iso:false,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'106.481%',
h:'43.257%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'106.481%',
h:'43.257%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'106.481%',
h:'43.257%',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
ip:'dr/025628.png',
dn:'si25540',
visible:1,
effectiveVi:1,
JSONEffectData:false,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1036,264],
vb:[-1,-1,1036,264]
},
si25552:{
name:'Image_Group_Text_167',
type:1268,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25552c',
tag:'container-image-text',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:14,
isOverridden:false
}
,{
presetId:'',
presetType:2,
isOverridden:false
}
]
,
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"30px"},"tablet":{"paddingLeft":"0px"},"mobile":{"paddingLeft":"0px"}}}',
parentGroup:'si25532',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
si:[{
n:'si25560',
t:1250
}
,{
n:'si25570',
t:1250
}
]
,
containerType:'single-image-text',
widgetProps:'{"padding":{"top":0,"bottom":0,"left":0,"right":0},"designOptionStyles":{"all":{"paddingLeft":"30px"},"tablet":{"paddingLeft":"0px"},"mobile":{"paddingLeft":"0px"}}}',
option:'',
padding:{
left:0,
right:0,
top:0,
bottom:0
}
,
parent:'si25532',
selectable:false,
trin:0,
trout:0,
isDD:false
},
si25552c:{
b:[0,0,0,0],
fh:false,
fw:false,
uid:25552,
iso:false,
css:{
360:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0px',
t:'0px',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0px',
lhID:-1,
lvEID:0,
lvV:'0px',
lvID:-1,
w:'0px',
h:'0px',
cah:false,
cav:false,
rpmm:{
mw:'1px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25552',
visible:1,
effectiveVi:1,
JSONEffectData:false,
bc:'#ffffff',
fe:true,
fca:1,
fa:100,
sde:false,
scp:0,
sc:'#0080ff',
sw:1,
ss:0,
sa:1,
se:false,
vbwr:[-1,-1,1,1],
vb:[-1,-1,1,1]
},
si25560:{
name:'Text_442',
type:1250,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25560c',
tag:'slide-item-caption',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"align-items":"start"},"tablet":{},"mobile":{}}}',
parentGroup:'si25552',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"b4gcq","text":"Staying Connected","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":17,"style":"fontType:regular"},{"offset":0,"length":17,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":17,"style":"textShadowY:4px"},{"offset":0,"length":17,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":17,"style":"desktop-fontSize:80"},{"offset":0,"length":17,"style":"textHighlightEnable:false"},{"offset":0,"length":17,"style":"textTransform:none"},{"offset":0,"length":17,"style":"color:#020C1C"},{"offset":0,"length":17,"style":"lineHeight:110%"},{"offset":0,"length":17,"style":"textShadowOpacity:none"},{"offset":0,"length":17,"style":"overridden:true"},{"offset":0,"length":17,"style":"textDecoration:none"},{"offset":0,"length":17,"style":"fontFamily:Georgia"},{"offset":0,"length":17,"style":"borderBottomStyle:none"},{"offset":0,"length":17,"style":"fontWeight:bold"},{"offset":0,"length":17,"style":"textShadowEnable:false"},{"offset":0,"length":17,"style":"hlnk:"},{"offset":0,"length":17,"style":"textShadowBlur:8px"},{"offset":0,"length":17,"style":"tablet-fontSize:60"},{"offset":0,"length":17,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"defaultTextShadow:none"},{"offset":0,"length":17,"style":"fontStyle:normal"},{"offset":0,"length":17,"style":"hlnkt:wp"},{"offset":0,"length":17,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":17,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"textOutlineEnable:false"},{"offset":0,"length":17,"style":"letterSpacing:-4%"},{"offset":0,"length":17,"style":"opacity:1"},{"offset":0,"length":17,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":17,"style":"mobile-fontSize:48"},{"offset":0,"length":17,"style":"hlnke:true"},{"offset":0,"length":17,"style":"backgroundColor:unset"},{"offset":0,"length":17,"style":"textShadow:none"},{"offset":0,"length":17,"style":"textShadowX:0px"},{"offset":0,"length":17,"style":"fontStretch:normal"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-heading-2","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[25560]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si25560c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:25560,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25560',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
si25570:{
name:'Text_443',
type:1250,
from:649,
to:834,
rp:0,
rpa:0,
mdi:'si25570c',
tag:'slide-item-subtitle',
v:0,
enabled:true,
defEn:true,
vu:[],
siaf:0,
sid:6.2,
presetData:[{
presetId:'',
presetType:1,
isOverridden:true
}
]
,
widgetProps:'{"shouldRender":true,"designOptionStyles":{"all":{"marginTop":"50px"},"tablet":{"marginTop":"0px"},"mobile":{"marginTop":"0px"}}}',
parentGroup:'si25552',
retainState:false,
immo:false,
apsn:'Slide25422',
efph:{
}
,
eflh:[],
iflbx:false,
ipflbx:true,
text:'{"blocks":[{"key":"vt3a","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-detail-4","listSize":"100%"}},{"key":"3bqrl","text":"We primarily communicate through slack when we need help outside of meetups, keep up with new events, and anything else","type":"unstyled","depth":0,"inlineStyleRanges":[{"offset":0,"length":119,"style":"color:#020C1C"},{"offset":0,"length":119,"style":"textShadowOpacity:none"},{"offset":0,"length":119,"style":"overridden:true"},{"offset":0,"length":119,"style":"textDecoration:none"},{"offset":0,"length":119,"style":"desktop-fontSize:30"},{"offset":0,"length":119,"style":"fontFamily:Georgia"},{"offset":0,"length":119,"style":"borderBottomStyle:none"},{"offset":0,"length":119,"style":"textShadowEnable:false"},{"offset":0,"length":119,"style":"hlnk:"},{"offset":0,"length":119,"style":"fontWeight:normal"},{"offset":0,"length":119,"style":"textShadowBlur:8px"},{"offset":0,"length":119,"style":"mobile-fontSize:21"},{"offset":0,"length":119,"style":"tablet-fontSize:24"},{"offset":0,"length":119,"style":"WebkitTextStrokeWidth:1px"},{"offset":0,"length":119,"style":"hlnkt:wp"},{"offset":0,"length":119,"style":"fontStyle:normal"},{"offset":0,"length":119,"style":"WebkitTextStrokeColor:#F1EEE6"},{"offset":0,"length":119,"style":"defaultTextStrokeWidth:1px"},{"offset":0,"length":119,"style":"textOutlineEnable:false"},{"offset":0,"length":119,"style":"opacity:1"},{"offset":0,"length":119,"style":"defaultTextStrokeColor:#F1EEE6"},{"offset":0,"length":119,"style":"hlnke:true"},{"offset":0,"length":119,"style":"defaultTextShadow:none"},{"offset":0,"length":119,"style":"backgroundColor:unset"},{"offset":0,"length":119,"style":"textShadow:none"},{"offset":0,"length":119,"style":"textShadowX:0px"},{"offset":0,"length":119,"style":"fontStretch:normal"},{"offset":0,"length":119,"style":"fontType:regular"},{"offset":0,"length":119,"style":"defaultBackgroundColor:#E8D01B"},{"offset":0,"length":119,"style":"textShadowY:4px"},{"offset":0,"length":119,"style":"textShadowColor:#F1EEE61F"},{"offset":0,"length":119,"style":"lineHeight:135%"},{"offset":0,"length":119,"style":"letterSpacing:0%"},{"offset":0,"length":119,"style":"textHighlightEnable:false"},{"offset":0,"length":119,"style":"textTransform:none"}],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-detail-4","listSize":"100%"}},{"key":"3rp68","text":"","type":"unstyled","depth":0,"inlineStyleRanges":[],"entityRanges":[],"data":{"listDepth":"0","listColor":"#666666","verticalAlignMarginBottom":"0px","listIndent":"100%","overridden":"true","marginLeft":"0px","verticalAlignMarginTop":"auto","listType":"S_Bullets08","textAlign":"left","marginBottom":"0%","presetId":"text-detail-4","listSize":"100%"}}],"entityMap":{}}',
autoGrow:false,
tbqt:0,
trin:0,
trout:0,
stl:[{
stn:'Normal',
stt:0,
stsi:[25570]
}
]
,
stis:0,
bstiid:-1,
sipst:0,
sicbs:false,
sihhs:false,
sihds:false,
siq:false,
isDD:false
},
si25570c:{
b:[0,0,1,1],
fh:false,
fw:false,
uid:25570,
iso:true,
css:{
360:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
600:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}
,
972:{
l:'0.000%',
t:'0.000%',
b:'auto',
r:'auto',
lhEID:0,
lhV:'0.000%',
lhID:-1,
lvEID:0,
lvV:'0.000%',
lvID:-1,
w:'0.103%',
h:'auto',
apr:'1.000',
cah:false,
cav:false,
rpmm:{
mw:'0px',
mh:'1px',
Mw:'',
Mh:''
}
,
p:'absolute',
ipiv:1
}

}
,
sr:cp.fd,
dn:'si25570',
visible:1,
effectiveVi:1,
JSONEffectData:false,
vbwr:[-1,-1,2,2],
vb:[-1,-1,2,2]
},
Slide25422:{
lb:'Collaboration _ Meetups',
id:25422,
from:649,
to:834,
iols:0,
i360qs:false,
sdu:6.2,
presetData:[{
presetId:'',
presetType:3,
isOverridden:false
}
]
,
propTxtScaling:false,
minFontSizeScaling:14,
useng:true,
transition:{
type:0
}
,
mmot:false,
mdi:'Slide25422c',
st:'Normal Slide',
sk:'Scenario',
slideTag:'scenario-slide1',
type:30,
accProps:{
a11yTabOrder:[],
a11yReviewTabOrder:[]
}
,
si:[{
n:'si25444',
t:1268
}
,{
n:'si25630',
t:1268
}
,{
n:'si25524',
t:1268
}
]
,
iph:[]
,
v:false,
canvasData:{
bc:'#ffffff',
fa:1,
fe:true,
iso:false,
se:false
}
,
bookmarks:[]
,
qs:''
},
Slide25422c:{
b:[0,0,0,0],
css:{
}
,
sr:cp.fd,
uid:25422,
dn:'Slide25422',
visible:'1'
},
quizzingData:{
allowBackwardMovement:true,
allowReviewMode:true,
reviewShowAnswers:true,
it:false,
firstSlideInQuiz:-1,
lastSlideInQuiz:-1,
quizScopeEndSlide:-1,
maxScore:0,
minScore:0,
maxPretestScore:0,
numQuestionsInQuiz:0,
numQuizAttemptsAllowed:1,
passingScore:0,
quizInfoCurrentAttempt:0,
quizInfoPercentScored:0,
quizMandateLevel:0,
quizID:199,
questionPoolsInitialized:true,
quizInfoAttempts:1,
quizInfoLastSlidePointScored:0,
quizInfoMaxAttemptsOnCurrentQuestion:1,
quizInfoPassFail:0,
quizInfoPointsPerQuestionSlide:0,
quizInfoPointsScored:0,
quizInfoQuizPassPercent:80,
quizInfoQuizPassPoints:0,
quizInfoTotalCorrectAnswers:0,
quizInfoTotalProjectPoints:0,
quizInfoTotalQuestionsPerProject:0,
quizInfoTotalQuizPoints:0,
quizInfoTotalUnansweredQuestions:0,
reportingEnabled:false,
submitAll:false,
hidePlaybarInQuiz:false,
quizBranchAware:false,
passFailPassingScoreTypeInPrecent:true,
passFailPassingScoreValue:80,
showRetake:false,
showReviewButtons:true,
oid:'$$OBJECTIVE_ID',
quizVariableVsIdMap:{
learnerId:'var346',
learnerName:'var347',
isInQuizScope:'var368',
isInReviewMode:'var369',
quizInfoPercentScored:'var370',
quizInfoAttempts:'var371',
quizInfoPassFail:'var372',
score:'var373',
quizInfoQuizPassPercent:'var374',
passingScore:'var375',
quizInfoTotalCorrectAnswers:'var376',
maxScore:'var377',
quizInfoTotalQuestionsPerProject:'var378',
quizInfoTotalUnansweredQuestions:'var379',
quizInfoAnswerChoice:'var380',
quizInfoPreviousQuestionScore:'var381',
questionInfoMaxAttempts:'var382',
questionInfoNegativePoints:'var383',
questionInfoPointsAssigned:'var384'
}

},
var346var346:{
vid:346,
name:'LMS.LearnerID',
vv:'',
vvt:2,
vt:0
},
var347var347:{
vid:347,
name:'LMS.LearnerName',
vv:'',
vvt:2,
vt:0
},
var348var348:{
vid:348,
name:'LMS.CourseName',
vv:'',
vvt:2,
vt:0
},
var349var349:{
vid:349,
name:'Project.ClosedCaptions',
vv:1,
vvt:0,
vt:9
},
var350var350:{
vid:350,
name:'Project.MuteAudio',
vv:0,
vvt:0,
vt:9
},
var351var351:{
vid:351,
name:'Project.ShowPlaybar',
vv:1,
vvt:0,
vt:9
},
var352var352:{
vid:352,
name:'Project.ShowTOC',
vv:0,
vvt:0,
vt:9
},
var353var353:{
vid:353,
name:'Project.AudioLevel',
vv:100,
vvt:1,
vt:9
},
var354var354:{
vid:354,
name:'Project.LockTOC',
vv:0,
vvt:0,
vt:9
},
var355var355:{
vid:355,
name:'Project.CurrentSlideNumber',
vv:1,
vvt:1,
vt:9
},
var356var356:{
vid:356,
name:'Project.CurrentSlideName',
vv:'slide',
vvt:2,
vt:9
},
var357var357:{
vid:357,
name:'Project.SlideCount',
vv:1,
vvt:1,
vt:9
},
var358var358:{
vid:358,
name:'Date.Today',
vv:'dd',
vvt:3,
vt:5
},
var359var359:{
vid:359,
name:'Date.DateMMDDYY',
vv:'mm/dd/yyyy',
vvt:3,
vt:5
},
var360var360:{
vid:360,
name:'Date.DateDDMMYY',
vv:'dd/mm/yyyy',
vvt:3,
vt:5
},
var361var361:{
vid:361,
name:'Date.Day',
vv:'1',
vvt:3,
vt:5
},
var362var362:{
vid:362,
name:'Date.Hours',
vv:'hh',
vvt:3,
vt:5
},
var363var363:{
vid:363,
name:'Date.LocaleString',
vv:'',
vvt:3,
vt:5
},
var364var364:{
vid:364,
name:'Date.Minutes',
vv:'mm',
vvt:3,
vt:5
},
var365var365:{
vid:365,
name:'Date.Month',
vv:'mm',
vvt:3,
vt:5
},
var366var366:{
vid:366,
name:'Date.Time',
vv:'hh:mm:ss',
vvt:3,
vt:5
},
var367var367:{
vid:367,
name:'Date.Year',
vv:'yyyy',
vvt:3,
vt:5
},
var368var368:{
vid:368,
name:'Quiz.InScope',
vv:0,
vvt:0,
vt:7
},
var369var369:{
vid:369,
name:'Quiz.InReview',
vv:0,
vvt:0,
vt:7
},
var370var370:{
vid:370,
name:'Quiz.PercentageScore',
vv:'0',
vvt:2,
vt:7
},
var371var371:{
vid:371,
name:'Quiz.AttemptCount',
vv:0,
vvt:1,
vt:7
},
var372var372:{
vid:372,
name:'Quiz.Pass',
vv:0,
vvt:0,
vt:7
},
var373var373:{
vid:373,
name:'Quiz.Score',
vv:0,
vvt:1,
vt:7
},
var374var374:{
vid:374,
name:'Quiz.PassPercentage',
vv:80,
vvt:1,
vt:7
},
var375var375:{
vid:375,
name:'Quiz.PassPoints',
vv:0,
vvt:1,
vt:7
},
var376var376:{
vid:376,
name:'Quiz.CorrectAnswerCount',
vv:0,
vvt:1,
vt:7
},
var377var377:{
vid:377,
name:'Quiz.MaxScore',
vv:0,
vvt:1,
vt:7
},
var378var378:{
vid:378,
name:'Quiz.QuestionCount',
vv:0,
vvt:1,
vt:7
},
var379var379:{
vid:379,
name:'Quiz.UnansweredQuestionCount',
vv:0,
vvt:1,
vt:7
},
var380var380:{
vid:380,
name:'Question.AnswerChoice',
vv:'',
vvt:2,
vt:7
},
var381var381:{
vid:381,
name:'Question.PreviousQuestionScore',
vv:0,
vvt:1,
vt:7
},
var382var382:{
vid:382,
name:'Question.MaxAttempts',
vv:0,
vvt:1,
vt:7
},
var383var383:{
vid:383,
name:'Question.NegativePoints',
vv:0,
vvt:1,
vt:7
},
var384var384:{
vid:384,
name:'Question.PointsAssigned',
vv:0,
vvt:1,
vt:7
},
var35044var35044:{
vid:35044,
name:'variableEditBoxStr_1',
vv:'',
vvt:2,
vt:0
},
var35045var35045:{
vid:35045,
name:'variableEditBoxNum_1',
vv:0,
vvt:1,
vt:0
},
variableIdVsNameMap:{
var346:'LMS.LearnerID',
var347:'LMS.LearnerName',
var348:'LMS.CourseName',
var349:'Project.ClosedCaptions',
var350:'Project.MuteAudio',
var351:'Project.ShowPlaybar',
var352:'Project.ShowTOC',
var353:'Project.AudioLevel',
var354:'Project.LockTOC',
var355:'Project.CurrentSlideNumber',
var356:'Project.CurrentSlideName',
var357:'Project.SlideCount',
var358:'Date.Today',
var359:'Date.DateMMDDYY',
var360:'Date.DateDDMMYY',
var361:'Date.Day',
var362:'Date.Hours',
var363:'Date.LocaleString',
var364:'Date.Minutes',
var365:'Date.Month',
var366:'Date.Time',
var367:'Date.Year',
var368:'Quiz.InScope',
var369:'Quiz.InReview',
var370:'Quiz.PercentageScore',
var371:'Quiz.AttemptCount',
var372:'Quiz.Pass',
var373:'Quiz.Score',
var374:'Quiz.PassPercentage',
var375:'Quiz.PassPoints',
var376:'Quiz.CorrectAnswerCount',
var377:'Quiz.MaxScore',
var378:'Quiz.QuestionCount',
var379:'Quiz.UnansweredQuestionCount',
var380:'Question.AnswerChoice',
var381:'Question.PreviousQuestionScore',
var382:'Question.MaxAttempts',
var383:'Question.NegativePoints',
var384:'Question.PointsAssigned',
var35044:'variableEditBoxStr_1',
var35045:'variableEditBoxNum_1'
},
project:{
fps:30,
hasTOC:1,
hasCC:false,
showClosedCaptions:true,
w:1920,
h:1080,
iw:1366,
ih:768,
prm:[1,1,0,0],
stateNameToLocalizedStateNameMap:{
kCPNormalState:'Normal',
kCPDownState:'Click',
kCPRolloverState:'Hover',
kCPVisitedState:'Visited',
kCPDragoverState:'',
kCPDragstartState:'',
kCPDropCorrect:'',
kCPDropIncorrect:'',
kCPDropAccept:'',
kCPDropReject:''
}
,
prjBgColor:'#ffffff',
pkt:0,
htmlBgColor:'#f5f4f1',
shc:false,
pN:'CWA-OnboardingOrientation.cpt'
},
projectThemeData:{
image_presets:'{\\
  "theme_image_default": {\\
    "meta": {\\
      "name": "kCPImageStyleNormal",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_default--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_default--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Normal",\\
        "mixBlendMode": "normal"\\
      }\\
    }\\
  },\\
\\
  "theme_image_greyscale": {\\
    "meta": {\\
      "name": "kCPImageStyleGreyscale",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_greyscale--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_greyscale--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Greyscale",\\
        "mixBlendMode": "saturation",\\
        "intensity": "var(--theme_image_greyscale--intensity)",\\
        "filterColor": {\\
          "fill": "#000000",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_lighten": {\\
    "meta": {\\
      "name": "kCPImageStyleLighten",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_lighten--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_lighten--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Lighten",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_lighten--intensity)",\\
        "filterColor": {\\
          "fill": "#FFFFFF",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_darken": {\\
    "meta": {\\
      "name": "kCPImageStyleDarken",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_darken--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_darken--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Darken",\\
        "mixBlendMode": "soft-light",\\
        "intensity": "var(--theme_image_darken--intensity)",\\
        "filterColor": {\\
          "fill": "var(--black)",\\
          "fillOpacity": 1\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_overlay": {\\
    "meta": {\\
      "name": "kCPImageStyleOverlay",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_overlay--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_overlay--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Overlay",\\
        "mixBlendMode": "overlay",\\
        "intensity": "var(--theme_image_overlay--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_overlay--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  },\\
\\
  "theme_image_colorize": {\\
    "meta": {\\
      "name": "kCPImageStyleColorize",\\
      "type": 2,\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "borderEnable": 0,\\
      "shadowEnable": 0\\
    },\\
    "styles": {\\
      "border": {\\
        "color": "var(--theme_image_colorize--strokeColor)",\\
        "size": 1,\\
        "type": 0,\\
        "style": 0\\
      },\\
      "boxShadow": {\\
        "shadowXOffset": 1,\\
        "shadowYOffset": 2,\\
        "shadowBlur": 4,\\
        "color": "var(--theme_image_colorize--boxShadowColor)"\\
      },\\
      "imageFilter": {\\
        "filterType": "Colorize",\\
        "mixBlendMode": "color",\\
        "intensity": "var(--theme_image_colorize--intensity)",\\
        "filterColor": {\\
          "fill": "var(--theme_image_colorize--primaryFillColor)",\\
          "fillOpacity": 1,\\
          "gradientProps": {\\
            "linearGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 0 },\\
                { "x": 50, "y": 100 }\\
              ]\\
            },\\
            "radialGradientProps": {\\
              "colorStops": [\\
                {\\
                  "color": "#378ef0",\\
                  "alpha": 1,\\
                  "scaledPosition": 0\\
                },\\
                {\\
                  "color": "#1c4778",\\
                  "alpha": 1,\\
                  "scaledPosition": 1\\
                }\\
              ],\\
              "endPoints": [\\
                { "x": 50, "y": 50 },\\
                { "x": 100, "y": 50 }\\
              ],\\
              "radialHandlePoints": [\\
                { "x": 50, "y": 100 },\\
                { "x": 100, "y": 100 }\\
              ]\\
            }\\
          }\\
        }\\
      }\\
    }\\
  }\\
}\\
',
meta:'{\\
  "name": "kCPThemeLight",\\
  "description": "kCPThemeLightDescription",\\
  "version": 0.1,\\
  "guid": "Default-Light-Theme",\\
  "default_presets": {\\
    "0": "cp_default_shape_solid_style",\\
    "1": "text-body-1",\\
    "2": "theme_image_default",\\
    "3": "cp_default_slide_style",\\
    "4": "cp_textinshape_body_1",\\
    "5": "cp_default_line_shape_style",\\
    "6": "cp_default_complex_shape_solid_style",\\
    "7": "cp_button_style_1_textonly",\\
    "8": "cp_checkbox_style_1_textonly",\\
    "9": "cp_svg_style",\\
    "10": "cp_dropDown_style_1",\\
    "11": "cp_radiobutton_style_1_textonly",\\
    "12": "cp_inputField_style_1",\\
    "13": "cp_clickbox_style",\\
    "14": "cp_responsive_container_style",\\
    "15": "cp_default_shape_solid_style"\\
  },\\
  "color_palettes": [\\
    {\\
      "name": "Light Palette - 1",\\
      "colors": [\\
        "var(--color1)",\\
        "var(--color2)",\\
        "var(--color3)",\\
        "var(--color4)",\\
        "var(--color5)",\\
        "var(--color6)",\\
        "var(--color7)",\\
        "var(--color5_light)",\\
        "var(--color4_dark)"\\
      ]\\
    }\\
  ],\\
  "active_color_palette": 0\\
}',
other_presets:'{\\
  "cp_default_slide_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "type": 3,\\
      "category": 0\\
    },\\
    "backgroundColor": "var(--palette-color1)",\\
    "outlineColor": "var(--palette-color5)",\\
    "outlineWidth": 1,\\
    "outlineStyle": "solid",\\
    "outlineCap": "butt",\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 0,\\
            "y": 0\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color2)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_responsive_container_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 14,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": 1,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_correct": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--success)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incorrect": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--error)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_incomplete": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--incomplete)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_hint": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--hint)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_retry": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--retry)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_caption_shape_solid_style_timeout": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--timeout)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color6)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color1)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_default_shape_radial_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 0,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color1)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}',
theme:'{"--primary":"#F1EEE6","--color1":"#FFFFFF","--color2":"#F8F7F4","--color3":"#F1EEE6","--color4":"#D6D5D1","--color5":"#666666","--color6":"#333333","--color7":"#020C1C","--colorC7":"#F7F7F7","--disabledC12":"#989898","--color1_light":"#FFCD74","--color1_dark":"#C76D12","--color2_light":"#86FFFF","--color2_dark":"#00ACCC","--color3_light":"#9B5DFF","--color3_dark":"#0000CA","--color4_light":"#99FF99","--color4_dark":"#112FA7","--color5_light":"#163EE5","--color5_dark":"#00CB92","--color6_light":"#7697FF","--color6_dark":"#0040CB","--color7_light":"#FF8E64","--color7_dark":"#C5230B","--success":"#558564","--error":"#C83E4D","--hint":"#CB6F10","--incomplete":"#E8BD2B","--timeout":"#C74545","--retry":"#CB6F10","--white":"#ffffff","--black":"#000000","--greyscale1":"#FFFFFF","--greyscale2":"#F1EEE61F","--greyscale3":"#B3B3B3","--greyscale4":"#4B4B4B","--greyscale5":"#333333","--disabled":"#818181","--palette-color0":"var(--color1)","--palette-color1":"var(--color2)","--palette-color2":"var(--color3)","--palette-color3":"var(--color4)","--palette-color4":"var(--color5)","--palette-color5":"var(--color6)","--palette-color6":"var(--color7)","--palette-color7":"var(--color5_light)","--palette-color8":"var(--color4_dark)","--design-option-color1":"255, 255, 255","--design-option-color2":"248, 247, 244","--design-option-color3":"241, 238, 230","--design-option-color4":"214, 213, 209","--design-option-color5":"102, 102, 102","--design-option-color6":"51, 51, 51","--design-option-color7":"2, 12, 28","--design-option-color5_light":"22, 62, 229","--design-option-color4_dark":"17, 47, 167","--c1":"var(--design-option-color1)","--c2":"var(--design-option-color2)","--c3":"var(--design-option-color3)","--c4":"var(--design-option-color4)","--c5":"var(--design-option-color5)","--c6":"var(--design-option-color6)","--c7":"var(--design-option-color7)","--c8":"var(--design-option-color5_light)","--c9":"var(--design-option-color4_dark)","--widget-container--fillcolor":"var(--palette-color1)","--font1":"Georgia","--font2":"Arial","--text-style-unset":"none","--text-heading-1--fontSize--desktop":"120px","--text-heading-1--fontSize--tablet":"100px","--text-heading-1--fontSize--mobile":"80px","--text-heading-1--fontFamily":"var(--font1)","--text-heading-1--fontWeight":"normal","--text-heading-1--fontType":"regular","--text-heading-1--fontStyle":"normal","--text-heading-1--fontStretch":"normal","--text-heading-1--lineHeight":"1.07","--text-heading-1--marginLeft":"0px","--text-heading-1--color":"var(--palette-color6)","--text-heading-1--borderBottomStyle":"none","--text-heading-1--textDecoration":"none","--text-heading-1--letterSpacing":"-0.01","--text-heading-1--textTransform":"none","--text-heading-1--stroke":"var(--palette-color2)","--text-heading-1--textAlign":"left","--text-heading-1--justifyContent":"flex-start","--text-heading-1--marginTop":"auto","--text-heading-1--marginBottom":"0","--text-heading-1--defaultTextStroke":"1px var(--palette-color2)","--text-heading-1--WebkitTextStroke":"var(--text-style-unset)","--text-heading-1--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-heading-1--textShadow":"var(--text-style-unset)","--text-heading-2--fontSize--desktop":"80px","--text-heading-2--fontSize--tablet":"72px","--text-heading-2--fontSize--mobile":"60px","--text-heading-2--fontFamily":"var(--font1)","--text-heading-2--fontWeight":"normal","--text-heading-2--fontType":"regular","--text-heading-2--fontStyle":"normal","--text-heading-2--fontStretch":"normal","--text-heading-2--lineHeight":"1.1","--text-heading-2--marginLeft":"0px","--text-heading-2--color":"var(--palette-color6)","--text-heading-2--borderBottomStyle":"none","--text-heading-2--textDecoration":"none","--text-heading-2--letterSpacing":"-0.04","--text-heading-2--textTransform":"none","--text-heading-2--stroke":"var(--palette-color2)","--text-heading-2--textAlign":"left","--text-heading-2--justifyContent":"flex-start","--text-heading-2--marginTop":"auto","--text-heading-2--marginBottom":"0","--text-heading-2--defaultTextStroke":"1px var(--palette-color2)","--text-heading-2--WebkitTextStroke":"var(--text-style-unset)","--text-heading-2--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-heading-2--textShadow":"var(--text-style-unset)","--text-heading-3--fontSize--desktop":"60px","--text-heading-3--fontSize--tablet":"52px","--text-heading-3--fontSize--mobile":"44px","--text-heading-3--fontFamily":"var(--font1)","--text-heading-3--fontWeight":"normal","--text-heading-3--fontType":"regular","--text-heading-3--fontStyle":"normal","--text-heading-3--fontStretch":"normal","--text-heading-3--lineHeight":"1.1","--text-heading-3--marginLeft":"0px","--text-heading-3--color":"var(--palette-color6)","--text-heading-3--borderBottomStyle":"none","--text-heading-3--textDecoration":"none","--text-heading-3--letterSpacing":"0.03","--text-heading-3--textTransform":"none","--text-heading-3--stroke":"var(--palette-color2)","--text-heading-3--textAlign":"left","--text-heading-3--justifyContent":"flex-start","--text-heading-3--marginTop":"auto","--text-heading-3--marginBottom":"0","--text-heading-3--defaultTextStroke":"1px var(--palette-color2)","--text-heading-3--WebkitTextStroke":"var(--text-style-unset)","--text-heading-3--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-heading-3--textShadow":"var(--text-style-unset)","--text-heading-4--fontSize--desktop":"52px","--text-heading-4--fontSize--tablet":"40px","--text-heading-4--fontSize--mobile":"32px","--text-heading-4--fontFamily":"var(--font1)","--text-heading-4--fontWeight":"normal","--text-heading-4--fontType":"regular","--text-heading-4--fontStyle":"normal","--text-heading-4--fontStretch":"normal","--text-heading-4--lineHeight":"1.15","--text-heading-4--marginLeft":"0px","--text-heading-4--color":"var(--palette-color6)","--text-heading-4--borderBottomStyle":"none","--text-heading-4--textDecoration":"none","--text-heading-4--letterSpacing":"0.10","--text-heading-4--textTransform":"uppercase","--text-heading-4--stroke":"var(--palette-color2)","--text-heading-4--textAlign":"left","--text-heading-4--justifyContent":"flex-start","--text-heading-4--marginTop":"auto","--text-heading-4--marginBottom":"0","--text-heading-4--defaultTextStroke":"1px var(--palette-color2)","--text-heading-4--WebkitTextStroke":"var(--text-style-unset)","--text-heading-4--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-heading-4--textShadow":"var(--text-style-unset)","--text-heading-5--fontSize--desktop":"40px","--text-heading-5--fontSize--tablet":"32px","--text-heading-5--fontSize--mobile":"28px","--text-heading-5--fontFamily":"var(--font1)","--text-heading-5--fontWeight":"normal","--text-heading-5--fontType":"regular","--text-heading-5--fontStyle":"normal","--text-heading-5--fontStretch":"normal","--text-heading-5--lineHeight":"1.2","--text-heading-5--marginLeft":"0px","--text-heading-5--color":"var(--palette-color6)","--text-heading-5--borderBottomStyle":"none","--text-heading-5--textDecoration":"none","--text-heading-5--letterSpacing":"0","--text-heading-5--textTransform":"none","--text-heading-5--stroke":"var(--palette-color2)","--text-heading-5--textAlign":"left","--text-heading-5--justifyContent":"flex-start","--text-heading-5--marginTop":"auto","--text-heading-5--marginBottom":"0","--text-heading-5--defaultTextStroke":"1px var(--palette-color2)","--text-heading-5--WebkitTextStroke":"var(--text-style-unset)","--text-heading-5--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-heading-5--textShadow":"var(--text-style-unset)","--text-heading-6--fontSize--desktop":"36px","--text-heading-6--fontSize--tablet":"28px","--text-heading-6--fontSize--mobile":"24px","--text-heading-6--fontFamily":"var(--font2)","--text-heading-6--fontWeight":"normal","--text-heading-6--fontType":"regular","--text-heading-6--fontStyle":"normal","--text-heading-6--fontStretch":"normal","--text-heading-6--lineHeight":"1.2","--text-heading-6--marginLeft":"0px","--text-heading-6--color":"var(--palette-color6)","--text-heading-6--borderBottomStyle":"none","--text-heading-6--textDecoration":"none","--text-heading-6--letterSpacing":"0","--text-heading-6--textTransform":"none","--text-heading-6--stroke":"var(--palette-color2)","--text-heading-6--textAlign":"left","--text-heading-6--justifyContent":"flex-start","--text-heading-6--marginTop":"auto","--text-heading-6--marginBottom":"0","--text-heading-6--defaultTextStroke":"1px var(--palette-color2)","--text-heading-6--WebkitTextStroke":"var(--text-style-unset)","--text-heading-6--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-heading-6--textShadow":"var(--text-style-unset)","--text-heading-7--fontSize--desktop":"20px","--text-heading-7--fontSize--tablet":"20px","--text-heading-7--fontSize--mobile":"20px","--text-heading-7--fontFamily":"var(--font1)","--text-heading-7--fontWeight":"normal","--text-heading-7--fontType":"regular","--text-heading-7--fontStyle":"normal","--text-heading-7--fontStretch":"normal","--text-heading-7--lineHeight":"1.35","--text-heading-7--marginLeft":"0px","--text-heading-7--color":"var(--palette-color5)","--text-heading-7--borderBottomStyle":"none","--text-heading-7--textDecoration":"none","--text-heading-7--letterSpacing":"0","--text-heading-7--textTransform":"none","--text-heading-7--stroke":"var(--palette-color2)","--text-heading-7--textAlign":"left","--text-heading-7--justifyContent":"flex-start","--text-heading-7--marginTop":"auto","--text-heading-7--marginBottom":"0","--text-heading-7--defaultTextStroke":"1px var(--palette-color2)","--text-heading-7--WebkitTextStroke":"var(--text-style-unset)","--text-heading-7--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-heading-7--textShadow":"var(--text-style-unset)","--text-heading-8--fontSize--desktop":"72px","--text-heading-8--fontSize--tablet":"48px","--text-heading-8--fontSize--mobile":"32px","--text-heading-8--fontFamily":"var(--font1)","--text-heading-8--fontWeight":"normal","--text-heading-8--fontType":"regular","--text-heading-8--fontStyle":"normal","--text-heading-8--fontStretch":"normal","--text-heading-8--lineHeight":"1.35","--text-heading-8--marginLeft":"0px","--text-heading-8--color":"var(--palette-color5)","--text-heading-8--borderBottomStyle":"none","--text-heading-8--textDecoration":"none","--text-heading-8--letterSpacing":"0","--text-heading-8--textTransform":"none","--text-heading-8--stroke":"var(--palette-color2)","--text-heading-8--textAlign":"center","--text-heading-8--justifyContent":"flex-start","--text-heading-8--marginTop":"auto","--text-heading-8--marginBottom":"0","--text-heading-8--defaultTextStroke":"1px var(--palette-color2)","--text-heading-8--WebkitTextStroke":"var(--text-style-unset)","--text-heading-8--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-heading-8--textShadow":"var(--text-style-unset)","--text-heading-9--fontSize--desktop":"32px","--text-heading-9--fontSize--tablet":"32px","--text-heading-9--fontSize--mobile":"32px","--text-heading-9--fontFamily":"var(--font1)","--text-heading-9--fontWeight":"normal","--text-heading-9--fontType":"regular","--text-heading-9--fontStyle":"normal","--text-heading-9--fontStretch":"normal","--text-heading-9--lineHeight":"1.35","--text-heading-9--marginLeft":"0px","--text-heading-9--color":"var(--palette-color5)","--text-heading-9--borderBottomStyle":"none","--text-heading-9--textDecoration":"none","--text-heading-9--letterSpacing":"0","--text-heading-9--textTransform":"none","--text-heading-9--stroke":"var(--palette-color2)","--text-heading-9--textAlign":"center","--text-heading-9--justifyContent":"flex-start","--text-heading-9--marginTop":"auto","--text-heading-9--marginBottom":"0","--text-heading-9--defaultTextStroke":"1px var(--palette-color2)","--text-heading-9--WebkitTextStroke":"var(--text-style-unset)","--text-heading-9--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-heading-9--textShadow":"var(--text-style-unset)","--text-body-1--fontSize--desktop":"22px","--text-body-1--fontSize--tablet":"20px","--text-body-1--fontSize--mobile":"18px","--text-body-1--fontFamily":"var(--font1)","--text-body-1--fontWeight":"normal","--text-body-1--fontType":"regular","--text-body-1--fontStyle":"normal","--text-body-1--fontStretch":"normal","--text-body-1--lineHeight":"1.3","--text-body-1--marginLeft":"0px","--text-body-1--color":"var(--palette-color5)","--text-body-1--borderBottomStyle":"none","--text-body-1--textDecoration":"none","--text-body-1--letterSpacing":"0","--text-body-1--textTransform":"none","--text-body-1--stroke":"var(--palette-color2)","--text-body-1--textAlign":"left","--text-body-1--justifyContent":"flex-start","--text-body-1--marginTop":"auto","--text-body-1--marginBottom":"0","--text-body-1--defaultTextStroke":"1px var(--palette-color2)","--text-body-1--WebkitTextStroke":"var(--text-style-unset)","--text-body-1--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-body-1--textShadow":"var(--text-style-unset)","--text-body-2--fontSize--desktop":"22px","--text-body-2--fontSize--tablet":"20px","--text-body-2--fontSize--mobile":"18px","--text-body-2--fontFamily":"var(--font2)","--text-body-2--fontWeight":"normal","--text-body-2--fontType":"regular","--text-body-2--fontStyle":"normal","--text-body-2--fontStretch":"normal","--text-body-2--lineHeight":"1.3","--text-body-2--marginLeft":"0px","--text-body-2--color":"var(--palette-color4)","--text-body-2--borderBottomStyle":"none","--text-body-2--textDecoration":"none","--text-body-2--letterSpacing":"0.03","--text-body-2--textTransform":"none","--text-body-2--Stroke":"var(--palette-color2)","--text-body-2--textAlign":"left","--text-body-2--justifyContent":"flex-start","--text-body-2--marginTop":"auto","--text-body-2--marginBottom":"0","--text-body-2--defaultTextStroke":"1px var(--palette-color2)","--text-body-2--WebkitTextStroke":"var(--text-style-unset)","--text-body-2--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-body-2--textShadow":"var(--text-style-unset)","--text-body-3--fontSize--desktop":"18px","--text-body-3--fontSize--tablet":"16px","--text-body-3--fontSize--mobile":"16px","--text-body-3--fontFamily":"var(--font1)","--text-body-3--fontWeight":"normal","--text-body-3--fontType":"regular","--text-body-3--fontStyle":"normal","--text-body-3--fontStretch":"normal","--text-body-3--lineHeight":"1.35","--text-body-3--marginLeft":"0px","--text-body-3--color":"var(--palette-color4)","--text-body-3--borderBottomStyle":"none","--text-body-3--textDecoration":"none","--text-body-3--letterSpacing":"0","--text-body-3--textTransform":"none","--text-body-3--Stroke":"var(--palette-color2)","--text-body-3--textAlign":"left","--text-body-3--justifyContent":"flex-start","--text-body-3--marginTop":"auto","--text-body-3--marginBottom":"0","--text-body-3--defaultTextStroke":"1px var(--palette-color2)","--text-body-3--WebkitTextStroke":"var(--text-style-unset)","--text-body-3--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-body-3--textShadow":"var(--text-style-unset)","--text-body-4--fontSize--desktop":"18px","--text-body-4--fontSize--tablet":"16px","--text-body-4--fontSize--mobile":"16px","--text-body-4--fontFamily":"var(--font2)","--text-body-4--fontWeight":"normal","--text-body-4--fontType":"regular","--text-body-4--fontStyle":"normal","--text-body-4--fontStretch":"normal","--text-body-4--lineHeight":"1.35","--text-body-4--marginLeft":"0px","--text-body-4--color":"var(--palette-color4)","--text-body-4--borderBottomStyle":"none","--text-body-4--textDecoration":"none","--text-body-4--letterSpacing":"0","--text-body-4--textTransform":"none","--text-body-4--Stroke":"var(--palette-color2)","--text-body-4--textAlign":"left","--text-body-4--justifyContent":"flex-start","--text-body-4--marginTop":"auto","--text-body-4--marginBottom":"0","--text-body-4--defaultTextStroke":"1px var(--palette-color2)","--text-body-4--WebkitTextStroke":"var(--text-style-unset)","--text-body-4--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-body-4--textShadow":"var(--text-style-unset)","--text-body-5--fontSize--desktop":"18px","--text-body-5--fontSize--tablet":"16px","--text-body-5--fontSize--mobile":"16px","--text-body-5--fontFamily":"var(--font1)","--text-body-5--fontWeight":"normal","--text-body-5--fontType":"italic","--text-body-5--fontStyle":"normal","--text-body-5--fontStretch":"normal","--text-body-5--lineHeight":1.35,"--text-body-5--marginLeft":"0px","--text-body-5--color":"var(--palette-color4)","--text-body-5--borderBottomStyle":"none","--text-body-5--textDecoration":"none","--text-body-5--letterSpacing":0,"--text-body-5--textTransform":"none","--text-body-5--Stroke":"var(--palette-color2)","--text-body-5--textAlign":"center","--text-body-5--justifyContent":"flex-start","--text-body-5--marginTop":"auto","--text-body-5--marginBottom":0,"--text-body-5--defaultTextStroke":"1px var(--palette-color2)","--text-body-5--WebkitTextStroke":"var(--text-style-unset)","--text-body-5--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-body-5--textShadow":"var(--text-style-unset)","--text-body-6--fontSize--desktop":"16px","--text-body-6--fontSize--tablet":"14px","--text-body-6--fontSize--mobile":"14px","--text-body-6--fontFamily":"var(--font2)","--text-body-6--fontWeight":"normal","--text-body-6--fontType":"regular","--text-body-6--fontStyle":"normal","--text-body-6--fontStretch":"normal","--text-body-6--lineHeight":"1.35","--text-body-6--marginLeft":"0px","--text-body-6--color":"var(--palette-color4)","--text-body-6--borderBottomStyle":"none","--text-body-6--textDecoration":"none","--text-body-6--letterSpacing":"0","--text-body-6--textTransform":"none","--text-body-6--Stroke":"var(--palette-color2)","--text-body-6--textAlign":"left","--text-body-6--justifyContent":"flex-start","--text-body-6--marginTop":"auto","--text-body-6--marginBottom":"0","--text-body-6--defaultTextStroke":"1px var(--palette-color2)","--text-body-6--WebkitTextStroke":"var(--text-style-unset)","--text-body-6--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-body-6--textShadow":"var(--text-style-unset)","--text-component-1--fontSize--desktop":"22px","--text-component-1--fontSize--tablet":"20px","--text-component-1--fontSize--mobile":"20px","--text-component-1--fontFamily":"var(--font1)","--text-component-1--fontWeight":"normal","--text-component-1--fontType":"regular","--text-component-1--fontStyle":"normal","--text-component-1--fontStretch":"normal","--text-component-1--lineHeight":"1.35","--text-component-1--marginLeft":"0px","--text-component-1--color":"var(--color6)","--text-component-1--borderBottomStyle":"none","--text-component-1--textDecoration":"none","--text-component-1--letterSpacing":"0","--text-component-1--textTransform":"none","--text-component-1--stroke":"var(--palette-color2)","--text-component-1--textAlign":"left","--text-component-1--justifyContent":"flex-start","--text-component-1--marginTop":"auto","--text-component-1--marginBottom":"0","--text-component-1--defaultTextStroke":"1px var(--palette-color2)","--text-component-1--WebkitTextStroke":"var(--text-style-unset)","--text-component-1--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-component-1--textShadow":"var(--text-style-unset)","--text-component-2--fontSize--desktop":"24px","--text-component-2--fontSize--tablet":"20px","--text-component-2--fontSize--mobile":"20px","--text-component-2--fontFamily":"var(--font1)","--text-component-2--fontWeight":"normal","--text-component-2--fontType":"regular","--text-component-2--fontStyle":"normal","--text-component-2--fontStretch":"normal","--text-component-2--lineHeight":"1.35","--text-component-2--marginLeft":"0px","--text-component-2--color":"var(--palette-color1)","--text-component-2--borderBottomStyle":"none","--text-component-2--textDecoration":"none","--text-component-2--letterSpacing":"0.16","--text-component-2--textTransform":"none","--text-component-2--stroke":"var(--palette-color2)","--text-component-2--textAlign":"left","--text-component-2--justifyContent":"flex-start","--text-component-2--marginTop":"auto","--text-component-2--marginBottom":"0","--text-component-2--defaultTextStroke":"1px var(--palette-color2)","--text-component-2--WebkitTextStroke":"var(--text-style-unset)","--text-component-2--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-component-2--textShadow":"var(--text-style-unset)","--text-component-3--fontSize--desktop":"14px","--text-component-3--fontSize--tablet":"14px","--text-component-3--fontSize--mobile":"14px","--text-component-3--fontFamily":"var(--font1)","--text-component-3--fontWeight":"normal","--text-component-3--fontType":"regular","--text-component-3--fontStyle":"normal","--text-component-3--fontStretch":"normal","--text-component-3--lineHeight":"1.35","--text-component-3--marginLeft":"0px","--text-component-3--color":"var(--palette-color6)","--text-component-3--borderBottomStyle":"none","--text-component-3--textDecoration":"none","--text-component-3--letterSpacing":"0.2","--text-component-3--textTransform":"uppercase","--text-component-3--stroke":"var(--palette-color2)","--text-component-3--textAlign":"center","--text-component-3--justifyContent":"flex-start","--text-component-3--marginTop":"auto","--text-component-3--marginBottom":"0","--text-component-3--defaultTextStroke":"1px var(--palette-color2)","--text-component-3--WebkitTextStroke":"var(--text-style-unset)","--text-component-3--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-component-3--textShadow":"var(--text-style-unset)","--text-component-4--fontSize--desktop":"22px","--text-component-4--fontSize--tablet":"20px","--text-component-4--fontSize--mobile":"20px","--text-component-4--fontFamily":"var(--font1)","--text-component-4--fontWeight":"normal","--text-component-4--fontType":"regular","--text-component-4--fontStyle":"normal","--text-component-4--fontStretch":"normal","--text-component-4--lineHeight":"1.35","--text-component-4--marginLeft":"0px","--text-component-4--color":"var(--color6)","--text-component-4--borderBottomStyle":"none","--text-component-4--textDecoration":"none","--text-component-4--letterSpacing":"0.02","--text-component-4--textTransform":"none","--text-component-4--stroke":"var(--palette-color2)","--text-component-4--textAlign":"left","--text-component-4--justifyContent":"flex-start","--text-component-4--marginTop":"auto","--text-component-4--marginBottom":"0","--text-component-4--defaultTextStroke":"1px var(--palette-color2)","--text-component-4--WebkitTextStroke":"var(--text-style-unset)","--text-component-4--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-component-4--textShadow":"var(--text-style-unset)","--text-subheading-1--fontSize--desktop":"36px","--text-subheading-1--fontSize--tablet":"32px","--text-subheading-1--fontSize--mobile":"28px","--text-subheading-1--fontFamily":"var(--font2)","--text-subheading-1--fontWeight":"normal","--text-subheading-1--fontType":"regular","--text-subheading-1--fontStyle":"normal","--text-subheading-1--fontStretch":"normal","--text-subheading-1--lineHeight":"1.1","--text-subheading-1--marginLeft":"0px","--text-subheading-1--color":"var(--palette-color6)","--text-subheading-1--borderBottomStyle":"none","--text-subheading-1--textDecoration":"none","--text-subheading-1--letterSpacing":"0.05","--text-subheading-1--textTransform":"uppercase","--text-subheading-1--stroke":"var(--palette-color2)","--text-subheading-1--textAlign":"left","--text-subheading-1--justifyContent":"flex-start","--text-subheading-1--marginTop":"auto","--text-subheading-1--marginBottom":"0","--text-subheading-1--defaultTextStroke":"1px var(--palette-color2)","--text-subheading-1--WebkitTextStroke":"var(--text-style-unset)","--text-subheading-1--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-subheading-1--textShadow":"var(--text-style-unset)","--text-subheading-2--fontSize--desktop":"28px","--text-subheading-2--fontSize--tablet":"24px","--text-subheading-2--fontSize--mobile":"20px","--text-subheading-2--fontFamily":"var(--font2)","--text-subheading-2--fontWeight":"normal","--text-subheading-2--fontType":"bold","--text-subheading-2--fontStyle":"normal","--text-subheading-2--fontStretch":"normal","--text-subheading-2--lineHeight":"1.15","--text-subheading-2--marginLeft":"0px","--text-subheading-2--color":"var(--palette-color6)","--text-subheading-2--borderBottomStyle":"none","--text-subheading-2--textDecoration":"none","--text-subheading-2--letterSpacing":"0.05","--text-subheading-2--textTransform":"none","--text-subheading-2--stroke":"var(--palette-color2)","--text-subheading-2--textAlign":"left","--text-subheading-2--justifyContent":"flex-start","--text-subheading-2--marginTop":"auto","--text-subheading-2--marginBottom":"0","--text-subheading-2--defaultTextStroke":"1px var(--palette-color2)","--text-subheading-2--WebkitTextStroke":"var(--text-style-unset)","--text-subheading-2--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-subheading-2--textShadow":"var(--text-style-unset)","--text-subheading-3--fontSize--desktop":"26px","--text-subheading-3--fontSize--tablet":"22px","--text-subheading-3--fontSize--mobile":"18px","--text-subheading-3--fontFamily":"var(--font2)","--text-subheading-3--fontWeight":"normal","--text-subheading-3--fontType":"regular","--text-subheading-3--fontStyle":"normal","--text-subheading-3--fontStretch":"normal","--text-subheading-3--lineHeight":"1.15","--text-subheading-3--marginLeft":"0px","--text-subheading-3--color":"var(--palette-color6)","--text-subheading-3--borderBottomStyle":"none","--text-subheading-3--textDecoration":"none","--text-subheading-3--letterSpacing":"0","--text-subheading-3--textTransform":"none","--text-subheading-3--stroke":"var(--palette-color2)","--text-subheading-3--textAlign":"center","--text-subheading-3--justifyContent":"flex-start","--text-subheading-3--marginTop":"auto","--text-subheading-3--marginBottom":"0","--text-subheading-3--defaultTextStroke":"1px var(--palette-color2)","--text-subheading-3--WebkitTextStroke":"var(--text-style-unset)","--text-subheading-3--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-subheading-3--textShadow":"var(--text-style-unset)","--text-subheading-4--fontSize--desktop":"24px","--text-subheading-4--fontSize--tablet":"20px","--text-subheading-4--fontSize--mobile":"16px","--text-subheading-4--fontFamily":"var(--font2)","--text-subheading-4--fontWeight":"normal","--text-subheading-4--fontType":"bold","--text-subheading-4--fontStyle":"normal","--text-subheading-4--fontStretch":"normal","--text-subheading-4--lineHeight":"1.15","--text-subheading-4--marginLeft":"0px","--text-subheading-4--color":"var(--palette-color0)","--text-subheading-4--borderBottomStyle":"none","--text-subheading-4--textDecoration":"none","--text-subheading-4--letterSpacing":"0.05","--text-subheading-4--textTransform":"none","--text-subheading-4--stroke":"var(--palette-color2)","--text-subheading-4--textAlign":"left","--text-subheading-4--justifyContent":"flex-start","--text-subheading-4--marginTop":"auto","--text-subheading-4--marginBottom":"0","--text-subheading-4--defaultTextStroke":"1px var(--palette-color2)","--text-subheading-4--WebkitTextStroke":"var(--text-style-unset)","--text-subheading-4--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-subheading-4--textShadow":"var(--text-style-unset)","--text-subheading-5--fontSize--desktop":"24px","--text-subheading-5--fontSize--tablet":"20px","--text-subheading-5--fontSize--mobile":"16px","--text-subheading-5--fontFamily":"var(--font1)","--text-subheading-5--fontWeight":"normal","--text-subheading-5--fontType":"bold","--text-subheading-5--fontStyle":"normal","--text-subheading-5--fontStretch":"normal","--text-subheading-5--lineHeight":"1.15","--text-subheading-5--marginLeft":"0px","--text-subheading-5--color":"var(--palette-color5)","--text-subheading-5--borderBottomStyle":"none","--text-subheading-5--textDecoration":"none","--text-subheading-5--letterSpacing":"-0.05","--text-subheading-5--textTransform":"none","--text-subheading-5--stroke":"var(--palette-color2)","--text-subheading-5--textAlign":"left","--text-subheading-5--justifyContent":"flex-start","--text-subheading-5--marginTop":"auto","--text-subheading-5--marginBottom":"0","--text-subheading-5--defaultTextStroke":"1px var(--palette-color2)","--text-subheading-5--WebkitTextStroke":"var(--text-style-unset)","--text-subheading-5--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-subheading-5--textShadow":"var(--text-style-unset)","--text-subheading-6--fontSize--desktop":"18px","--text-subheading-6--fontSize--tablet":"16px","--text-subheading-6--fontSize--mobile":"14px","--text-subheading-6--fontFamily":"var(--font2)","--text-subheading-6--fontWeight":"normal","--text-subheading-6--fontType":"bold","--text-subheading-6--fontStyle":"normal","--text-subheading-6--fontStretch":"normal","--text-subheading-6--lineHeight":"1.25","--text-subheading-6--marginLeft":"0px","--text-subheading-6--color":"var(--palette-color5)","--text-subheading-6--borderBottomStyle":"none","--text-subheading-6--textDecoration":"none","--text-subheading-6--letterSpacing":"0","--text-subheading-6--textTransform":"none","--text-subheading-6--stroke":"var(--palette-color2)","--text-subheading-6--textAlign":"left","--text-subheading-6--justifyContent":"flex-start","--text-subheading-6--marginTop":"auto","--text-subheading-6--marginBottom":"0","--text-subheading-6--defaultTextStroke":"1px var(--palette-color2)","--text-subheading-6--WebkitTextStroke":"var(--text-style-unset)","--text-subheading-6--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-subheading-6--textShadow":"var(--text-style-unset)","--text-detail-1--fontSize--desktop":"20px","--text-detail-1--fontSize--tablet":"18px","--text-detail-1--fontSize--mobile":"16px","--text-detail-1--fontFamily":"var(--font2)","--text-detail-1--fontWeight":"normal","--text-detail-1--fontType":"regular","--text-detail-1--fontStyle":"normal","--text-detail-1--fontStretch":"normal","--text-detail-1--lineHeight":"1.2","--text-detail-1--marginLeft":"0px","--text-detail-1--color":"var(--palette-color6)","--text-detail-1--borderBottomStyle":"none","--text-detail-1--textDecoration":"none","--text-detail-1--letterSpacing":"0","--text-detail-1--textTransform":"uppercase","--text-detail-1--stroke":"var(--palette-color5)","--text-detail-1--textAlign":"left","--text-detail-1--justifyContent":"flex-start","--text-detail-1--marginTop":"auto","--text-detail-1--marginBottom":"0","--text-detail-1--defaultTextStroke":"1px var(--palette-color2)","--text-detail-1--WebkitTextStroke":"var(--text-style-unset)","--text-detail-1--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-detail-1--textShadow":"var(--text-style-unset)","--text-detail-2--fontSize--desktop":"16px","--text-detail-2--fontSize--tablet":"14px","--text-detail-2--fontSize--mobile":"12px","--text-detail-2--fontFamily":"var(--font2)","--text-detail-2--fontWeight":"normal","--text-detail-2--fontType":"bold","--text-detail-2--fontStyle":"normal","--text-detail-2--fontStretch":"normal","--text-detail-2--lineHeight":"1.3","--text-detail-2--marginLeft":"0px","--text-detail-2--color":"var(--palette-color6)","--text-detail-2--borderBottomStyle":"none","--text-detail-2--textDecoration":"none","--text-detail-2--letterSpacing":"0","--text-detail-2--textTransform":"uppercase","--text-detail-2--stroke":"var(--palette-color2)","--text-detail-2--textAlign":"left","--text-detail-2--justifyContent":"flex-start","--text-detail-2--marginTop":"auto","--text-detail-2--marginBottom":"0","--text-detail-2--defaultTextStroke":"1px var(--palette-color2)","--text-detail-2--WebkitTextStroke":"var(--text-style-unset)","--text-detail-2--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-detail-2--textShadow":"var(--text-style-unset)","--text-detail-3--fontSize--desktop":"16px","--text-detail-3--fontSize--tablet":"14px","--text-detail-3--fontSize--mobile":"12px","--text-detail-3--fontFamily":"var(--font2)","--text-detail-3--fontWeight":"normal","--text-detail-3--fontType":"regular","--text-detail-3--fontStyle":"normal","--text-detail-3--fontStretch":"normal","--text-detail-3--lineHeight":"1.35","--text-detail-3--marginLeft":"0px","--text-detail-3--color":"var(--palette-color4)","--text-detail-3--borderBottomStyle":"none","--text-detail-3--textDecoration":"none","--text-detail-3--letterSpacing":"0.2","--text-detail-3--textTransform":"uppercase","--text-detail-3--stroke":"var(--palette-color2)","--text-detail-3--textAlign":"left","--text-detail-3--justifyContent":"flex-start","--text-detail-3--marginTop":"auto","--text-detail-3--marginBottom":"0","--text-detail-3--defaultTextStroke":"1px var(--palette-color2)","--text-detail-3--WebkitTextStroke":"var(--text-style-unset)","--text-detail-3--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-detail-3--textShadow":"var(--text-style-unset)","--text-detail-4--fontSize--desktop":"22px","--text-detail-4--fontSize--tablet":"20px","--text-detail-4--fontSize--mobile":"20px","--text-detail-4--fontFamily":"var(--font1)","--text-detail-4--fontWeight":"normal","--text-detail-4--fontType":"regular","--text-detail-4--fontStyle":"normal","--text-detail-4--fontStretch":"normal","--text-detail-4--lineHeight":"1.35","--text-detail-4--marginLeft":"0px","--text-detail-4--color":"var(--palette-color5)","--text-detail-4--borderBottomStyle":"none","--text-detail-4--textDecoration":"none","--text-detail-4--letterSpacing":"0","--text-detail-4--textTransform":"none","--text-detail-4--stroke":"var(--palette-color2)","--text-detail-4--textAlign":"center","--text-detail-4--justifyContent":"flex-start","--text-detail-4--marginTop":"auto","--text-detail-4--marginBottom":"0","--text-detail-4--defaultTextStroke":"1px var(--palette-color2)","--text-detail-4--WebkitTextStroke":"var(--text-style-unset)","--text-detail-4--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-detail-4--textShadow":"var(--text-style-unset)","--text-variable-1--fontSize--desktop":"36px","--text-variable-1--fontSize--tablet":"32px","--text-variable-1--fontSize--mobile":"30px","--text-variable-1--fontFamily":"var(--font2)","--text-variable-1--fontWeight":"normal","--text-variable-1--fontType":"bold","--text-variable-1--fontStyle":"normal","--text-variable-1--fontStretch":"normal","--text-variable-1--lineHeight":"1.2","--text-variable-1--marginLeft":"0px","--text-variable-1--color":"var(--palette-color7)","--text-variable-1--borderBottomStyle":"none","--text-variable-1--textDecoration":"none","--text-variable-1--letterSpacing":"0.02","--text-variable-1--textTransform":"none","--text-variable-1--stroke":"var(--palette-color2)","--text-variable-1--textAlign":"left","--text-variable-1--justifyContent":"flex-start","--text-variable-1--marginTop":"auto","--text-variable-1--marginBottom":"0","--text-variable-1--defaultTextStroke":"1px var(--palette-color2)","--text-variable-1--WebkitTextStroke":"var(--text-style-unset)","--text-variable-1--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-variable-1--textShadow":"var(--text-style-unset)","--text-variable-2--fontSize--desktop":"24px","--text-variable-2--fontSize--tablet":"22px","--text-variable-2--fontSize--mobile":"20px","--text-variable-2--fontFamily":"var(--font2)","--text-variable-2--fontWeight":"normal","--text-variable-2--fontType":"bold","--text-variable-2--fontStyle":"normal","--text-variable-2--fontStretch":"normal","--text-variable-2--lineHeight":"1.15","--text-variable-2--marginLeft":"0px","--text-variable-2--color":"var(--palette-color6)","--text-variable-2--borderBottomStyle":"none","--text-variable-2--textDecoration":"none","--text-variable-2--letterSpacing":"0","--text-variable-2--textTransform":"none","--text-variable-2--stroke":"var(--palette-color2)","--text-variable-2--textAlign":"left","--text-variable-2--justifyContent":"flex-start","--text-variable-2--marginTop":"auto","--text-variable-2--marginBottom":"0","--text-variable-2--defaultTextStroke":"1px var(--palette-color2)","--text-variable-2--WebkitTextStroke":"var(--text-style-unset)","--text-variable-2--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-variable-2--textShadow":"var(--text-style-unset)","--text-variable-3--fontSize--desktop":"20px","--text-variable-3--fontSize--tablet":"18px","--text-variable-3--fontSize--mobile":"16px","--text-variable-3--fontFamily":"var(--font1)","--text-variable-3--fontWeight":"normal","--text-variable-3--fontType":"bold","--text-variable-3--fontStyle":"normal","--text-variable-3--fontStretch":"normal","--text-variable-3--lineHeight":"1.2","--text-variable-3--marginLeft":"0px","--text-variable-3--color":"var(--palette-color6)","--text-variable-3--borderBottomStyle":"none","--text-variable-3--textDecoration":"none","--text-variable-3--letterSpacing":"0","--text-variable-3--textTransform":"none","--text-variable-3--stroke":"var(--palette-color2)","--text-variable-3--textAlign":"left","--text-variable-3--justifyContent":"flex-start","--text-variable-3--marginTop":"auto","--text-variable-3--marginBottom":"0","--text-variable-3--defaultTextStroke":"1px var(--palette-color2)","--text-variable-3--WebkitTextStroke":"var(--text-style-unset)","--text-variable-3--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-variable-3--textShadow":"var(--text-style-unset)","--text-variable-4--fontSize--desktop":"16px","--text-variable-4--fontSize--tablet":"14px","--text-variable-4--fontSize--mobile":"12px","--text-variable-4--fontFamily":"var(--font2)","--text-variable-4--fontWeight":"normal","--text-variable-4--fontType":"bold","--text-variable-4--fontStyle":"normal","--text-variable-4--fontStretch":"normal","--text-variable-4--lineHeight":"1.3","--text-variable-4--marginLeft":"0px","--text-variable-4--color":"var(--palette-color6)","--text-variable-4--borderBottomStyle":"none","--text-variable-4--textDecoration":"none","--text-variable-4--letterSpacing":"0.02","--text-variable-4--textTransform":"none","--text-variable-4--stroke":"var(--palette-color2)","--text-variable-4--textAlign":"left","--text-variable-4--justifyContent":"flex-start","--text-variable-4--marginTop":"auto","--text-variable-4--marginBottom":"0","--text-variable-4--defaultTextStroke":"1px var(--palette-color2)","--text-variable-4--WebkitTextStroke":"var(--text-style-unset)","--text-variable-4--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-variable-4--textShadow":"var(--text-style-unset)","--text-question-1--fontSize--desktop":"48px","--text-question-1--fontSize--tablet":"20px","--text-question-1--fontSize--mobile":"20px","--text-question-1--fontFamily":"var(--font1)","--text-question-1--fontWeight":"normal","--text-question-1--fontType":"regular","--text-question-1--fontStyle":"normal","--text-question-1--fontStretch":"normal","--text-question-1--lineHeight":"1.35","--text-question-1--marginLeft":"0px","--text-question-1--color":"var(--palette-color5)","--text-question-1--borderBottomStyle":"none","--text-question-1--textDecoration":"none","--text-question-1--letterSpacing":"0","--text-question-1--textTransform":"none","--text-question-1--stroke":"var(--palette-color2)","--text-question-1--textAlign":"left","--text-question-1--justifyContent":"flex-start","--text-question-1--marginTop":"auto","--text-question-1--marginBottom":"0","--text-question-1--defaultTextStroke":"1px var(--palette-color2)","--text-question-1--WebkitTextStroke":"var(--text-style-unset)","--text-question-1--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-question-1--textShadow":"var(--text-style-unset)","--text-question-2--fontSize--desktop":"24px","--text-question-2--fontSize--tablet":"20px","--text-question-2--fontSize--mobile":"20px","--text-question-2--fontFamily":"var(--font1)","--text-question-2--fontWeight":"normal","--text-question-2--fontType":"bold","--text-question-2--fontStyle":"normal","--text-question-2--fontStretch":"normal","--text-question-2--lineHeight":"1.35","--text-question-2--marginLeft":"0px","--text-question-2--color":"var(--palette-color5)","--text-question-2--borderBottomStyle":"none","--text-question-2--textDecoration":"none","--text-question-2--letterSpacing":"0","--text-question-2--textTransform":"none","--text-question-2--stroke":"var(--palette-color2)","--text-question-2--textAlign":"left","--text-question-2--justifyContent":"flex-start","--text-question-2--marginTop":"auto","--text-question-2--marginBottom":"0","--text-question-2--defaultTextStroke":"1px var(--palette-color2)","--text-question-2--WebkitTextStroke":"var(--text-style-unset)","--text-question-2--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-question-2--textShadow":"var(--text-style-unset)","--text-button-1--fontSize--desktop":"16px","--text-button-1--fontSize--tablet":"16px","--text-button-1--fontSize--mobile":"16px","--text-button-1--fontFamily":"var(--font2)","--text-button-1--fontWeight":"normal","--text-button-1--fontType":"regular","--text-button-1--fontStyle":"normal","--text-button-1--fontStretch":"normal","--text-button-1--lineHeight":"1.25","--text-button-1--marginLeft":"0px","--text-button-1--color":"var(--palette-color7)","--text-button-1--borderBottomStyle":"none","--text-button-1--textDecoration":"none","--text-button-1--letterSpacing":"0.12","--text-button-1--textTransform":"uppercase","--text-button-1--stroke":"var(--palette-color2)","--text-button-1--textAlign":"center","--text-button-1--justifyContent":"flex-start","--text-button-1--marginTop":"auto","--text-button-1--marginBottom":"0","--text-button-1--defaultTextStroke":"1px var(--palette-color2)","--text-button-1--WebkitTextStroke":"var(--text-style-unset)","--text-button-1--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-button-1--textShadow":"var(--text-style-unset)","--text-button-2--fontSize--desktop":"16px","--text-button-2--fontSize--tablet":"16px","--text-button-2--fontSize--mobile":"16px","--text-button-2--fontFamily":"var(--font2)","--text-button-2--fontWeight":"normal","--text-button-2--fontType":"regular","--text-button-2--fontStyle":"normal","--text-button-2--fontStretch":"normal","--text-button-2--lineHeight":"1.25","--text-button-2--marginLeft":"0px","--text-button-2--color":"var(--palette-color0)","--text-button-2--borderBottomStyle":"none","--text-button-2--textDecoration":"none","--text-button-2--letterSpacing":"0.12","--text-button-2--textTransform":"uppercase","--text-button-2--stroke":"var(--palette-color2)","--text-button-2--textAlign":"center","--text-button-2--justifyContent":"flex-start","--text-button-2--marginTop":"auto","--text-button-2--marginBottom":"0","--text-button-2--defaultTextStroke":"1px var(--palette-color2)","--text-button-2--WebkitTextStroke":"var(--text-style-unset)","--text-button-2--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-button-2--textShadow":"var(--text-style-unset)","--text-button-3--fontSize--desktop":"16px","--text-button-3--fontSize--tablet":"16px","--text-button-3--fontSize--mobile":"16px","--text-button-3--fontFamily":"var(--font2)","--text-button-3--fontWeight":"normal","--text-button-3--fontType":"regular","--text-button-3--fontStyle":"normal","--text-button-3--fontStretch":"normal","--text-button-3--lineHeight":"1.25","--text-button-3--marginLeft":"0px","--text-button-3--color":"var(--palette-color5)","--text-button-3--borderBottomStyle":"none","--text-button-3--textDecoration":"none","--text-button-3--letterSpacing":"0.12","--text-button-3--textTransform":"uppercase","--text-button-3--stroke":"var(--palette-color2)","--text-button-3--textAlign":"center","--text-button-3--justifyContent":"flex-start","--text-button-3--marginTop":"auto","--text-button-3--marginBottom":"0","--text-button-3--defaultTextStroke":"1px var(--palette-color2)","--text-button-3--WebkitTextStroke":"var(--text-style-unset)","--text-button-3--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-button-3--textShadow":"var(--text-style-unset)","--text-button-4--fontSize--desktop":"16px","--text-button-4--fontSize--tablet":"16px","--text-button-4--fontSize--mobile":"16px","--text-button-4--fontFamily":"var(--font2)","--text-button-4--fontWeight":"normal","--text-button-4--fontType":"regular","--text-button-4--fontStyle":"normal","--text-button-4--fontStretch":"normal","--text-button-4--lineHeight":"1.25","--text-button-4--marginLeft":"0px","--text-button-4--color":"var(--palette-color4)","--text-button-4--borderBottomStyle":"none","--text-button-4--textDecoration":"none","--text-button-4--letterSpacing":"0.12","--text-button-4--textTransform":"uppercase","--text-button-4--stroke":"var(--palette-color2)","--text-button-4--textAlign":"center","--text-button-4--justifyContent":"flex-start","--text-button-4--marginTop":"auto","--text-button-4--marginBottom":"0","--text-button-4--defaultTextStroke":"1px var(--palette-color2)","--text-button-4--WebkitTextStroke":"var(--text-style-unset)","--text-button-4--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-button-4--textShadow":"var(--text-style-unset)","--text-uic-1--fontSize--desktop":"18px","--text-uic-1--fontSize--tablet":"18px","--text-uic-1--fontSize--mobile":"18px","--text-uic-1--fontFamily":"var(--font1)","--text-uic-1--fontWeight":"normal","--text-uic-1--fontType":"italic","--text-uic-1--fontStyle":"normal","--text-uic-1--fontStretch":"normal","--text-uic-1--lineHeight":"1.35","--text-uic-1--marginLeft":"0px","--text-uic-1--color":"var(--palette-color4)","--text-uic-1--borderBottomStyle":"none","--text-uic-1--textDecoration":"none","--text-uic-1--letterSpacing":"0","--text-uic-1--textTransform":"none","--text-uic-1--stroke":"var(--palette-color2)","--text-uic-1--textAlign":"left","--text-uic-1--justifyContent":"flex-start","--text-uic-1--marginTop":"auto","--text-uic-1--marginBottom":"0","--text-uic-1--defaultTextStroke":"1px var(--palette-color2)","--text-uic-1--WebkitTextStroke":"var(--text-style-unset)","--text-uic-1--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-uic-1--textShadow":"var(--text-style-unset)","--text-uic-2--fontSize--desktop":"18px","--text-uic-2--fontSize--tablet":"18px","--text-uic-2--fontSize--mobile":"18px","--text-uic-2--fontFamily":"var(--font1)","--text-uic-2--fontWeight":"normal","--text-uic-2--fontType":"italic","--text-uic-2--fontStyle":"normal","--text-uic-2--fontStretch":"normal","--text-uic-2--lineHeight":"1.35","--text-uic-2--marginLeft":"0px","--text-uic-2--color":"var(--palette-color1)","--text-uic-2--borderBottomStyle":"none","--text-uic-2--textDecoration":"none","--text-uic-2--letterSpacing":"0","--text-uic-2--textTransform":"none","--text-uic-2--stroke":"var(--palette-color2)","--text-uic-2--textAlign":"left","--text-uic-2--justifyContent":"flex-start","--text-uic-2--marginTop":"auto","--text-uic-2--marginBottom":"0","--text-uic-2--defaultTextStroke":"1px var(--palette-color2)","--text-uic-2--WebkitTextStroke":"var(--text-style-unset)","--text-uic-2--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-uic-2--textShadow":"var(--text-style-unset)","--text-uic-3--fontSize--desktop":"22px","--text-uic-3--fontSize--tablet":"22px","--text-uic-3--fontSize--mobile":"22px","--text-uic-3--fontFamily":"var(--font1)","--text-uic-3--fontWeight":"normal","--text-uic-3--fontType":"regular","--text-uic-3--fontStyle":"normal","--text-uic-3--fontStretch":"normal","--text-uic-3--lineHeight":"1.25","--text-uic-3--marginLeft":"0px","--text-uic-3--color":"var(--palette-color5)","--text-uic-3--borderBottomStyle":"none","--text-uic-3--textDecoration":"none","--text-uic-3--letterSpacing":"0","--text-uic-3--textTransform":"none","--text-uic-3--stroke":"var(--palette-color2)","--text-uic-3--textAlign":"left","--text-uic-3--justifyContent":"flex-start","--text-uic-3--marginTop":"auto","--text-uic-3--marginBottom":"0","--text-uic-3--defaultTextStroke":"1px var(--palette-color2)","--text-uic-3--WebkitTextStroke":"var(--text-style-unset)","--text-uic-3--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-uic-3--textShadow":"var(--text-style-unset)","--text-uic-4--fontSize--desktop":"22px","--text-uic-4--fontSize--tablet":"22px","--text-uic-4--fontSize--mobile":"22px","--text-uic-4--fontFamily":"var(--font1)","--text-uic-4--fontWeight":"normal","--text-uic-4--fontType":"regular","--text-uic-4--fontStyle":"normal","--text-uic-4--fontStretch":"normal","--text-uic-4--lineHeight":"1.25","--text-uic-4--marginLeft":"0px","--text-uic-4--color":"var(--palette-color4)","--text-uic-4--borderBottomStyle":"none","--text-uic-4--textDecoration":"none","--text-uic-4--letterSpacing":"0","--text-uic-4--textTransform":"none","--text-uic-4--stroke":"var(--palette-color2)","--text-uic-4--textAlign":"left","--text-uic-4--justifyContent":"flex-start","--text-uic-4--marginTop":"auto","--text-uic-4--marginBottom":"0","--text-uic-4--defaultTextStroke":"1px var(--palette-color2)","--text-uic-4--WebkitTextStroke":"var(--text-style-unset)","--text-uic-4--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-uic-4--textShadow":"var(--text-style-unset)","--text-uic-5--fontSize--desktop":"22px","--text-uic-5--fontSize--tablet":"22px","--text-uic-5--fontSize--mobile":"22px","--text-uic-5--fontFamily":"var(--font1)","--text-uic-5--fontWeight":"normal","--text-uic-5--fontType":"regular","--text-uic-5--fontStyle":"normal","--text-uic-5--fontStretch":"normal","--text-uic-5--lineHeight":"1.25","--text-uic-5--marginLeft":"0px","--text-uic-5--color":"var(--palette-color3)","--text-uic-5--borderBottomStyle":"none","--text-uic-5--textDecoration":"none","--text-uic-5--letterSpacing":"0","--text-uic-5--textTransform":"none","--text-uic-5--stroke":"var(--palette-color2)","--text-uic-5--textAlign":"left","--text-uic-5--justifyContent":"flex-start","--text-uic-5--marginTop":"auto","--text-uic-5--marginBottom":"0","--text-uic-5--defaultTextStroke":"1px var(--palette-color2)","--text-uic-5--WebkitTextStroke":"var(--text-style-unset)","--text-uic-5--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-uic-5--textShadow":"var(--text-style-unset)","--text-uic-6--fontSize--desktop":"16px","--text-uic-6--fontSize--tablet":"16px","--text-uic-6--fontSize--mobile":"16px","--text-uic-6--fontFamily":"var(--font2)","--text-uic-6--fontWeight":"normal","--text-uic-6--fontType":"bold","--text-uic-6--fontStyle":"normal","--text-uic-6--fontStretch":"normal","--text-uic-6--lineHeight":"1.5","--text-uic-6--marginLeft":"0px","--text-uic-6--color":"var(--palette-color7)","--text-uic-6--borderBottomStyle":"none","--text-uic-6--textDecoration":"none","--text-uic-6--letterSpacing":"0.12","--text-uic-6--textTransform":"none","--text-uic-6--stroke":"var(--palette-color2)","--text-uic-6--textAlign":"left","--text-uic-6--justifyContent":"flex-start","--text-uic-6--marginTop":"auto","--text-uic-6--marginBottom":"0","--text-uic-6--defaultTextStroke":"1px var(--palette-color2)","--text-uic-6--WebkitTextStroke":"var(--text-style-unset)","--text-uic-6--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-uic-6--textShadow":"var(--text-style-unset)","--text-closedcaptions--fontSize--desktop":"24px","--text-closedcaptions--fontSize--tablet":"24px","--text-closedcaptions--fontSize--mobile":"24px","--text-closedcaptions--fontFamily":"var(--font1)","--text-closedcaptions--fontWeight":"normal","--text-closedcaptions--fontType":"regular","--text-closedcaptions--fontStyle":"normal","--text-closedcaptions--fontStretch":"normal","--text-closedcaptions--lineHeight":"1.35","--text-closedcaptions--marginLeft":"0px","--text-closedcaptions--color":"var(--white)","--text-closedcaptions--borderBottomStyle":"none","--text-closedcaptions--textDecoration":"none","--text-closedcaptions--letterSpacing":"0","--text-closedcaptions--textTransform":"none","--text-closedcaptions--stroke":"var(--palette-color2)","--text-closedcaptions--textAlign":"center","--text-closedcaptions--justifyContent":"flex-start","--text-closedcaptions--marginTop":"auto","--text-closedcaptions--marginBottom":"0","--text-closedcaptions--defaultTextStroke":"1px var(--palette-color2)","--text-closedcaptions--WebkitTextStroke":"var(--text-style-unset)","--text-closedcaptions--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-closedcaptions--textShadow":"var(--text-style-unset)","--text-caption--fontSize--desktop":"24px","--text-caption--fontSize--tablet":"24px","--text-caption--fontSize--mobile":"24px","--text-caption--fontFamily":"var(--font1)","--text-caption--fontWeight":"normal","--text-caption--fontType":"regular","--text-caption--fontStyle":"normal","--text-caption--fontStretch":"normal","--text-caption--lineHeight":"1.35","--text-caption--marginLeft":"0px","--text-caption--color":"var(--palette-color6)","--text-caption--borderBottomStyle":"none","--text-caption--textDecoration":"none","--text-caption--letterSpacing":"0","--text-caption--textTransform":"none","--text-caption--stroke":"var(--palette-color2)","--text-caption--textAlign":"center","--text-caption--justifyContent":"flex-start","--text-caption--marginTop":"auto","--text-caption--marginBottom":"0","--text-caption--defaultTextStroke":"1px var(--palette-color2)","--text-caption--WebkitTextStroke":"var(--text-style-unset)","--text-caption--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-caption--textShadow":"var(--text-style-unset)","--text-caption_correct--fontSize--desktop":"24px","--text-caption_correct--fontSize--tablet":"24px","--text-caption_correct--fontSize--mobile":"24px","--text-caption_correct--fontFamily":"var(--font1)","--text-caption_correct--fontWeight":"normal","--text-caption_correct--fontType":"regular","--text-caption_correct--fontStyle":"normal","--text-caption_correct--fontStretch":"normal","--text-caption_correct--lineHeight":"1.35","--text-caption_correct--marginLeft":"0px","--text-caption_correct--color":"var(--palette-color6)","--text-caption_correct--borderBottomStyle":"none","--text-caption_correct--textDecoration":"none","--text-caption_correct--letterSpacing":"0","--text-caption_correct--textTransform":"none","--text-caption_correct--stroke":"var(--palette-color2)","--text-caption_correct--textAlign":"center","--text-caption_correct--justifyContent":"flex-start","--text-caption_correct--marginTop":"auto","--text-caption_correct--marginBottom":"0","--text-caption_correct--defaultTextStroke":"1px var(--palette-color2)","--text-caption_correct--WebkitTextStroke":"var(--text-style-unset)","--text-caption_correct--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-caption_correct--textShadow":"var(--text-style-unset)","--text-caption_incorrect--fontSize--desktop":"24px","--text-caption_incorrect--fontSize--tablet":"24px","--text-caption_incorrect--fontSize--mobile":"24px","--text-caption_incorrect--fontFamily":"var(--font1)","--text-caption_incorrect--fontWeight":"normal","--text-caption_incorrect--fontType":"regular","--text-caption_incorrect--fontStyle":"normal","--text-caption_incorrect--fontStretch":"normal","--text-caption_incorrect--lineHeight":"1.35","--text-caption_incorrect--marginLeft":"0px","--text-caption_incorrect--color":"var(--palette-color6)","--text-caption_incorrect--borderBottomStyle":"none","--text-caption_incorrect--textDecoration":"none","--text-caption_incorrect--letterSpacing":"0","--text-caption_incorrect--textTransform":"none","--text-caption_incorrect--stroke":"var(--palette-color2)","--text-caption_incorrect--textAlign":"center","--text-caption_incorrect--justifyContent":"flex-start","--text-caption_incorrect--marginTop":"auto","--text-caption_incorrect--marginBottom":"0","--text-caption_incorrect--defaultTextStroke":"1px var(--palette-color2)","--text-caption_incorrect--WebkitTextStroke":"var(--text-style-unset)","--text-caption_incorrect--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-caption_incorrect--textShadow":"var(--text-style-unset)","--text-caption_incomplete--fontSize--desktop":"24px","--text-caption_incomplete--fontSize--tablet":"24px","--text-caption_incomplete--fontSize--mobile":"24px","--text-caption_incomplete--fontFamily":"var(--font1)","--text-caption_incomplete--fontWeight":"normal","--text-caption_incomplete--fontType":"regular","--text-caption_incomplete--fontStyle":"normal","--text-caption_incomplete--fontStretch":"normal","--text-caption_incomplete--lineHeight":"1.35","--text-caption_incomplete--marginLeft":"0px","--text-caption_incomplete--color":"var(--palette-color6)","--text-caption_incomplete--borderBottomStyle":"none","--text-caption_incomplete--textDecoration":"none","--text-caption_incomplete--letterSpacing":"0","--text-caption_incomplete--textTransform":"none","--text-caption_incomplete--stroke":"var(--palette-color2)","--text-caption_incomplete--textAlign":"center","--text-caption_incomplete--justifyContent":"flex-start","--text-caption_incomplete--marginTop":"auto","--text-caption_incomplete--marginBottom":"0","--text-caption_incomplete--defaultTextStroke":"1px var(--palette-color2)","--text-caption_incomplete--WebkitTextStroke":"var(--text-style-unset)","--text-caption_incomplete--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-caption_incomplete--textShadow":"var(--text-style-unset)","--text-caption_hint--fontSize--desktop":"24px","--text-caption_hint--fontSize--tablet":"24px","--text-caption_hint--fontSize--mobile":"24px","--text-caption_hint--fontFamily":"var(--font1)","--text-caption_hint--fontWeight":"normal","--text-caption_hint--fontType":"regular","--text-caption_hint--fontStyle":"normal","--text-caption_hint--fontStretch":"normal","--text-caption_hint--lineHeight":"1.35","--text-caption_hint--marginLeft":"0px","--text-caption_hint--color":"var(--palette-color6)","--text-caption_hint--borderBottomStyle":"none","--text-caption_hint--textDecoration":"none","--text-caption_hint--letterSpacing":"0","--text-caption_hint--textTransform":"none","--text-caption_hint--stroke":"var(--palette-color2)","--text-caption_hint--textAlign":"center","--text-caption_hint--justifyContent":"flex-start","--text-caption_hint--marginTop":"auto","--text-caption_hint--marginBottom":"0","--text-caption_hint--defaultTextStroke":"1px var(--palette-color2)","--text-caption_hint--WebkitTextStroke":"var(--text-style-unset)","--text-caption_hint--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-caption_hint--textShadow":"var(--text-style-unset)","--text-caption_retry--fontSize--desktop":"24px","--text-caption_retry--fontSize--tablet":"24px","--text-caption_retry--fontSize--mobile":"24px","--text-caption_retry--fontFamily":"var(--font1)","--text-caption_retry--fontWeight":"normal","--text-caption_retry--fontType":"regular","--text-caption_retry--fontStyle":"normal","--text-caption_retry--fontStretch":"normal","--text-caption_retry--lineHeight":"1.35","--text-caption_retry--marginLeft":"0px","--text-caption_retry--color":"var(--palette-color6)","--text-caption_retry--borderBottomStyle":"none","--text-caption_retry--textDecoration":"none","--text-caption_retry--letterSpacing":"0","--text-caption_retry--textTransform":"none","--text-caption_retry--stroke":"var(--palette-color2)","--text-caption_retry--textAlign":"center","--text-caption_retry--justifyContent":"flex-start","--text-caption_retry--marginTop":"auto","--text-caption_retry--marginBottom":"0","--text-caption_retry--defaultTextStroke":"1px var(--palette-color2)","--text-caption_retry--WebkitTextStroke":"var(--text-style-unset)","--text-caption_retry--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-caption_retry--textShadow":"var(--text-style-unset)","--text-caption_timeout--fontSize--desktop":"24px","--text-caption_timeout--fontSize--tablet":"24px","--text-caption_timeout--fontSize--mobile":"24px","--text-caption_timeout--fontFamily":"var(--font1)","--text-caption_timeout--fontWeight":"normal","--text-caption_timeout--fontType":"regular","--text-caption_timeout--fontStyle":"normal","--text-caption_timeout--fontStretch":"normal","--text-caption_timeout--lineHeight":"1.35","--text-caption_timeout--marginLeft":"0px","--text-caption_timeout--color":"var(--palette-color6)","--text-caption_timeout--borderBottomStyle":"none","--text-caption_timeout--textDecoration":"none","--text-caption_timeout--letterSpacing":"0","--text-caption_timeout--textTransform":"none","--text-caption_timeout--stroke":"var(--palette-color2)","--text-caption_timeout--textAlign":"center","--text-caption_timeout--justifyContent":"flex-start","--text-caption_timeout--marginTop":"auto","--text-caption_timeout--marginBottom":"0","--text-caption_timeout--defaultTextStroke":"1px var(--palette-color2)","--text-caption_timeout--WebkitTextStroke":"var(--text-style-unset)","--text-caption_timeout--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-caption_timeout--textShadow":"var(--text-style-unset)","--text-caption_1--fontSize--desktop":"18px","--text-caption_1--fontSize--tablet":"18px","--text-caption_1--fontSize--mobile":"16px","--text-caption_1--fontFamily":"var(--font2)","--text-caption_1--fontWeight":"normal","--text-caption_1--fontType":"regular","--text-caption_1--fontStyle":"normal","--text-caption_1--fontStretch":"normal","--text-caption_1--lineHeight":"1.2","--text-caption_1--marginLeft":"0px","--text-caption_1--color":"#FFFFFF","--text-caption_1--borderBottomStyle":"none","--text-caption_1--textDecoration":"none","--text-caption_1--letterSpacing":"0","--text-caption_1--textTransform":"none","--text-caption_1--stroke":"#00000000","--text-caption_1--textAlign":"left","--text-caption_1--justifyContent":"flex-start","--text-caption_1--marginTop":"auto","--text-caption_1--marginBottom":"0","--text-caption_1--defaultTextStroke":"1px #00000000","--text-caption_1--WebkitTextStroke":"var(--text-style-unset)","--text-caption_1--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-caption_1--textShadow":"var(--text-style-unset)","--text-caption_2--fontSize--desktop":"20px","--text-caption_2--fontSize--tablet":"20px","--text-caption_2--fontSize--mobile":"18px","--text-caption_2--fontFamily":"var(--font2)","--text-caption_2--fontWeight":"normal","--text-caption_2--fontType":"bold","--text-caption_2--fontStyle":"normal","--text-caption_2--fontStretch":"normal","--text-caption_2--lineHeight":"1.2","--text-caption_2--marginLeft":"0px","--text-caption_2--color":"#FFFFFF","--text-caption_2--borderBottomStyle":"none","--text-caption_2--textDecoration":"none","--text-caption_2--letterSpacing":"0","--text-caption_2--textTransform":"none","--text-caption_2--stroke":"#00000000","--text-caption_2--textAlign":"left","--text-caption_2--justifyContent":"flex-start","--text-caption_2--marginTop":"auto","--text-caption_2--marginBottom":"0","--text-caption_2--defaultTextStroke":"1px #00000000","--text-caption_2--WebkitTextStroke":"var(--text-style-unset)","--text-caption_2--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-caption_2--textShadow":"var(--text-style-unset)","--text-caption_3--fontSize--desktop":"24px","--text-caption_3--fontSize--tablet":"24px","--text-caption_3--fontSize--mobile":"22px","--text-caption_3--fontFamily":"var(--font1)","--text-caption_3--fontWeight":"normal","--text-caption_3--fontType":"italic","--text-caption_3--fontStyle":"normal","--text-caption_3--fontStretch":"normal","--text-caption_3--lineHeight":"1.2","--text-caption_3--marginLeft":"0px","--text-caption_3--color":"#FFFFFF","--text-caption_3--borderBottomStyle":"none","--text-caption_3--textDecoration":"none","--text-caption_3--letterSpacing":"0","--text-caption_3--textTransform":"none","--text-caption_3--stroke":"#00000000","--text-caption_3--textAlign":"left","--text-caption_3--justifyContent":"flex-start","--text-caption_3--marginTop":"auto","--text-caption_3--marginBottom":"0","--text-caption_3--defaultTextStroke":"1px #00000000","--text-caption_3--WebkitTextStroke":"var(--text-style-unset)","--text-caption_3--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-caption_3--textShadow":"var(--text-style-unset)","--text-caption_4--fontSize--desktop":"22px","--text-caption_4--fontSize--tablet":"22px","--text-caption_4--fontSize--mobile":"20px","--text-caption_4--fontFamily":"var(--font2)","--text-caption_4--fontWeight":"normal","--text-caption_4--fontType":"italic","--text-caption_4--fontStyle":"normal","--text-caption_4--fontStretch":"normal","--text-caption_4--lineHeight":"1.3","--text-caption_4--marginLeft":"0px","--text-caption_4--color":"#666666","--text-caption_4--borderBottomStyle":"none","--text-caption_4--textDecoration":"none","--text-caption_4--letterSpacing":"0","--text-caption_4--textTransform":"none","--text-caption_4--stroke":"#00000000","--text-caption_4--textAlign":"left","--text-caption_4--justifyContent":"flex-start","--text-caption_4--marginTop":"auto","--text-caption_4--marginBottom":"0","--text-caption_4--defaultTextStroke":"1px #00000000","--text-caption_4--WebkitTextStroke":"var(--text-style-unset)","--text-caption_4--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-caption_4--textShadow":"var(--text-style-unset)","--text-comment-box--fontSize--desktop":"20px","--text-comment-box--fontSize--tablet":"20px","--text-comment-box--fontSize--mobile":"20px","--text-comment-box--fontFamily":"var(--font1)","--text-comment-box--fontWeight":"normal","--text-comment-box--fontType":"regular","--text-comment-box--fontStyle":"normal","--text-comment-box--fontStretch":"normal","--text-comment-box--lineHeight":"1.35","--text-comment-box--marginLeft":"0px","--text-comment-box--color":"var(--palette-color6)","--text-comment-box--borderBottomStyle":"none","--text-comment-box--textDecoration":"none","--text-comment-box--letterSpacing":"0","--text-comment-box--textTransform":"none","--text-comment-box--stroke":"var(--palette-color2)","--text-comment-box--textAlign":"center","--text-comment-box--justifyContent":"flex-start","--text-comment-box--marginTop":"auto","--text-comment-box--marginBottom":"0","--text-comment-box--defaultTextStroke":"1px var(--palette-color2)","--text-comment-box--WebkitTextStroke":"var(--text-style-unset)","--text-comment-box--defaultTextShadow":"0px 4px 8px var(--greyscale2)","--text-comment-box--textShadow":"var(--text-style-unset)","--theme_image_default--strokeColor":"var(--palette-color1)","--theme_image_default--boxShadowColor":"var(--greyscale3)","--theme_image_greyscale--strokeColor":"var(--palette-color1)","--theme_image_greyscale--boxShadowColor":"var(--greyscale3)","--theme_image_greyscale--intensity":100,"--theme_image_lighten--strokeColor":"var(--palette-color1)","--theme_image_lighten--boxShadowColor":"var(--greyscale3)","--theme_image_lighten--intensity":80,"--theme_image_darken--strokeColor":"var(--palette-color1)","--theme_image_darken--boxShadowColor":"var(--greyscale3)","--theme_image_darken--intensity":80,"--theme_image_overlay--strokeColor":"var(--palette-color1)","--theme_image_overlay--boxShadowColor":"var(--greyscale3)","--theme_image_overlay--intensity":80,"--theme_image_overlay--primaryFillColor":"var(--palette-color2)","--theme_image_overlay--secondaryFillColor":"var(--palette-color1)","--theme_image_colorize--strokeColor":"var(--palette-color1)","--theme_image_colorize--boxShadowColor":"var(--greyscale3)","--theme_image_colorize--intensity":80,"--theme_image_colorize--primaryFillColor":"var(--palette-color4)","--theme_image_colorize--secondaryFillColor":"var(--palette-color1)","--button-normal--primaryColor":"var(--palette-color7)","--button-normal--borderColor":"var(--palette-color7)","--button-normal--shadowColor":"var(--greyscale3)","--text-button-normal--color":"var(--palette-color0)","--text-button-normal--fontFamily":"var(--font2)","--text-button-normal--fontType":"regular","--text-button-normal--fontSize--desktop":"16px","--text-button-normal--fontSize--tablet":"16px","--text-button-normal--fontSize--mobile":"16px","--button-selected--primaryColor":"var(--palette-color5)","--button-selected--borderColor":"var(--palette-color5)","--button-selected--shadowColor":"var(--greyscale3)","--text-button-selected--color":"var(--palette-color0)","--text-button-selected--fontFamily":"var(--font2)","--text-button-selected--fontType":"regular","--text-button-selected--fontSize--desktop":"16px","--text-button-selected--fontSize--tablet":"16px","--text-button-selected--fontSize--mobile":"16px","--button-disabled--primaryColor":"var(--palette-color3)","--button-disabled--borderColor":"var(--palette-color3)","--button-disabled--shadowColor":"var(--greyscale3)","--text-button-disabled--color":"var(--palette-color4)","--text-button-disabled--fontFamily":"var(--font2)","--text-button-disabled--fontType":"regular","--text-button-disabled--fontSize--desktop":"16px","--text-button-disabled--fontSize--tablet":"16px","--text-button-disabled--fontSize--mobile":"16px","--button-hover--primaryColor":"#112FA7","--button-hover--borderColor":"#112FA7","--button-hover--shadowColor":"var(--greyscale3)","--text-button-hover--color":"var(--palette-color0)","--text-button-hover--fontFamily":"var(--font2)","--text-button-hover--fontType":"regular","--text-button-hover--fontSize--desktop":"16px","--text-button-hover--fontSize--tablet":"16px","--text-button-hover--fontSize--mobile":"16px","--button-visited--primaryColor":"#112FA780","--button-visited--borderColor":"#112FA780","--button-visited--shadowColor":"var(--greyscale3)","--text-button-visited--color":"var(--palette-color0)","--text-button-visited--fontFamily":"var(--font2)","--text-button-visited--fontType":"regular","--text-button-visited--fontSize--desktop":"16px","--text-button-visited--fontSize--tablet":"16px","--text-button-visited--fontSize--mobile":"16px","--checkbox-normal--primaryColor":"var(--palette-color0)","--checkbox-normal--borderColor":"var(--palette-color3)","--checkbox-normal--shadowColor":"var(--greyscale3)","--text-checkbox-normal--color":"var(--palette-color4)","--text-checkbox-normal--fontFamily":"var(--font1)","--text-checkbox-normal--fontType":"regular","--text-checkbox-normal--fontSize--desktop":"22px","--text-checkbox-normal--fontSize--tablet":"20px","--text-checkbox-normal--fontSize--mobile":"20px","--checkbox-selected--primaryColor":"var(--palette-color7)","--checkbox-selected--borderColor":"var(--palette-color4)","--checkbox-selected--shadowColor":"var(--greyscale3)","--text-checkbox-selected--color":"var(--palette-color4)","--text-checkbox-selected--fontFamily":"var(--font1)","--text-checkbox-selected--fontType":"regular","--text-checkbox-selected--fontSize--desktop":"22px","--text-checkbox-selected--fontSize--tablet":"20px","--text-checkbox-selected--fontSize--mobile":"20px","--checkbox-disabled-checked--primaryColor":"var(--palette-color3)","--checkbox-disabled-checked--borderColor":"var(--palette-color3)","--checkbox-disabled-checked--shadowColor":"var(--greyscale3)","--text-checkbox-disabled-checked--color":"var(--palette-color3)","--text-checkbox-disabled-checked--fontFamily":"var(--font1)","--text-checkbox-disabled-checked--fontType":"regular","--text-checkbox-disabled-checked--fontSize--desktop":"22px","--text-checkbox-disabled-checked--fontSize--tablet":"20px","--text-checkbox-disabled-checked--fontSize--mobile":"20px","--checkbox-hover--primaryColor":"var(--palette-color0)","--checkbox-hover--borderColor":"var(--palette-color3)","--checkbox-hover--shadowColor":"var(--greyscale3)","--text-checkbox-hover--color":"var(--palette-color5)","--text-checkbox-hover--fontFamily":"var(--font1)","--text-checkbox-hover--fontType":"regular","--text-checkbox-hover--fontSize--desktop":"22px","--text-checkbox-hover--fontSize--tablet":"20px","--text-checkbox-hover--fontSize--mobile":"20px","--checkbox-disabled-unchecked--primaryColor":"var(--palette-color3)","--checkbox-disabled-unchecked--borderColor":"var(--palette-color3)","--checkbox-disabled-unchecked--shadowColor":"var(--greyscale3)","--text-checkbox-disabled-unchecked--color":"var(--palette-color3)","--text-checkbox-disabled-unchecked--fontFamily":"var(--font1)","--text-checkbox-disabled-unchecked--fontType":"regular","--text-checkbox-disabled-unchecked--fontSize--desktop":"22px","--text-checkbox-disabled-unchecked--fontSize--tablet":"20px","--text-checkbox-disabled-unchecked--fontSize--mobile":"20px","--inputfield-normal--primaryColor":"var(--palette-color0)","--inputfield-normal--borderColor":"var(--palette-color3)","--inputfield-normal--shadowColor":"var(--greyscale3)","--text-inputfield-normal--color":"var(--palette-color4)","--text-inputfield-normal--fontFamily":"var(--font1)","--text-inputfield-normal--fontType":"regular","--text-inputfield-normal--fontSize--desktop":"18px","--text-inputfield-normal--fontSize--tablet":"20px","--text-inputfield-normal--fontSize--mobile":"20px","--inputfield-active--primaryColor":"var(--palette-color0)","--inputfield-active--borderColor":"var(--palette-color7)","--inputfield-active--shadowColor":"#var(--greyscale3)","--text-inputfield-active--color":"var(--palette-color4)","--text-inputfield-active--fontFamily":"var(--font1)","--text-inputfield-active--fontType":"regular","--text-inputfield-active--fontSize--desktop":"18px","--text-inputfield-active--fontSize--tablet":"20px","--text-inputfield-active--fontSize--mobile":"20px","--inputfield-disabled--primaryColor":"var(--palette-color3)","--inputfield-disabled--borderColor":"var(--palette-color3)","--inputfield-disabled--shadowColor":"var(--greyscale3)","--text-inputfield-disabled--color":"var(--palette-color1)","--text-inputfield-disabled--fontFamily":"var(--font1)","--text-inputfield-disabled--fontType":"regular","--text-inputfield-disabled--fontSize--desktop":"18px","--text-inputfield-disabled--fontSize--tablet":"20px","--text-inputfield-disabled--fontSize--mobile":"20px","--inputfield-focusLost--primaryColor":"var(--palette-color0)","--inputfield-focusLost--borderColor":"var(--palette-color3)","--inputfield-focusLost--shadowColor":"var(--greyscale3)","--text-inputfield-focusLost--color":"var(--palette-color4)","--text-inputfield-focusLost--fontFamily":"var(--font1)","--text-inputfield-focusLost--fontType":"regular","--text-inputfield-focusLost--fontSize--desktop":"18px","--text-inputfield-focusLost--fontSize--tablet":"20px","--text-inputfield-focusLost--fontSize--mobile":"20px","--inputfield-error--primaryColor":"var(--palette-color0)","--inputfield-error--borderColor":"var(--error)","--inputfield-error--shadowColor":"var(--greyscale3)","--text-inputfield-error--color":"var(--palette-color4)","--text-inputfield-error--fontFamily":"var(--font1)","--text-inputfield-error--fontType":"regular","--text-inputfield-error--fontSize--desktop":"18px","--text-inputfield-error--fontSize--tablet":"20px","--text-inputfield-error--fontSize--mobile":"20px","--dropdown-normal--primaryColor":"var(--palette-color0)","--dropdown-normal--borderColor":"var(--palette-color3)","--dropdown-normal--shadowColor":"var(--greyscale3)","--text-dropdown-normal--color":"var(--palette-color4)","--text-dropdown-normal--fontFamily":"var(--font1)","--text-dropdown-normal--fontType":"italic","--text-dropdown-normal--fontSize--desktop":"18px","--text-dropdown-normal--fontSize--tablet":"18px","--text-dropdown-normal--fontSize--mobile":"18px","--dropdown-selected--primaryColor":"var(--palette-color0)","--dropdown-selected--borderColor":"var(--palette-color7)","--dropdown-selected--shadowColor":"var(--greyscale3)","--text-dropdown-selected--color":"var(--palette-color4)","--text-dropdown-selected--fontFamily":"var(--font1)","--text-dropdown-selected--fontType":"italic","--text-dropdown-selected--fontSize--desktop":"18px","--text-dropdown-selected--fontSize--tablet":"18px","--text-dropdown-selected--fontSize--mobile":"18px","--dropdown-disabled--primaryColor":"var(--palette-color3)","--dropdown-disabled--borderColor":"var(--palette-color3)","--dropdown-disabled--shadowColor":"var(--greyscale3)","--text-dropdown-disabled--color":"var(--palette-color1)","--text-dropdown-disabled--fontFamily":"var(--font1)","--text-dropdown-disabled--fontType":"italic","--text-dropdown-disabled--fontSize--desktop":"18px","--text-dropdown-disabled--fontSize--tablet":"18px","--text-dropdown-disabled--fontSize--mobile":"18px","--dropdown-hover--primaryColor":"var(--palette-color0)","--dropdown-hover--borderColor":"var(--palette-color3)","--dropdown-hover--shadowColor":"var(--greyscale3)","--text-dropdown-hover--color":"var(--palette-color4)","--text-dropdown-hover--fontFamily":"var(--font1)","--text-dropdown-hover--fontType":"italic","--text-dropdown-hover--fontSize--desktop":"18px","--text-dropdown-hover--fontSize--tablet":"18px","--text-dropdown-hover--fontSize--mobile":"18px","--radio-normal--primaryColor":"var(--palette-color0)","--radio-normal--borderColor":"var(--palette-color3)","--radio-normal--shadowColor":"var(--greyscale3)","--text-radio-normal--color":"var(--palette-color4)","--text-radio-normal--fontFamily":"var(--font1)","--text-radio-normal--fontType":"regular","--text-radio-normal--fontSize--desktop":"22px","--text-radio-normal--fontSize--tablet":"20px","--text-radio-normal--fontSize--mobile":"20px","--radio-selected--primaryColor":"var(--palette-color0)","--radio-selected--borderColor":"var(--palette-color4)","--radio-selected--shadowColor":"var(--greyscale3)","--text-radio-selected--color":"var(--palette-color4)","--text-radio-selected--fontFamily":"var(--font1)","--text-radio-selected--fontType":"regular","--text-radio-selected--fontSize--desktop":"22px","--text-radio-selected--fontSize--tablet":"20px","--text-radio-selected--fontSize--mobile":"20px","--radio-disabled-checked--primaryColor":"var(--palette-color3)","--radio-disabled-checked--borderColor":"var(--palette-color3)","--radio-disabled-checked--shadowColor":"var(--greyscale3)","--text-radio-disabled-checked--color":"var(--palette-color3)","--text-radio-disabled-checked--fontFamily":"var(--font1)","--text-radio-disabled-checked--fontType":"regular","--text-radio-disabled-checked--fontSize--desktop":"22px","--text-radio-disabled-checked--fontSize--tablet":"20px","--text-radio-disabled-checked--fontSize--mobile":"20px","--radio-hover--primaryColor":"var(--palette-color0)","--radio-hover--borderColor":"var(--palette-color3)","--radio-hover--shadowColor":"var(--greyscale3)","--text-radio-hover--color":"var(--palette-color5)","--text-radio-hover--fontFamily":"var(--font1)","--text-radio-hover--fontType":"regular","--text-radio-hover--fontSize--desktop":"22px","--text-radio-hover--fontSize--tablet":"20px","--text-radio-hover--fontSize--mobile":"20px","--radio-disabled-unchecked--primaryColor":"var(--palette-color3)","--radio-disabled-unchecked--borderColor":"var(--palette-color3)","--radio-disabled-unchecked--shadowColor":"var(--greyscale3)","--text-radio-disabled-unchecked--color":"var(--palette-color3)","--text-radio-disabled-unchecked--fontFamily":"var(--font1)","--text-radio-disabled-unchecked--fontType":"regular","--text-radio-disabled-unchecked--fontSize--desktop":"22px","--text-radio-disabled-unchecked--fontSize--tablet":"20px","--text-radio-disabled-unchecked--fontSize--mobile":"20px","--video_preset-color":"#666666","--video_preset-borderColor":"#666666","--clickbox-preset-fill-color":"#3F80E4","--drag-object-default-state-fill-color":"255, 255, 255","--drag-object-hover-state-fill-color":"250, 250, 250","--drag-object-transition-state-fill-color":"250, 250, 250","--drag-object-dragOver-state-fill-color":"250, 250, 250","--drag-object-dropped-state-fill-color":"255, 255, 255","--drag-object-default-state-border-color":"214, 213, 209","--drag-object-hover-state-border-color":"214, 213, 209","--drag-object-transition-state-border-color":"214, 213, 209","--drag-object-dragOver-state-border-color":"230, 132, 80","--drag-object-dropped-state-border-color":"214, 213, 209","--drop-object-default-state-fill-color":"255, 255, 255","--drop-object-hover-state-fill-color":"255, 255, 255","--drop-object-dragOver-state-fill-color":"230, 132, 80","--drop-object-dropped-state-fill-color":"255, 255, 255","--drop-object-default-state-border-color":"42, 49, 62","--drop-object-hover-state-border-color":"230, 132, 80","--drop-object-dragOver-state-border-color":"230, 132, 80","--drop-object-dropped-state-border-color":"42, 49, 62"}',
uic_presets:'{\\
  "cp_button_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 1,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "--button-selected--shadowColor",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-visited--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style": {\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "#707070",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_hover": {\\
    "fill": "#9ec4f3",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 7,\\
      "spread": null,\\
      "color": "var(--black)",\\
      "inset": null,\\
      "opacity": 0.53\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_selected": {\\
    "fill": "var(--palette-color5)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_visited": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_disabled": {\\
    "fill": "#0A00FF",\\
    "fillOpacity": 1,\\
    "stroke": "var(--color6)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_checkbox_shape_1_solid_style_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--checkbox-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--checkbox-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--checkbox-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_active": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-active--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-active--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-active--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_focusLost": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-focusLost--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-focusLost--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-focusLost--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_error": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-error--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-error--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-error--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_inputField_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--inputfield-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--inputfield-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--inputfield-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 0,\\
      "y": 0,\\
      "blur": 14,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 0.78\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_dropDown_shape_1_solid_style_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "video_preset_style": {\\
    "fillEnable": 0,\\
    "strokeEnable": 0,\\
    "shadowEnable": 0,\\
    "fill": "var(--video_preset-color)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--video_preset-border)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_comment_box_shape_1_solid_style": {\\
    "fill": "#F2B807",\\
    "fillOpacity": 1,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clickbox_shape_solid_style": {\\
    "fill": "var(--clickbox-preset-fill-color)",\\
    "fillOpacity": 0.6,\\
    "stroke": "var(--palette-color3)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "2, 3",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-hover--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_visited": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-visited--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-visited--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--button-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--button-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#333333",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#000000",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "button_navigate_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#D6D5D1",\\
    "fillOpacity": 1,\\
    "stroke": "#D6D5D1",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--button-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "dropdown_shape_1_disabled": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--dropdown-disabled--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--dropdown-disabled--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--dropdown-disabled--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_normal": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-normal--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-normal--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-normal--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_hover": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-hover--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-hover--borderColor)",\\
    "strokeWidth": 3,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-hover--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_selected": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-selected--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-selected--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-selected--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_checked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-checked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-checked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-checked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "radio_shape_1_disabled_unchecked": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--radio-disabled-unchecked--primaryColor)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--radio-disabled-unchecked--borderColor)",\\
    "strokeWidth": 2,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_clicktoreveal_default": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 1,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "#ffffff",\\
    "fillOpacity": 1,\\
    "stroke": "#ffffff",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--radio-disabled-unchecked--shadowColor)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_linear_style": {\\
    "meta": {\\
      "fillEnable": 1,\\
      "fillType": 3,\\
      "strokeEnable": 1,\\
      "shadowEnable": 0,\\
      "type": 0,\\
      "category": 0\\
    },\\
    "fill": "var(--palette-color0)",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color7)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color8)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  },\\
  "cp_button_shape_8_solid_style_blue": {\\
    "fill": "#ADD8E6",\\
    "fillOpacity": 1,\\
    "stroke": "var(--black)",\\
    "strokeWidth": 1,\\
    "strokeLinecap": "butt",\\
    "strokeDasharray": "none",\\
    "brightness": 0,\\
    "contrast": 0,\\
    "saturation": 0,\\
    "sharpness": 0,\\
    "boxShadow": {\\
      "x": 1,\\
      "y": 2,\\
      "blur": 4,\\
      "spread": null,\\
      "color": "var(--greyscale3)",\\
      "inset": null,\\
      "opacity": 1\\
    },\\
    "gradientFill": {\\
      "linearFill": {\\
        "colorStops": [\\
          {\\
            "color": "#FF335E",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "#ECA8B6",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 0\\
          },\\
          {\\
            "x": 50,\\
            "y": 100\\
          }\\
        ]\\
      },\\
      "radialFill": {\\
        "colorStops": [\\
          {\\
            "color": "var(--palette-color1)",\\
            "alpha": 1,\\
            "scaledPosition": 0\\
          },\\
          {\\
            "color": "var(--palette-color0)",\\
            "alpha": 1,\\
            "scaledPosition": 1\\
          }\\
        ],\\
        "endPoints": [\\
          {\\
            "x": 50,\\
            "y": 50\\
          },\\
          {\\
            "x": 100,\\
            "y": 50\\
          }\\
        ],\\
        "radialHandlePoints": [\\
          {\\
            "x": 50,\\
            "y": 100\\
          },\\
          {\\
            "x": 100,\\
            "y": 100\\
          }\\
        ]\\
      }\\
    }\\
  }\\
}'
},
project_main:{
from:1,
to:0,
currentFrame:1,
featureFlags:{
isNewWidgetArchitecture:'{"isEnabled":true,"featureData":{}}'
}
,
useResponsive:true,
responsiveType:512,
isResponsiveSim:1,
currentFrame:1,
useWidgetVersion7:false,
isPublishedFromLacuna:false,
vestr:0,
vim:0,
slides:'Slide5512,Slide5755,Slide17159,Slide23468,Slide25422',
questions:'',
autoplay:false,
preloader:true,
preloaderFileName:'dr/loading.gif',
preloaderPercentage:100,
pprtd:false,
peon:false,
fadeInAtStart:0,
fadeOutAtEnd:0
},
borderProperties:{
hasBorder:false
},
playBarProperties:{
hasPlayBar:true,
jsfile:'playbarScript.js',
cssfile:'playbarStyle.css',
position:3,
layout:3,
showOnHover:false,
overlay:true,
tworow:false,
hasRewind:true,
hasBackward:true,
hasPlay:true,
hasEnterVR:false,
hasSlider:true,
hasForward:true,
hasCC:false,
hasAudioOn:true,
hasExit:true,
hasFastForward:true,
applyColors:false,
alpha:100,
noToolTips:false,
locale:0
},
tocProperties:{
tocProperties:'{"tocConfig":{"labels":{"TITLE":"Table of Content","SLIDE_DETAILS":"SLIDE TITLE","DURATION":"DURATION","CLOSE_BUTTON_LABEL":"Close"},"slideDetails":[{"label":"Onboarding Guide","type":"slide","parentId":null,"id":"Slide5512","isVisible":true,"slideVisited":false,"originalId":5512,"labelShouldBeInSync":true},{"label":"Welcome","type":"slide","parentId":null,"id":"Slide5755","isVisible":true,"slideVisited":false,"originalId":5755,"labelShouldBeInSync":true},{"label":"Active Projects Overview","type":"slide","parentId":null,"id":"Slide17159","isVisible":true,"slideVisited":false,"originalId":17159,"labelShouldBeInSync":true},{"label":"Roles","type":"slide","parentId":null,"id":"Slide23468","isVisible":true,"slideVisited":false,"originalId":23468,"labelShouldBeInSync":true},{"label":"Collaboration _ Meetups","type":"slide","parentId":null,"id":"Slide25422","isVisible":true,"slideVisited":false,"originalId":25422,"labelShouldBeInSync":true}],"tocGeneratedOnPreviewClick":true,"preserveSlidesOrder":true},"playbarConfig":{"isPlaybarControlsPlayEnabled":true,"isPlaybarControlsNextEnabled":true,"isPlaybarControlsTOCEnabled":true,"isShowPlaybarEnabled":true,"isShowTooltipsEnabled":true,"isPlaybarControlsBackEnabled":true,"isHidePlaybarInQuizEnabled":false,"isPlaybarControlsMuteEnabled":true,"isPlaybarControlsClosedCaptionsEnabled":false}}'
},
trecs:[{
link:5512,
text:[]
}
,{
link:5755,
text:[]
}
,{
link:17159,
text:[]
}
,{
link:23468,
text:[]
}
,{
link:25422,
text:[]
}
]

,
typekit:{
kit_id:''
},
};
cp.model.projectImages=[
'assets/htmlimages/ThreeD_Close.svg',
'assets/htmlimages/ThreeD_HotspotDefaultGlow.png',
'assets/htmlimages/ThreeD_HotspotGlow.png',
'assets/htmlimages/assessmenthotspotvisited.svg',
'assets/htmlimages/expand_icon.png',
'assets/htmlimages/img_trans.gif',
'assets/htmlimages/placeholder.png'
];
cp.model.data.images=[{
ip:'dr/017423.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/017489.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/017555.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/017621.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/020855.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/020922.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/020989.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/024412.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/024434.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/024458.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/024562.jpeg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/024570.jpeg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/024951.jpeg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/025060.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/025063.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/025076.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/025079.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/025082.jpg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/025516.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/025628.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/026743.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0472.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/060241.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/060640.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/060649.svg',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/064845.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0673.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0740.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0807.png',
ipiv:{
360:1,
600:1,
972:1
}

}
,{
ip:'dr/0874.png',
ipiv:{
360:1,
600:1,
972:1
}

}
];
cp.model.videos=[
];
cp.model.slideVideos=[
];
cp.model.tocVideos=[
];
cp.model.audios=[
];

cp.initVariables = function(){
cp.cv('CaptivateVersion','12.2.0',1,1000,0);
cp.cv('Date.DateDDMMYY','dd/mm/yyyy',1,15,0);
cp.cv('Date.DateMMDDYY','mm/dd/yyyy',1,15,0);
cp.cv('Date.Day',1,1,15,0);
cp.cv('Date.Hours','hh',1,15,0);
cp.cv('Date.LocaleString','',1,15,0);
cp.cv('Date.Minutes','mm',1,15,0);
cp.cv('Date.Month','mm',1,15,0);
cp.cv('Date.Time','hh:mm:ss',1,15,0);
cp.cv('Date.Today','dd',1,15,0);
cp.cv('Date.Year','yyyy',1,15,0);
cp.cv('Project.AudioLevel',100,1,15,0);
cp.cv('Project.ClosedCaptions',1,1,15,0);
cp.cv('Project.CurrentSlideName','slide',1,15,0);
cp.cv('Project.CurrentSlideNumber',1,1,15,0);
cp.cv('Project.LockTOC',0,1,15,0);
cp.cv('Project.MuteAudio',0,1,15,0);
cp.cv('Project.ShowPlaybar',1,1,15,0);
cp.cv('Project.ShowTOC',0,1,15,0);
cp.cv('Project.SlideCount',1,1,15,0);
cp.cv('Question.AnswerChoice','',1,15,0);
cp.cv('Question.MaxAttempts',0,1,15,0);
cp.cv('Question.NegativePoints',0,1,15,0);
cp.cv('Question.PointsAssigned',0,1,15,0);
cp.cv('Question.PreviousQuestionScore',0,1,15,0);
cp.cv('Quiz.AttemptCount',0,1,15,0);
cp.cv('Quiz.CorrectAnswerCount',0,1,15,0);
cp.cv('Quiz.InReview',0,1,15,0);
cp.cv('Quiz.InScope',0,1,15,0);
cp.cv('Quiz.MaxScore',0,1,1000,0);
cp.cv('Quiz.Pass',0,1,15,0);
cp.cv('Quiz.PassPercentage',80,1,1000,0);
cp.cv('Quiz.PassPoints',0,1,1000,0);
cp.cv('Quiz.PercentageScore',0,1,15,0);
cp.cv('Quiz.QuestionCount',0,1,1000,0);
cp.cv('Quiz.Score',0,1,15,0);
cp.cv('Quiz.UnansweredQuestionCount',0,1,1000,0);
cp.cv('cpInfoHasPlaybar',1,1,1000,0);
cp.cv('cpInfoSlidesInProject',5,1,1000,0);
cp.cv('cpLockTOC',0,1,1000,0);
cp.cv('cpQuizInfoPreTestTotalQuestions',0,1,1000,0);
cp.cv('cpQuizInfoTotalQuizPoints',0,1,1000,0);
cp.cv('cpInfoPrevFrame',0,1,15,0);
cp.cv('LMS.CourseName','',0,15,0);
cp.cv('LMS.LearnerID','',0,15,0);
cp.cv('LMS.LearnerName','',0,15,0);
cp.cv('variableEditBoxNum_1','',0,15,0);
cp.cv('variableEditBoxStr_1','',0,15,0);
};cp.ReportingVariables="LMS.CourseName,LMS.LearnerID,LMS.LearnerName,variableEditBoxNum_1,variableEditBoxStr_1,";
};cp.sbw=0;cp.useg=0;cp.geo=0;cp.pg=0;cp.win8=0;cp.autoGrow=1;cp.fluidFont=1;
